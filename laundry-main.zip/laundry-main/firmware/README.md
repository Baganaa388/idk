# Moon Laundry NFC терминал — firmware

ESP32 дээр ажилладаг терминалын firmware. Ганц скетч:

**[`moon-terminal/`](moon-terminal)** — бүрэн апп (v8 «Хөвөн», 24/7).
Бүх ажиллагаа, холболт, компайл, оношилгоо: [`moon-terminal/README.md`](moon-terminal/README.md)

Тоног хангамжийн угсралт/холболтын схем: [`../docs/nfc-terminal-hardware.md`](../docs/nfc-terminal-hardware.md)

> Хөгжүүлэлтийн явцын туршилтын скетчүүд (дэлгэц/touch/RC522 тест гэх мэт) цэвэрлэгдсэн —
> хэрэгтэй бол git түүхээс: `git log --oneline -- firmware/`
