// Төхөөрөмжийн API — ESP32 NFC терминал үүгээр сервертэй харилцана.
// Нэвтрэлт: x-device-key толгой (DEVICE_KEY орчны хувьсагч эсвэл анхны утга).
'use strict';

const crypto = require('node:crypto');
const express = require('express');
const { getCustomerByNfc, setCustomerNfc, customerPublicView, normalizeUid } = require('../lib');
const { getSetting } = require('../db');
const deviceState = require('../device-state');

const router = express.Router();

// Хүчинтэй түлхүүр: орчны хувьсагч эсвэл DB-д хадгалсан санамсаргүй утга (хатуу утга байхгүй)
function deviceKey() {
  return process.env.DEVICE_KEY || getSetting('device_key') || '';
}
function keyOk(provided) {
  const expected = deviceKey();
  if (!expected || !provided) return false;
  const a = Buffer.from(String(provided));
  const b = Buffer.from(String(expected));
  if (a.length !== b.length) return false; // timingSafeEqual тэнцүү урт шаардана
  return crypto.timingSafeEqual(a, b);
}

// Түлхүүр шалгах (бүх зам) — зөвхөн header эсвэл body-оор (URL query-д БИШ, лог-т орохоос сэргийлнэ)
router.use((req, res, next) => {
  const key = req.get('x-device-key') || (req.body && req.body.key);
  if (!keyOk(key)) return res.status(401).json({ error: 'device key буруу байна' });
  next();
});

// Холболт шалгах + бизнесийн товч мэдээлэл (төхөөрөмжийн толгойд)
router.get('/hello', (req, res) => {
  const b = getSetting('business') || {};
  res.json({ ok: true, at: Date.now(), business: { name: b.name, phone: b.phone } });
});

// Карт уншуулах — гол урсгал
// body: { uid, intent?: 'balance'|'service' }
router.post('/scan', (req, res, next) => {
  try {
    const uid = normalizeUid(req.body && req.body.uid);
    if (!uid || uid.length < 6) return res.status(400).json({ error: 'uid буруу байна' });
    const intent = req.body && req.body.intent === 'service' ? 'service' : 'balance';

    // 1) Админ "холбох" горим армласан бол — энэ картыг тэр хэрэглэгчид холбоно
    const armPhone = deviceState.consumeBindArm();
    if (armPhone) {
      const c = setCustomerNfc(armPhone, uid); // өөр хэрэглэгчийнх бол 409 шиднэ
      deviceState.recordScan({ uid, phone: c.phone, name: c.name, intent: 'bind' });
      return res.json({ mode: 'bound', phone: c.phone, name: c.name });
    }

    // 2) Картаар хэрэглэгч хайх
    const c = getCustomerByNfc(uid);
    if (!c) {
      deviceState.recordScan({ uid, phone: null, name: null, intent });
      return res.json({ mode: 'unknown', uid });
    }
    const view = customerPublicView(c.phone);
    deviceState.recordScan({ uid, phone: c.phone, name: c.name, intent });
    res.json({ mode: 'known', view });
  } catch (e) {
    next(e);
  }
});

module.exports = router;
