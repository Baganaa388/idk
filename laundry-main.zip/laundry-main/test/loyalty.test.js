// Лоялтигийн логикийн шалгалт — `npm test`
// Түр өгөгдлийн сан дээр ажиллана; бодит data/laundry.db-г ХӨНДӨХГҮЙ.
'use strict';

const os = require('node:os');
const fs = require('node:fs');
const path = require('node:path');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'moon-test-'));
process.env.DB_PATH = path.join(TMP, 'test.db');

const { getSetting, setSetting, db } = require('../src/db');
const lib = require('../src/lib');

let pass = 0;
let fail = 0;
function eq(name, got, want) {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  console.log(`${ok ? '  ✓' : '  ✗'} ${name}${ok ? '' : ` → ${JSON.stringify(got)} (хүлээсэн ${JSON.stringify(want)})`}`);
  ok ? pass++ : fail++;
}

console.log('\nЛоялтигийн дүрэм');
const l = getSetting('loyalty');
eq('3 шатлалын хөнгөлөлт 5/7/10%', l.tiers.map((t) => t.discount), [5, 7, 10]);
eq('картын бонус анхдагчаар 2%, идэвхтэй', [l.card_bonus_enabled, l.card_bonus_pct], [true, 2]);

console.log('\nКартын бонус');
lib.createCustomer('99110011', 'Карттай');
lib.createCustomer('99110022', 'Картгүй');
lib.setCustomerNfc('99110011', '04A1B2C3D4');
const withCard = lib.getCustomer('99110011');
const noCard = lib.getCustomer('99110022');

const q1 = lib.quote({ customer: withCard, amount: 100000 });
eq('карттай — түвшин 5% = 5000₮', q1.tier.discount, 5000);
eq('карттай — бонус 2% = 2000₮', q1.card_bonus, { pct: 2, discount: 2000 });
eq('карттай — төлөх 93 000₮', q1.total, 93000);

const q2 = lib.quote({ customer: noCard, amount: 100000 });
eq('картгүй — бонус тооцогдохгүй', q2.card_bonus, null);
eq('картгүй — төлөх 95 000₮', q2.total, 95000);

db.prepare('UPDATE customers SET lifetime_points = 50 WHERE phone = ?').run('99110011');
const gold = lib.getCustomer('99110011');
eq('Gold түвшин 10%', lib.quote({ customer: gold, amount: 100000 }).tier.pct, 10);
eq('Gold + карт → 88 000₮', lib.quote({ customer: gold, amount: 100000 }).total, 88000);

console.log('\nАдминаас унтраах');
setSetting('loyalty', { ...getSetting('loyalty'), card_bonus_enabled: false });
eq('унтраасан — бонус null', lib.quote({ customer: gold, amount: 100000 }).card_bonus, null);
eq('унтраасан — зөвхөн түвшний 10%', lib.quote({ customer: gold, amount: 100000 }).total, 90000);
setSetting('loyalty', { ...getSetting('loyalty'), card_bonus_enabled: true, card_bonus_pct: 5 });
eq('хувь солих — 5% = 5000₮', lib.quote({ customer: gold, amount: 100000 }).card_bonus.discount, 5000);
setSetting('loyalty', { ...getSetting('loyalty'), card_bonus_pct: 2 });

console.log('\nГүйлгээ');
const r = lib.recordTransaction({ phone: '99110011', amount: 100000, service_type: 'Тест' });
eq('card_discount хадгалагдана', r.transaction.card_discount, 2000);
eq('төлсөн дүн 88 000₮', r.transaction.amount, 88000);
lib.reverseTransaction(r.transaction.id);
eq('буцаалт — гүйлгээ үлдэхгүй', db.prepare('SELECT COUNT(*) n FROM transactions').get().n, 0);

console.log('\nХэрэглэгчийн харагдац');
const v = lib.customerPublicView('99110011');
eq('карттай — нийт 12% хөнгөлөлт', [v.card.has_card, v.card.bonus_pct, v.card.total_discount], [true, 2, 12]);
eq('картгүй — идэвхгүй', lib.customerPublicView('99110022').card.active, false);

console.log('\nХөнгөлөлтийн дараалал');
db.prepare(
  `INSERT INTO promo_codes (code,type,value,valid_from,valid_to,usage_limit,is_active,description)
   VALUES ('TEST10','percent',10,'2000-01-01','2099-12-31',0,1,'')`
).run();
// 100000 − 10000 (Gold) − 2000 (карт) = 88000 → промо 10% (8800) → 79200
eq('түвшин → карт → промо', lib.quote({ customer: gold, amount: 100000, promo_code: 'TEST10' }).total, 79200);

fs.rmSync(TMP, { recursive: true, force: true });
console.log(`\n${fail === 0 ? '✅ БҮГД ТЭНЦЛЭЭ' : '❌ АЛДАА ИЛЭРЛЭЭ'} — ${pass} тэнцсэн, ${fail} унасан\n`);
process.exit(fail ? 1 : 0);
