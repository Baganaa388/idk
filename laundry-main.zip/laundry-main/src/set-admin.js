// Админы нууц үг тохируулах / сэргээх — `npm run admin -- <нууц-үг> [нэр]`
//
// Нууц үгээ мартсан үед, эсвэл шинэ серверт нэвтрэлтээ тогтооход хэрэглэнэ.
// Аргумент өгөөгүй бол анхдагч (admin / 12345678) руу буцаана.
'use strict';

const { setAdminPassword, DEFAULT_ADMIN_USER, DEFAULT_ADMIN_PASS } = require('./auth');
const { DB_PATH } = require('./db');

const pass = process.argv[2] || DEFAULT_ADMIN_PASS;
const user = process.argv[3] || DEFAULT_ADMIN_USER;

if (String(pass).length < 6) {
  console.error('✗ Нууц үг дор хаяж 6 тэмдэгт байх ёстой.');
  process.exit(1);
}

setAdminPassword(user, String(pass));
console.log(`\n✓ Админ нэвтрэлт тохируулагдлаа (${DB_PATH})`);
console.log(`  Нэр:     ${user}`);
console.log(`  Нууц үг: ${pass}`);
console.log('  Хуучин session-ууд хүчингүй боллоо — дахин нэвтэрнэ үү.\n');
