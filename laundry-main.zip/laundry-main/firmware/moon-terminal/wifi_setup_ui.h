// =============================================================================
//  wifi_setup_ui.h — Дэлгэц дээрх Wi-Fi тохиргоо · «Хөвөн» загвар
//  moon-terminal.ino доторх C_* палитр, F13/F16 фонт, topbar()/rrect()/txt()/
//  faceCircle()/animateSpinner() туслахуудыг ДАХИН ашиглана (тэдгээрийн ДАРАА include).
//  Урсгал: SCAN → LIST → KEYBOARD → CONNECTING → RESULT, NVS-д хадгална.
// =============================================================================
#pragma once
#include <WiFi.h>
#include <Preferences.h>

// ---- NVS (Preferences) — креденшил ----
static Preferences wui_prefs;
static void wui_saveCreds(const String& ssid, const String& pass) {
  wui_prefs.begin("wifi", false); wui_prefs.putString("ssid", ssid); wui_prefs.putString("pass", pass); wui_prefs.end();
}
static bool wui_loadCreds(String& ssid, String& pass) {
  wui_prefs.begin("wifi", true); ssid = wui_prefs.getString("ssid", ""); pass = wui_prefs.getString("pass", ""); wui_prefs.end();
  return ssid.length() > 0;
}
static void wui_clearCreds() { wui_prefs.begin("wifi", false); wui_prefs.clear(); wui_prefs.end(); }

// Блоклогч давталтын хамгаалалт — киоск ХЭЗЭЭ Ч гацахгүй:
//  • гаж (phantom) координатыг шүүнэ — клон чип үхэх зуураа хогийн цэг мэдээлдэг
//  • 1с тутам чипээ шалгаж, үхсэн бол энд ч өөрөө сэргээнэ (өмнө нь эдгээр
//    давталт дотор watchdog байгаагүй → Wi-Fi дэлгэц дээр бүрмөсөн гацдаг байв)
static bool wui_touch(int32_t& x, int32_t& y) {
  if (!lcd.getTouch(&x, &y)) return false;
  return x >= 0 && x <= W && y >= 0 && y <= H;
}
// Сонгогчийн блоклогч давталтуудын хамгаалалт: watchdog-оо тэжээж (эс бөгөөс
// төхөөрөмж энд байхдаа дахин ачаалагдана), зэрэг touch чипээ шалгана.
static void wui_guard() {
  appAlive();
  static uint32_t lp = 0; static uint8_t f = 0;
  if (millis() - lp < 1000) return;
  lp = millis();
  if (!tpPing()) { if (++f >= 2) { tpRecover("wui"); f = 0; } }
  else f = 0;
}
static void wui_wait() {
  int32_t x, y; uint32_t t0 = millis();
  while (lcd.getTouch(&x, &y) && millis() - t0 < 2000) { delay(5); appAlive(); }  // гацсан «даралт»-д хамгаалалттай
  wasDown = false; delay(20);
}
static bool wui_backTap() { int32_t x, y; return wui_touch(x, y) && hit(BTN_BACK, x, y); }

// ============================ Сканнер ======================================
struct WNet { String ssid; int32_t rssi; uint8_t enc; };
static WNet wui_nets[24];
static int  wui_netN = 0;
static const int WVIS = 4, WLY0 = 58, WPITCH = 44, WROWH = 38;   // хөндлөн: 4 мөр

static int wui_bars(int32_t r) { return r >= -60 ? 3 : (r >= -72 ? 2 : 1); }

// async scan → wui_nets (dedup + RSSI буурахаар). -1 = Буцах
static int wui_doScan() {
  lcd.fillScreen(C_BG); topbar(1);                 // "Хайж байна" clay pill
  txt("Сүлжээ хайж байна", 160, 178, F13, C_MUT, C_BG);
  spinLast = 0;
  WiFi.mode(WIFI_STA); WiFi.disconnect(); delay(60);
  WiFi.scanDelete(); WiFi.scanNetworks(true);
  int n = -1;
  for (;;) {
    wui_guard();
    animateSpinner(160, 112, C_BG);
    int16_t st = WiFi.scanComplete();
    if (st == WIFI_SCAN_FAILED) WiFi.scanNetworks(true);
    else if (st >= 0) { n = st; break; }
    if (wui_backTap()) { WiFi.scanDelete(); wui_wait(); return -1; }
    delay(10);
  }
  wui_netN = 0;
  for (int i = 0; i < n && wui_netN < 24; i++) {
    String s = WiFi.SSID(i); if (!s.length()) continue;
    int32_t r = WiFi.RSSI(i); uint8_t e = WiFi.encryptionType(i);
    int dup = -1;
    for (int j = 0; j < wui_netN; j++) if (wui_nets[j].ssid == s) { dup = j; break; }
    if (dup >= 0) { if (r > wui_nets[dup].rssi) wui_nets[dup].rssi = r; continue; }
    wui_nets[wui_netN++] = { s, r, e };
  }
  WiFi.scanDelete();
  for (int i = 1; i < wui_netN; i++) {             // RSSI буурахаар эрэмбэлэх
    WNet k = wui_nets[i]; int j = i - 1;
    while (j >= 0 && wui_nets[j].rssi < k.rssi) { wui_nets[j + 1] = wui_nets[j]; j--; }
    wui_nets[j + 1] = k;
  }
  Serial.printf("[wui] scan n=%d\n", wui_netN);
  return wui_netN;
}

static void wui_drawList() {
  lcd.fillScreen(C_BG); topbar(0);
  int shown = wui_netN < WVIS ? wui_netN : WVIS;
  for (int i = 0; i < shown; i++) {
    int y = WLY0 + i * WPITCH; bool sel = (i == 0);
    rrect(16, y, 288, WROWH, 18, sel ? C_CLAY : C_CARD);
    txt(wui_nets[i].ssid.c_str(), 31, y + WROWH / 2, F13, sel ? C_WHITE : C_ROW, sel ? C_CLAY : C_CARD, textdatum_t::middle_left);
    int lv = wui_bars(wui_nets[i].rssi);
    int bh[3] = { 4, 7, 11 };
    for (int b = 0; b < 3; b++) {
      uint16_t bc = (b < lv) ? (sel ? C_WHITE : C_CLAY) : C_EMPTY;
      lcd.fillRect(276 + b * 5, y + 25 - bh[b], 3, bh[b], bc);
    }
    if (wui_nets[i].enc != WIFI_AUTH_OPEN) {        // жижиг цоож
      lcd.drawRoundRect(258, y + 11, 8, 7, 2, sel ? C_WHITE : C_LBL);
      lcd.fillRoundRect(256, y + 15, 12, 8, 2, sel ? C_WHITE : C_LBL);
    }
  }
  if (!shown) txt("Сүлжээ олдсонгүй", 160, 120, F13, C_MUT, C_BG);
}

// scan + сонголт. -1 = Буцах
static int wui_scanAndPick(String& outSSID, bool& outOpen) {
  for (;;) {
    if (wui_doScan() < 0) return -1;
    wui_drawList();
    uint32_t lastAct = millis();
    for (;;) {
      int32_t x, y;
      wui_guard();
      if (wui_touch(x, y)) {
        lastAct = millis();
        if (hit(BTN_BACK, x, y)) { wui_wait(); return -1; }
        int shown = wui_netN < WVIS ? wui_netN : WVIS;
        if (y >= WLY0 && y < WLY0 + shown * WPITCH) {
          int idx = (y - WLY0) / WPITCH;
          if (idx < shown && (y - WLY0) % WPITCH < WROWH) {
            outSSID = wui_nets[idx].ssid; outOpen = (wui_nets[idx].enc == WIFI_AUTH_OPEN);
            wui_wait(); return idx;
          }
        }
      }
      if (millis() - lastAct > 90000) { wui_wait(); return -1; }   // 90с идэвхгүй → киоск гацахгүй
      delay(8);
    }
  }
}

// ============================ Гар (QWERTY) =================================
struct WK { int16_t x, y, w, h; char ch; uint8_t code; };
enum { KC_CH, KC_SH, KC_BK, KC_SY, KC_SP, KC_OK };
static WK wk[64]; static int wkN = 0;
static bool kShift = false, kSym = false;

static void addK(int x, int y, int w, char ch, uint8_t code) { wk[wkN++] = { (int16_t)x, (int16_t)y, (int16_t)w, 34, ch, code }; }
static void addRow(const char* s, int y, int x0, int pitch, int kw) {
  for (int i = 0; s[i]; i++) addK(x0 + i * pitch, y, kw, s[i], KC_CH);
}
static void buildKeys() {   // хөндлөн 320×240: өргөн товч, 4 эгнээ (80/119/158/197)
  wkN = 0;
  if (!kSym) {
    addRow(kShift ? "QWERTYUIOP" : "qwertyuiop", 80, 12, 30, 26);
    addRow(kShift ? "ASDFGHJKL" : "asdfghjkl", 119, 27, 30, 26);
    addK(12, 158, 40, 0, KC_SH); addRow(kShift ? "ZXCVBNM" : "zxcvbnm", 158, 58, 29, 25); addK(266, 158, 42, 0, KC_BK);
  } else {
    addRow("1234567890", 80, 12, 30, 26);
    addRow("@#$_&-+()/", 119, 12, 30, 26);
    addRow("*\"':;!?,.", 158, 12, 28, 24); addK(266, 158, 42, 0, KC_BK);
  }
  addK(12, 197, 52, 0, KC_SY); addK(70, 197, 160, ' ', KC_SP); addK(238, 197, 70, 0, KC_OK);
}
static void drawKey(const WK& k, bool dn) {
  uint16_t bg, fg;
  if (dn) { bg = C_CLAY; fg = C_WHITE; }
  else if (k.code == KC_CH) { bg = C_CARD; fg = C_INK; }
  else if (k.code == KC_OK) { bg = C_SAGE; fg = C_SAGEINK; }
  else if (k.code == KC_SH && kShift) { bg = C_SAGE; fg = C_SAGEINK; }
  else { bg = C_BLUSH; fg = C_MUT; }
  rrect(k.x, k.y, k.w, k.h, 9, bg);
  char b[2] = { k.ch, 0 }; const char* l = b;
  switch (k.code) {
    case KC_SH: l = "aA"; break; case KC_BK: l = "⌫"; break;
    case KC_SY: l = kSym ? "ABC" : "?12"; break; case KC_SP: l = ""; break; case KC_OK: l = "OK"; break;
    default: break;
  }
  if (*l) txt(l, k.x + k.w / 2, k.y + k.h / 2, k.code == KC_CH ? F13 : F11, fg, bg);
}
static void drawKeys() { for (int i = 0; i < wkN; i++) drawKey(wk[i], false); }
static void drawField(const String& s) {
  rrect(16, 42, 288, 30, 14, C_CARD);
  String d; for (size_t i = 0; i < s.length(); i++) d += "•"; d += "_";
  lcd.setClipRect(24, 42, 272, 30);
  txt(d.c_str(), 28, 57, F15, C_INK, C_CARD, textdatum_t::middle_left);
  lcd.clearClipRect();
}

// Гар: бичсэн текст буцаана. Буцах pill = "\x01" (цуцлав)
static String wui_promptText(const String& ssid) {
  String s = ""; kShift = false; kSym = false; buildKeys();
  lcd.fillScreen(C_BG); topbar(0); drawField(s); drawKeys();
  uint32_t lastAct = millis();
  for (;;) {
    int32_t x, y;
    wui_guard();
    if (millis() - lastAct > 120000) { wui_wait(); return String("\x01"); }   // 2 мин идэвхгүй → болив
    if (wui_touch(x, y)) {
      lastAct = millis();
      if (hit(BTN_BACK, x, y)) { wui_wait(); return String("\x01"); }
      for (int i = 0; i < wkN; i++) {
        WK& k = wk[i];
        if (x >= k.x && x < k.x + k.w && y >= k.y && y < k.y + k.h) {
          drawKey(k, true); bool rebuilt = false;
          switch (k.code) {
            case KC_CH: if (s.length() < 63) s += k.ch; break;
            case KC_SP: if (s.length() < 63) s += ' '; break;
            case KC_BK: if (s.length()) s.remove(s.length() - 1); break;
            case KC_SH: kShift = !kShift; buildKeys(); rebuilt = true; break;
            case KC_SY: kSym = !kSym; kShift = false; buildKeys(); rebuilt = true; break;
            case KC_OK: wui_wait(); return s;
          }
          drawField(s); wui_wait();
          if (rebuilt) drawKeys(); else drawKey(k, false);
          break;
        }
      }
    }
    delay(8);
  }
}

// ============================ Холболт + үр дүн =============================
static bool wui_connect(const char* ssid, const char* pass) {
  lcd.fillScreen(C_BG); topbar(2);                 // clay "Wi-Fi" pill
  txt(ssid, 160, 178, F15, C_MUT, C_BG);
  spinLast = 0;
  WiFi.mode(WIFI_STA); WiFi.begin(ssid, pass);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) {
    animateSpinner(160, 112, C_BG); delay(20); appAlive();
  }
  if (WiFi.status() == WL_CONNECTED) {
    // 3.3V шугамын ОГЦОМ хэлбэлзлийг арилгана — modem-sleep үед радио DTIM бүрт
    // сэрж гүйдлийн цохилт өгдөг нь touch чипийг латч хийлгэдэг байсан.
    // Тогтмол жигд ачаалал (sleep=false) + бага TX хүч = цохилтгүй тэжээл.
    WiFi.setSleep(false);
    WiFi.setTxPower(WIFI_POWER_2dBm);   // хамгийн бага түлхэлт — hotspot ойрхон тул хангалттай

  }
  return WiFi.status() == WL_CONNECTED;
}
static void wui_result(bool ok, const char* ssid) {
  lcd.fillScreen(C_BG); topbar(0);
  rrect(20, 52, 280, 160, 24, C_CARD);
  faceCircle(160, 102, 30, ok ? C_SAGE : C_BLUSH2, ok ? EX_SAGE : EX_FLAT);
  txt(ok ? "Wi-Fi холбогдлоо" : "Холбогдсонгүй", 160, 160, F16, C_INK, C_CARD);
  if (ok) txt(WiFi.localIP().toString().c_str(), 160, 190, F11, C_LBL, C_CARD);
  else    txt(ssid, 160, 190, F11, C_LBL, C_CARD);
  for (int i = 0; i < 8; i++) { delay(200); appAlive(); }
}

// ============================ Оркестратор =================================
// Ухаалаг авто-холболт: эхлээд орчноо СКАНДАЖ, хадгалсан сүлжээ бодитоор
// харагдаж байвал л холбогдоно — харагдахгүй сүлжээ (ж: гэрийн/утасны hotspot)
// руу сохроор 15с оролдохгүй. Seed-ийг зөвхөн NVS хоосон үед, мөн харагдаж
// байвал л хэрэглэнэ. Аль нь ч болохгүй бол шууд дэлгэцийн сонгогч руу.
static bool wui_smartConnect(const char* seedSsid, const char* seedPass) {
  String s, p; bool haveSaved = wui_loadCreds(s, p);
  WiFi.mode(WIFI_STA); WiFi.disconnect(); delay(50);
  int n = WiFi.scanNetworks();                     // синхрон, ~2с
  bool savedVis = false, seedVis = false;
  for (int i = 0; i < n; i++) {
    String ss = WiFi.SSID(i);
    if (haveSaved && ss == s) savedVis = true;
    if (seedSsid && *seedSsid && ss == seedSsid) seedVis = true;
  }
  WiFi.scanDelete();
  Serial.printf("[wifi] scan=%d хадгалсан('%s')харагдана=%d seed=%d\n",
                n, haveSaved ? s.c_str() : "-", savedVis, seedVis);
  if (haveSaved && savedVis && wui_connect(s.c_str(), p.c_str())) return true;
  // Хадгалсан сүлжээ ХАРАГДАХГҮЙ байвал (ж: өөр утас, хуучин hotspot) seed рүү шилжинэ.
  // Өмнө нь хуучирсан хадгалсан бичлэг seed-ийг үүрд хааж, терминал офлайн үлддэг байсан.
  if (seedVis && wui_connect(seedSsid, seedPass)) { wui_saveCreds(seedSsid, seedPass); return true; }
  return false;
}
// АРЫН (блоклохгүй) сэргээлт — хадгалсан нууц үгээр дахин холбогдохыг оролдоно.
// WiFi.begin() шууд буцдаг тул UI огт гацахгүй. Терминал тэжээл тасарсны дараа,
// эсвэл роутер дахин асахад хүний оролцоогүйгээр өөрөө сэргэнэ.
static void wui_bgReconnect(const char* seedSsid, const char* seedPass) {
  String s, p;
  bool haveSaved = wui_loadCreds(s, p) && s.length();
  bool haveSeed  = seedSsid && *seedSsid;
  if (!haveSaved && !haveSeed) return;

  // Хадгалсан ба seed сүлжээг ЭЭЛЖЛЭН оролдоно — хадгалсан сүлжээ бүрмөсөн
  // алга болсон ч (ж: өөр утас) seed hotspot ажиллаж байвал өөрөө холбогдоно.
  static bool useSeed = false;
  if (!haveSaved) useSeed = true;
  else if (!haveSeed) useSeed = false;

  const char* ssid = useSeed ? seedSsid : s.c_str();
  const char* pass = useSeed ? seedPass : p.c_str();
  useSeed = !useSeed;

  Serial.printf("[wifi] арын оролдлого: '%s'\n", ssid);
  WiFi.disconnect(false, false);   // өмнөх дуусаагүй оролдлогыг таслана
  delay(20);
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, pass);
}

static bool wui_runSetup() {
  for (;;) {
    String ssid; bool open = false;
    if (wui_scanAndPick(ssid, open) < 0) return false;
    String pass = "";
    if (!open) { pass = wui_promptText(ssid); if (pass.length() && pass[0] == '\x01') continue; }
    if (wui_connect(ssid.c_str(), pass.c_str())) { wui_saveCreds(ssid, pass); wui_result(true, ssid.c_str()); return true; }
    wui_result(false, ssid.c_str());
  }
}
