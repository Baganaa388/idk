// Нүүр хуудас — тохиргооноос нэр, үнэ, дүрэм, идэвхтэй промо ачаална.
'use strict';

(async () => {
  // Хаягийн картын дүрсүүд
  $$('[data-ic]').forEach((el) => { el.innerHTML = ICONS[el.dataset.ic] || ''; });

  // Hero онооны карт (жишээ 7/10, амилуулж харуулна)
  const hero = $('#heroCard');
  if (hero) {
    hero.innerHTML = stampCard({
      points: 7, target: 10, showTarget: true,
      visits: ['big', 'small', 'dry', 'small', 'shoe', 'big', 'small'],
      title: 'ОНООНЫ КАРТ',
      caption: 'Дараагийн урамшуулал хүртэл 3 оноо үлдлээ',
    });
  }

  let site;
  try {
    site = await api('/api/public/site');
  } catch {
    return; // статик агуулга хэвээр үлдэнэ
  }
  const { business, services, loyalty, promos } = site;

  // Бизнесийн мэдээлэл
  $$('[data-biz-name]').forEach((el) => (el.textContent = business.name));
  $$('[data-biz-tagline]').forEach((el) => (el.textContent = business.tagline));
  $$('[data-biz-hours]').forEach((el) => (el.textContent = business.hours));
  $$('[data-biz-phone]').forEach((el) => (el.textContent = business.phone));
  $$('[data-biz-address]').forEach((el) => (el.textContent = business.address));
  document.title = `${business.name} — ${business.tagline}`;

  const cardPct = Math.max(0, +loyalty.card_bonus_pct || 0);

  // Урамшууллын текстүүд
  const rl = $('[data-reward-line]');
  if (rl) rl.textContent = `${loyalty.reward_threshold} оноо цуглуулбал ${loyalty.reward_title}`;
  const se = $('[data-step-earn]');
  if (se)
    se.textContent =
      loyalty.points_mode === 'per_amount'
        ? `Төлбөрийн ${fmtT(loyalty.amount_per_point)} тутамд 1 оноо авна. Оноог бид автоматаар бүртгэнэ.`
        : loyalty.points_mode === 'per_service'
          ? 'Угаалгын төрлөөс хамаарч оноо авна — том угаалга илүү оноотой. Оноог бид автоматаар бүртгэнэ.'
          : `Үйлчлүүлэх бүрдээ ${loyalty.points_per_visit} оноо авна. Оноог бид автоматаар бүртгэнэ.`;
  const sr = $('[data-step-reward]');
  if (sr) {
    const first = (loyalty.reward_tiers && loyalty.reward_tiers[0]) || { points: loyalty.reward_threshold, title: loyalty.reward_title };
    sr.textContent = `${first.points} оноо цуглуулбал ${first.title}. Оноо их байх тусам илүү сайн урамшуулал — дугаараа хэлээд л эдэлнэ.`;
  }
  const st = $('[data-step-tier]');
  if (st) {
    const named = loyalty.tiers.filter((t) => t.min > 0).map((t) => t.name).join(', ');
    if (named) st.textContent = `Оноо хуримтлагдахад ${named} түвшинд хүрч байнгын хөнгөлөлт нээгдэнэ.`;
  }

  // Hero карт — жинхэнэ дүрмээр
  if (hero) {
    const tier0 = (loyalty.reward_tiers && loyalty.reward_tiers[0]) || { points: loyalty.reward_threshold, title: loyalty.reward_title };
    const demo = Math.max(1, tier0.points - 2);
    hero.innerHTML = stampCard({
      points: demo, target: tier0.points, showTarget: true,
      visits: ['big', 'small', 'dry', 'small', 'shoe', 'big', 'small'],
      title: 'ОНООНЫ КАРТ',
      caption: `${tier0.title} хүртэл ${tier0.points - demo} оноо үлдлээ`,
    });
  }

  // Үйлчилгээ ба үнэ — төрөл бүрд өөр дүрс, олдох онооны тэмдэг
  const iconFor = (name) => ICONS[SERVICE_KINDS[serviceKind(name)].icon] || ICONS.washer;
  $('#svcGrid').innerHTML = services
    .map(
      (s) => `
      <div class="svc">
        <span class="svc__ic" style="--k:${SERVICE_KINDS[serviceKind(s.name)].color}">${iconFor(s.name)}</span>
        <h3>${esc(s.name)}</h3>
        <div class="svc__price num">${fmtT(s.price)}</div>
        ${typeof s.points === 'number' ? `<div class="svc__pts num">+${s.points} оноо</div>` : '<div class="svc__unit">нэг удаагийн үйлчилгээ</div>'}
      </div>`
    )
    .join('');

  // Түвшний картууд
  const band = $('#tierBand');
  if (band && loyalty.tiers.length > 1) {
    band.innerHTML = loyalty.tiers
      .map((t) => {
        const mod = t.key === 'gold' ? ' tier-card--gold' : t.key === 'silver' ? ' tier-card--silver' : '';
        return `
        <div class="tier-card${mod}">
          <div class="tier-card__top">
            ${tierBadge(t.key, t.name)}
            <span class="tier-card__req num">${t.min > 0 ? `${t.min}+ оноо` : 'Эхлэл'}</span>
          </div>
          <p class="tier-card__perk">${t.discount > 0 ? `Бүх үйлчилгээнд байнгын −${t.discount}%` : 'Оноо цуглуулж эхэлнэ'}</p>
          ${cardPct > 0 ? `<p class="tier-card__bonus">Карттай бол −${t.discount + cardPct}%</p>` : ''}
        </div>`;
      })
      .join('');
  }

  // Картын бонусын мөр (тохиргоонд идэвхтэй үед л харагдана)
  const cb = $('[data-card-bonus]');
  const cbNote = $('#cardBonusNote');
  if (cb && cbNote) {
    if (cardPct > 0) {
      cb.textContent = `NFC карт авбал үйлчилгээ бүрт нэмэлт −${cardPct}% бонус автоматаар нэмэгдэнэ.`;
      cbNote.hidden = false;
    } else {
      cbNote.hidden = true;
    }
  }

  // Идэвхтэй промо
  if (promos.length) {
    $('#promoSection').hidden = false;
    $('#promoGrid').innerHTML = promos
      .map(
        (p) => `
        <div class="coupon">
          <button class="coupon__code" data-code="${esc(p.code)}" title="Хуулах">${esc(p.code)}${ICONS.copy}</button>
          <div class="coupon__meta">
            <div class="coupon__desc">${esc(p.description || 'Хөнгөлөлтийн код')}</div>
            <div class="coupon__till">${fmtDate(p.valid_to)} хүртэл</div>
          </div>
          <div class="coupon__value num">${p.type === 'percent' ? `−${p.value}%` : `−${fmtT(p.value)}`}</div>
        </div>`
      )
      .join('');
    $$('#promoGrid .coupon__code').forEach((btn) =>
      btn.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(btn.dataset.code);
          toast(`"${btn.dataset.code}" код хуулагдлаа`);
        } catch { /* clipboard байхгүй орчин */ }
      })
    );
  }
})();
