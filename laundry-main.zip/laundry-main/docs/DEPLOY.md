# Deploy — ugaalga.app

## Серверийн бүтэц

- **VM:** Google Cloud (Ubuntu) — `35.213.78.77`, ssh хэрэглэгч `bbaganaa56`
- **nginx:** 443 (Let's Encrypt/certbot, автоматаар сунгагдана) → `proxy_pass http://127.0.0.1:3000`
  - **gzip идэвхтэй** (`gzip_proxied any` + `gzip_types` — CSS/JS/JSON ~75% багасна)
  - Тохиргоо: `/etc/nginx/nginx.conf` (backup: `nginx.conf.bak-gzip`), сайт: `/etc/nginx/sites-available/laundry`
- **Апп:** systemd загвар unit **`app@laundry`** — `User=appsrv`, `Restart=always` (3с)
- **Хавтасны бүтэц** (сервер даяарх нэгдсэн стандарт — [`my-server/RUNBOOK.md`](../../my-server/RUNBOOK.md)):

  ```
  /srv/apps/laundry/
  ├── current/     ← энэ репогийн clone (main branch) — deploy бүрт солигдоно
  ├── shared/      ← deploy үед ХЭЗЭЭ Ч хөндөгдөхгүй
  │   ├── data/laundry.db    ·   SQLite өгөгдлийн сан
  │   └── app.env            ·   ENTRY / HOST / PORT / DB_PATH (эрх 600)
  └── logs/app.log ← аппын гаралт
  ```

- **Өгөгдлийн зам** нь `app.env` доторх `DB_PATH`-аар тодорхойлогдоно
  (`src/db.js` уг хувьсагчийг дэмждэг тул symlink шаардлагагүй).

> ⚠️ Хуучин `~/laundry` хавтас болон `laundry.service` unit **ашиглагдахаа больсон**.
> Тэнд `git pull` хийвэл сайт өөрчлөгдөхгүй.

## Deploy хийх

```bash
ssh -i ~/.ssh/google_compute_engine bbaganaa56@35.213.78.77
cd /srv/apps/laundry/current
sudo -u appsrv git pull
sudo -u appsrv npm install --omit=dev      # хамаарал өөрчлөгдсөн үед л хэрэгтэй
sudo systemctl restart app@laundry
systemctl is-active app@laundry            # → active
```

Зөвхөн статик/док файл өөрчлөгдсөн бол restart шаардлагагүй (`git pull` хангалттай).

## Шалгах

```bash
curl -s -o /dev/null -w "%{http_code}\n" https://ugaalga.app/          # 200
curl -s https://ugaalga.app/api/public/site | head -c 120              # JSON
sudo tail -n 30 /srv/apps/laundry/logs/app.log                         # аппын лог
sudo journalctl -u app@laundry -n 30 --no-pager                        # unit-ийн лог
```

## Домэйн ба SSL

- **Үндсэн домэйн:** `ugaalga.app` (A бичлэг → `35.213.78.77`), Let's Encrypt гэрчилгээтэй,
  HTTP → HTTPS автомат redirect. Гэрчилгээ certbot-оор автоматаар сунгагдана.
- nginx тохиргоо: `/etc/nginx/sites-available/laundry` (backup: `laundry.bak-*`).
- **`www.ugaalga.app` — АВТОМАТ.** DNS дээр `www`-г сервер рүү зааж өгмөгц (CNAME → `ugaalga.app.`
  эсвэл A → `35.213.78.77`) 10 минутын дотор гэрчилгээ өөрөө өргөжинө. Гараар хийх бол:
  ```bash
  sudo certbot --nginx -d ugaalga.app -d www.ugaalga.app --redirect --expand
  ```
- **Автомат SSL:** `/usr/local/bin/ugaalga-ssl.sh` + systemd timer `ugaalga-ssl.timer`
  (10 мин тутам, DNS бэлэн болмогц гэрчилгээ авч/өргөтгөөд өөрөө унтарна).
  Лог: `/var/log/ugaalga-ssl.log`. Төлөв: `systemctl list-timers ugaalga-ssl.timer`.
  ⚠️ Энэ сервер дээр **cron суулгаагүй** — давтагдах ажлыг systemd timer-ээр хийнэ.
- **DNS зөв бүтэц** (Namecheap):

  | Type | Host | Value |
  |---|---|---|
  | A Record | `@` | `35.213.78.77` |
  | CNAME Record | `www` | `ugaalga.app.` |

  ⚠️ `URL Redirect Record` (`@` → www) болон `www` → `parkingpage.namecheap.com` **байх ёсгүй** —
  эхнийх нь A бичлэгтэй зөрчилдөж, хоёрдугаарх нь www-г Namecheap-ийн зар руу чиглүүлнэ.

## Админ нууц үг

- Анхдагч: нэр `admin`, нууц үг `12345678`. Тохиргоо → Нууц үг солих хэсгээс солино.
- Мартвал сервер дээр:

  ```bash
  cd /srv/apps/laundry/current
  sudo -u appsrv DB_PATH=/srv/apps/laundry/shared/data/laundry.db \
       /usr/bin/node src/set-admin.js                    # → 12345678 болж сэргэнэ
  sudo -u appsrv DB_PATH=/srv/apps/laundry/shared/data/laundry.db \
       /usr/bin/node src/set-admin.js <шинэ-нууц-үг>
  ```
- `ADMIN_PASSWORD` орчны хувьсагчаар урьдчилан зааж болно (`shared/app.env` дотор).

## Өгөгдөл цэвэрлэх (шинэ эхлэл)

```bash
cd /srv/apps/laundry/current
sudo -u appsrv DB_PATH=/srv/apps/laundry/shared/data/laundry.db \
     /usr/bin/node src/reset-data.js          # баталгаажуулалт асууна
sudo -u appsrv DB_PATH=/srv/apps/laundry/shared/data/laundry.db \
     /usr/bin/node src/reset-data.js --yes    # асуулгүй
sudo systemctl restart app@laundry
```

Хэрэглэгч, гүйлгээ, промо, эрхийн бичиг устана. **Тохиргоо, админ, төхөөрөмжийн
түлхүүр үлдэнэ** — терминал цэвэрлэсний дараа шууд ажиллана.

## Backup

Сервер дээр `/usr/local/bin/backup-apps.sh` бүх аппын өгөгдлийг архивлана.
Гараар татаж авах бол локал машинаас:

```bash
ssh -i ~/.ssh/google_compute_engine bbaganaa56@35.213.78.77 \
    'sudo cat /srv/apps/laundry/shared/data/laundry.db' > ./laundry-backup-$(date +%F).db
```

Долоо хоногт нэг удаа хийж, өөр төхөөрөмжид хадгалахыг зөвлөнө.

## Асуудал гарвал

| Шинж тэмдэг | Шалгах | Шийдэл |
|---|---|---|
| Сайт унасан | `systemctl status app@laundry` | `sudo systemctl restart app@laundry`; лог: `sudo tail -50 /srv/apps/laundry/logs/app.log` |
| 502 Bad Gateway | Порт 3000 сонсож буй эсэх: `ss -ltn` | Апп унтарсан — дээрхтэй адил |
| Push хийсэн ч өөрчлөлт алга | `sudo git -C /srv/apps/laundry/current log -1` | `~/laundry`-д биш, **`/srv/apps/laundry/current`**-д pull хийсэн эсэхээ шалга |
| Өгөгдөл алга/хуучин | `sudo cat /srv/apps/laundry/shared/app.env` | `DB_PATH` зөв эсэхийг шалга — буруу бол өөр DB рүү бичиж байна |
| nginx тохиргоо эвдэрсэн | `sudo nginx -t` | Backup сэргээх: `sudo cp /etc/nginx/nginx.conf.bak-gzip /etc/nginx/nginx.conf && sudo systemctl reload nginx` |
