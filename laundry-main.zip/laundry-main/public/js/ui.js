// Дундын туслах функцууд — бүх хуудсанд ашиглагдана.
'use strict';

const $ = (q, root = document) => root.querySelector(q);
const $$ = (q, root = document) => [...root.querySelectorAll(q)];

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

const fmtT = (n) => `${Math.round(Number(n) || 0).toLocaleString('en-US')}₮`;
const fmtNum = (n) => (Number(n) || 0).toLocaleString('en-US');
const fmtDate = (s) => (s ? String(s).slice(0, 10).replaceAll('-', '.') : '');
const fmtDT = (s) => (s ? `${String(s).slice(5, 10).replace('-', '.')} ${String(s).slice(11, 16)}` : '');
const fmtPhone = (s) => (s && s.length === 8 ? `${s.slice(0, 4)}-${s.slice(4)}` : s || '');

async function api(path, opts = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    cache: 'no-store',
    ...opts,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch { /* CSV гэх мэт */ }
  if (!res.ok) {
    const err = new Error((data && data.error) || `Алдаа (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

function debounce(fn, ms = 300) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

// ---- Toast мэдэгдэл ----
function toast(msg, type = 'ok') {
  let host = $('#toasts');
  if (!host) {
    host = document.createElement('div');
    host.id = 'toasts';
    document.body.appendChild(host);
  }
  const t = document.createElement('div');
  t.className = `toast toast--${type}`;
  t.innerHTML = `<span>${type === 'ok' ? ICONS.check : ICONS.alert}</span><div>${esc(msg)}</div>`;
  host.appendChild(t);
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, 3600);
}

// ---- SVG дүрс тэмдгүүд ----
const _i = (inner) =>
  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${inner}</svg>`;
const ICONS = {
  droplet: _i('<path d="M12 2.7C12 2.7 5.5 10 5.5 14.2a6.5 6.5 0 0 0 13 0C18.5 10 12 2.7 12 2.7Z"/>'),
  moon: _i('<path d="M20.5 13.2A8.5 8.5 0 1 1 10.8 3.5a7 7 0 0 0 9.7 9.7Z"/>'),
  gauge: _i('<rect x="3" y="3" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2"/>'),
  plus: _i('<path d="M12 5v14M5 12h14"/>'),
  users: _i('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.2 3.4-5 6.5-5s5.7 1.8 6.5 5"/><circle cx="17" cy="9" r="2.5"/><path d="M16.5 15.2c2.3.3 4.2 1.9 5 4.8"/>'),
  tag: _i('<path d="M3 11.5V4a1 1 0 0 1 1-1h7.5a2 2 0 0 1 1.4.6l7.5 7.5a2 2 0 0 1 0 2.8l-6 6a2 2 0 0 1-2.8 0l-7.5-7.5A2 2 0 0 1 3 11.5Z"/><circle cx="8" cy="8" r="1.4" fill="currentColor" stroke="none"/>'),
  chart: _i('<path d="M4 20V10M10 20V4M16 20v-8M21 20H3"/>'),
  sliders: _i('<path d="M4 7h16M4 12h16M4 17h16"/><circle cx="9" cy="7" r="2" fill="var(--surface,#fff)"/><circle cx="15" cy="12" r="2" fill="var(--surface,#fff)"/><circle cx="7" cy="17" r="2" fill="var(--surface,#fff)"/>'),
  logout: _i('<path d="M9 4H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h4M15 8l4 4-4 4M19 12H9"/>'),
  search: _i('<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.3-4.3"/>'),
  download: _i('<path d="M12 4v10M8 10l4 4 4-4M4 19h16"/>'),
  printer: _i('<path d="M7 8V3h10v5"/><rect x="4" y="8" width="16" height="8" rx="1.5"/><rect x="7" y="14" width="10" height="7"/>'),
  trash: _i('<path d="M4 7h16M9 7V4h6v3M6.5 7l1 14h9l1-14M10 11v6M14 11v6"/>'),
  pencil: _i('<path d="M4 20l4.5-1L20 7.5a1.5 1.5 0 0 0 0-2.1l-1.4-1.4a1.5 1.5 0 0 0-2.1 0L5 15.5 4 20Z"/>'),
  check: _i('<path d="m5 12.5 4.5 4.5L19 7.5"/>'),
  x: _i('<path d="M6 6l12 12M18 6 6 18"/>'),
  copy: _i('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/>'),
  phone: _i('<path d="M5 4h4l1.5 4.5L8 10a12 12 0 0 0 6 6l1.5-2.5L20 15v4a1.5 1.5 0 0 1-1.7 1.5C10.5 19.6 4.4 13.5 3.5 5.7A1.5 1.5 0 0 1 5 4Z"/>'),
  clock: _i('<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.5 2"/>'),
  pin: _i('<path d="M12 21s-6.5-5.6-6.5-10.5a6.5 6.5 0 0 1 13 0C18.5 15.4 12 21 12 21Z"/><circle cx="12" cy="10.3" r="2.3"/>'),
  arrow: _i('<path d="M4 12h15M14 6.5l5.5 5.5-5.5 5.5"/>'),
  washer: _i('<rect x="4" y="3" width="16" height="18" rx="2.5"/><circle cx="12" cy="13" r="4.8"/><path d="M8.2 13a3.8 3.8 0 0 0 7.6 0"/><circle cx="7.2" cy="6" r=".9" fill="currentColor" stroke="none"/><circle cx="10.2" cy="6" r=".9" fill="currentColor" stroke="none"/>'),
  washerBig: _i('<rect x="3" y="3" width="18" height="18" rx="2.6"/><circle cx="12" cy="13.4" r="5.4"/><circle cx="12" cy="13.4" r="2.5"/><circle cx="6.4" cy="6" r=".95" fill="currentColor" stroke="none"/><circle cx="9.4" cy="6" r=".95" fill="currentColor" stroke="none"/>'),
  wind: _i('<path d="M3 8h10a2.5 2.5 0 1 0-2.4-3.3M3 12h15a2.5 2.5 0 1 1-2.4 3.3M3 16h8a2.2 2.2 0 1 1-2 3"/>'),
  shoe: _i('<path d="M3 16.5 4 10c1.8 1.2 3.6 1.4 5 .4l1.6-1.2c1.8 2.4 4.5 4 8.4 4.3a2 2 0 0 1 2 2v1H3Z"/><path d="M3 19.5h18"/>'),
  wallet: _i('<rect x="3" y="6" width="18" height="14" rx="2.5"/><path d="M16 6V5a2 2 0 0 0-2.4-2L4.6 5"/><circle cx="16.5" cy="13" r="1.3" fill="currentColor" stroke="none"/>'),
  coin: _i('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5v9M9 9.8h6M9 14.2h6"/>'),
  sparkle: _i('<path d="M12 3l1.9 5.6L19.5 10l-5.6 1.9L12 17.5l-1.9-5.6L4.5 10l5.6-1.4L12 3Z"/>'),
  gift: _i('<rect x="4" y="10" width="16" height="10" rx="1.5"/><path d="M12 10v10M4 14h16M12 10 9.5 7a2 2 0 1 1 2.5-2 2 2 0 1 1 2.5 2L12 10Z"/>'),
  calendar: _i('<rect x="3.5" y="5" width="17" height="16" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>'),
  alert: _i('<circle cx="12" cy="12" r="8.5"/><path d="M12 8v5M12 16.2v.3"/>'),
  receipt: _i('<path d="M6 3h12v18l-2-1.4L14 21l-2-1.4L10 21l-2-1.4L6 21V3Z"/><path d="M9 8h6M9 12h6"/>'),
  back: _i('<path d="M20 12H5M10 6.5 4.5 12l5.5 5.5"/>'),
};

// ---- Үйлчилгээний төрлүүд — карт дээр өөр өөр дүрсээр илэрхийлнэ ----
const SERVICE_KINDS = {
  small: { icon: 'washer', color: '#0284C7', label: 'Жижиг угаалга' },
  big: { icon: 'washerBig', color: '#7C3AED', label: 'Том угаалга' },
  dry: { icon: 'wind', color: '#D97706', label: 'Хатаалт' },
  shoe: { icon: 'shoe', color: '#E11D48', label: 'Пүүз угаалга' },
  other: { icon: 'sparkle', color: '#64748B', label: 'Бусад' },
};
// Үйлчилгээний нэрнээс төрлийг тодорхойлно (дараалал чухал: том/пүүз/хатаа-г ерөнхий "угаал"-аас өмнө)
function serviceKind(name) {
  const n = String(name || '').toLowerCase();
  if (n.includes('хатаа')) return 'dry';
  if (n.includes('пүүз') || n.includes('гутал')) return 'shoe';
  if (n.includes('том')) return 'big';
  if (n.includes('жижиг') || n.includes('угаал')) return 'small';
  return 'other';
}

// ---- Онооны карт — угаалгын машины нүүр хэлбэрээр ----
// Иллюминаторын усны түвшин = дараагийн урамшуулал хүртэлх явц.
// Хүрдний штамп бүр угаасан төрлөө (жижиг/том/хатаалт/пүүз) өөр дүрс, өнгөөр илэрхийлнэ.
// opts: { points, target, visits:[kind|serviceName], slots, title, caption, compact, showTarget }
function stampCard(opts = {}) {
  const points = Math.max(0, Math.floor(Number(opts.points) || 0));
  const target = Math.max(1, Math.floor(Number(opts.target) || 10));
  const pct = Math.max(4, Math.min(100, Math.round((points / target) * 100)));
  const slots = Math.max(5, Math.floor(opts.slots || 10));
  // visits нь kind ('big'..) эсвэл үйлчилгээний нэр байж болно
  const visits = (Array.isArray(opts.visits) ? opts.visits : [])
    .map((v) => (SERVICE_KINDS[v] ? v : serviceKind(v)))
    .slice(-slots);
  const holes = [];
  for (let i = 0; i < slots; i++) {
    const kind = visits[i];
    if (kind) {
      const k = SERVICE_KINDS[kind] || SERVICE_KINDS.other;
      holes.push(
        `<div class="hole hole--on" style="--d:${i * 55}ms;--k:${k.color}" title="${esc(k.label)}">${ICONS[k.icon] || ICONS.washer}</div>`
      );
    } else {
      holes.push(`<div class="hole" style="--d:${i * 55}ms"><span>${i + 1}</span></div>`);
    }
  }
  const led = opts.showTarget ? `${points}<em>/${target}</em>` : `${points}`;
  return `
    <div class="wash-card${opts.compact ? ' wash-card--compact' : ''}">
      <span class="wash-card__screw wash-card__screw--tl"></span>
      <span class="wash-card__screw wash-card__screw--tr"></span>
      <span class="wash-card__screw wash-card__screw--bl"></span>
      <span class="wash-card__screw wash-card__screw--br"></span>
      <div class="wash-card__panel">
        <span class="wash-card__knobs" aria-hidden="true"><i></i><i></i></span>
        <span class="wash-card__brand">${esc(opts.title || 'ОНООНЫ КАРТ')}</span>
        <span class="wash-card__led num" aria-label="${points} оноо">${led}</span>
      </div>
      <div class="wash-card__body">
        <div class="porthole" aria-hidden="true">
          <div class="porthole__glass">
            <div class="porthole__drum"></div>
            <div class="porthole__water" style="--lvl:${pct}%"><i></i><i></i><i></i><i></i></div>
            <span class="porthole__shine"></span>
          </div>
        </div>
        <div class="wash-card__stamps" style="--cols:${Math.min(slots, 5)}">${holes.join('')}</div>
      </div>
      ${opts.caption ? `<div class="wash-card__caption">${esc(opts.caption)}</div>` : ''}
    </div>`;
}

// Урамшууллын шатны жижиг зурвас — аль шат нээгдсэн, аль нь дараагийнх
function rewardLadder(tiers, points, opts = {}) {
  if (!Array.isArray(tiers) || !tiers.length) return '';
  return `<div class="reward-ladder">${tiers
    .map((t) => {
      const reached = points >= t.points;
      const isNext = !reached && !tiers.some((x) => x.points > t.points && x.points <= points);
      const cls = reached ? ' reward-ladder__row--on' : isNext ? ' reward-ladder__row--next' : '';
      return `
        <div class="reward-ladder__row${cls}">
          <span class="reward-ladder__ic">${reached ? ICONS.check : ICONS.gift}</span>
          <span class="reward-ladder__title">${esc(t.title)}</span>
          <span class="reward-ladder__pts num">${t.points} оноо</span>
        </div>`;
    })
    .join('')}</div>`;
}

function tierBadge(key, name) {
  return `<span class="tier tier--${esc(key)}">${ICONS.sparkle}${esc(name)}</span>`;
}
