// Бонус шалгах хуудас — зөвхөн харах.
'use strict';

(() => {
  const form = $('#checkForm');
  const input = $('#phoneInput');
  const errEl = $('#checkError');
  const btn = $('#checkBtn');
  const lookupView = $('#lookupView');
  const resultView = $('#resultView');

  // Бизнесийн мэдээлэл (толгой, хөл)
  api('/api/public/site')
    .then(({ business }) => {
      $$('[data-biz-name]').forEach((el) => (el.textContent = business.name));
      $$('[data-biz-hours]').forEach((el) => (el.textContent = business.hours));
      $$('[data-biz-phone]').forEach((el) => (el.textContent = business.phone));
    })
    .catch(() => {});

  input.addEventListener('input', () => {
    input.value = input.value.replace(/\D/g, '').slice(0, 8);
    errEl.hidden = true;
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const phone = input.value;
    if (phone.length !== 8) {
      errEl.textContent = 'Утасны дугаар 8 оронтой байх ёстой';
      errEl.hidden = false;
      return;
    }
    btn.disabled = true;
    btn.textContent = 'Шалгаж байна…';
    try {
      const d = await api('/api/public/check', { method: 'POST', body: { phone } });
      render(d);
    } catch (err) {
      errEl.textContent = err.message;
      errEl.hidden = false;
    } finally {
      btn.disabled = false;
      btn.textContent = 'Шалгах';
    }
  });

  function render(d) {
    const r = d.reward;
    const card = d.card || { has_card: false, bonus_pct: 0, active: false, total_discount: 0 };
    const hasReward = !!r.current;
    const greet = d.name ? `Сайн байна уу, ${esc(d.name)}!` : 'Сайн байна уу!';
    const remain = r.next ? Math.max(0, r.next.points - r.points) : 0;

    resultView.innerHTML = `
      <div class="result">
        <div class="result__hello">
          <h1>${greet}</h1>
          <p class="num">${esc(fmtPhone(d.phone))} · ${tierBadge(d.tier.key, d.tier.name)}</p>
        </div>

        ${stampCard({
          points: r.points,
          target: r.target,
          visits: d.card_services || [],
          showTarget: true,
          title: 'ТАНЫ ОНООНЫ КАРТ',
          caption: hasReward
            ? (r.next
                ? `«${esc(r.current.title)}» бэлэн! ${esc(r.next.title)} хүртэл ${remain} оноо`
                : `«${esc(r.current.title)}» бэлэн боллоо!`)
            : `${esc(r.next ? r.next.title : r.title)} хүртэл ${remain} оноо үлдлээ`,
        })}

        ${hasReward ? `
        <div class="reward-banner">
          ${ICONS.gift}
          <div>
            <strong>Танд «${esc(r.current.title)}» бэлэн байна!</strong>
            <span>Дараагийн ирэлтдээ кассанд утасны дугаараа хэлээд эдлээрэй.</span>
          </div>
        </div>` : ''}

        ${r.tiers && r.tiers.length > 1 ? `
        <div class="panel">
          <h2>${ICONS.gift} Урамшууллын шат</h2>
          <p class="ladder-note">Оноо их байх тусам илүү сайн урамшуулал. Одоо танд <b class="num">${r.points} оноо</b> байна.</p>
          ${rewardLadder(r.tiers, r.points)}
        </div>` : ''}

        <div class="result-grid">
          <div class="mini-stat"><b class="num">${fmtNum(d.points)}</b><span>Идэвхтэй оноо</span></div>
          <div class="mini-stat"><b class="num">${fmtNum(d.total_visits)}</b><span>Нийт ирэлт</span></div>
          <div class="mini-stat"><b class="num">${fmtNum(d.lifetime_points)}</b><span>Нийт оноо</span></div>
        </div>

        ${d.tier.discount > 0 || card.active ? `
        <div class="panel">
          <h2>${ICONS.sparkle} Таны байнгын хөнгөлөлт</h2>
          <p style="font-size:14.5px;color:var(--ink-2)">
            ${d.tier.discount > 0 ? `
              ${tierBadge(d.tier.key, d.tier.name)} түвшний хэрэглэгчид бүх үйлчилгээнд
              <b style="color:var(--mint-600)">−${d.tier.discount}%</b> хөнгөлөлт автоматаар тооцогдоно.` : ''}
            ${card.active ? `
              <br>Картаа уншуулдаг тул <b style="color:var(--mint-600)">нэмэлт −${card.bonus_pct}%</b> бонус нэмэгдэнэ —
              нийт <b style="color:var(--mint-600)">−${card.total_discount}%</b>.` : ''}
            ${!card.has_card && card.bonus_pct > 0 ? `
              <br>NFC карт авбал <b style="color:var(--mint-600)">нэмэлт −${card.bonus_pct}%</b> бонус нээгдэнэ.` : ''}
          </p>
        </div>` : ''}

        ${d.next_tier ? `
        <div class="panel">
          <h2>${ICONS.chart} Дараагийн түвшин</h2>
          <div class="tier-progress__row">
            <span><b>${esc(d.tier.name)}</b></span>
            <span>${esc(d.next_tier.name)} · <b class="num">${d.next_tier.remaining} оноо</b> дутуу</span>
          </div>
          <div class="progress"><i style="width:${d.next_tier.pct}%"></i></div>
          <p class="tier-progress__note">${esc(d.next_tier.name)} түвшинд хүрвэл байнгын −${d.next_tier.discount}% хөнгөлөлт нээгдэнэ.</p>
        </div>` : ''}

        ${d.promos.length ? `
        <div class="panel">
          <h2>${ICONS.tag} Идэвхтэй промо код</h2>
          <div style="display:grid;gap:10px">
            ${d.promos.map((p) => `
              <div class="coupon">
                <span class="coupon__code">${esc(p.code)}</span>
                <div class="coupon__meta">
                  <div class="coupon__desc">${esc(p.description || 'Хөнгөлөлтийн код')}</div>
                  <div class="coupon__till">${fmtDate(p.valid_to)} хүртэл</div>
                </div>
                <div class="coupon__value num">${p.type === 'percent' ? `−${p.value}%` : `−${fmtT(p.value)}`}</div>
              </div>`).join('')}
          </div>
        </div>` : ''}

        ${d.history.length ? `
        <div class="panel">
          <h2>${ICONS.clock} Сүүлийн үйлчилгээ</h2>
          <ul class="hist">
            ${d.history.map((h) => `
              <li>
                <span class="hist__ic">${h.points_redeemed > 0 ? ICONS.gift : (ICONS[SERVICE_KINDS[serviceKind(h.service_type)].icon] || ICONS.washer)}</span>
                <div class="hist__main">
                  <b>${esc(h.service_type)}</b>
                  <span class="num">${fmtDT(h.date)}</span>
                </div>
                <div class="hist__amt">
                  <b class="num">${fmtT(h.amount)}</b>
                  <span class="pts num ${h.points_redeemed > 0 ? 'pts--spend' : 'pts--earn'}">
                    ${h.points_redeemed > 0 ? `−${h.points_redeemed} оноо` : `+${h.points_earned} оноо`}
                  </span>
                </div>
              </li>`).join('')}
          </ul>
        </div>` : ''}

        <div class="check-again">
          <button class="btn btn--ghost" id="againBtn">${ICONS.back} Өөр дугаар шалгах</button>
        </div>
      </div>`;

    lookupView.hidden = true;
    resultView.hidden = false;
    window.scrollTo({ top: 0, behavior: 'smooth' });

    $('#againBtn').addEventListener('click', () => {
      resultView.hidden = true;
      lookupView.hidden = false;
      input.value = '';
      input.focus();
    });
  }

  // Утсаараа картаа уншуулбал URL-д ?uid= (эсвэл ?phone=) ирнэ → онооны хуудсыг шууд нээнэ
  (function autoOpen() {
    const q = new URLSearchParams(location.search);
    const uid = q.get('uid');
    const ph = (q.get('phone') || '').replace(/\D/g, '');
    if (uid) {
      lookupView.hidden = true;
      resultView.hidden = false;
      resultView.innerHTML = '<div class="card" style="text-align:center;padding:44px">Ачаалж байна…</div>';
      api('/api/public/check-uid?uid=' + encodeURIComponent(uid))
        .then(render)
        .catch((err) => {
          resultView.hidden = true;
          lookupView.hidden = false;
          errEl.textContent = err.message;
          errEl.hidden = false;
        });
    } else if (ph.length === 8) {
      input.value = ph;
      if (form.requestSubmit) form.requestSubmit();
      else form.dispatchEvent(new Event('submit', { cancelable: true }));
    }
  })();
})();
