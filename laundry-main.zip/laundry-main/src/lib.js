// Бизнес логик — оноо, түвшин, хөнгөлөлт, гүйлгээний тооцоолол.
// quote() нэг л газар тооцдог тул урьдчилсан харагдац ба бодит бүртгэл хэзээд таарна.
'use strict';

const crypto = require('node:crypto');
const { db, getSetting, defaultServicePoints } = require('./db');

// ---- Огноо (серверийн локал цагаар, 'YYYY-MM-DD HH:MM:SS') ----
function pad(n) {
  return String(n).padStart(2, '0');
}
function localDateTime(d = new Date()) {
  return (
    `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ` +
    `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
  );
}
function localDate(d = new Date()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

const isPhone = (s) => typeof s === 'string' && /^[0-9]{8}$/.test(s);

// ---- Түвшин ----
function sortedTiers(loyalty) {
  return [...loyalty.tiers].sort((a, b) => a.min - b.min);
}
function tierFor(lifetimePoints, loyalty) {
  const tiers = sortedTiers(loyalty);
  let cur = tiers[0];
  for (const t of tiers) if (lifetimePoints >= t.min) cur = t;
  return cur;
}
function tierProgress(lifetimePoints, loyalty) {
  const tiers = sortedTiers(loyalty);
  const cur = tierFor(lifetimePoints, loyalty);
  const next = tiers.find((t) => t.min > cur.min && t.min > lifetimePoints) || null;
  if (!next) return { current: cur, next: null, remaining: 0, pct: 100 };
  const span = next.min - cur.min;
  const done = lifetimePoints - cur.min;
  return {
    current: cur,
    next,
    remaining: next.min - lifetimePoints,
    pct: Math.max(0, Math.min(100, Math.round((done / span) * 100))),
  };
}

// ---- Урамшууллын шат (reward ladder) ----
// Оноогоор өгсөх дарааллаар цэвэрлэсэн шатууд. Оноо их байх тусам илүү сайн урамшуулал.
function sortedRewardTiers(loyalty) {
  let tiers =
    Array.isArray(loyalty.reward_tiers) && loyalty.reward_tiers.length
      ? loyalty.reward_tiers
      : [
          {
            points: loyalty.reward_threshold || 10,
            title: loyalty.reward_title || 'Урамшуулал',
            value: loyalty.reward_value || 0,
          },
        ];
  return tiers
    .map((t) => ({
      points: Math.max(1, Math.floor(Number(t.points) || 0)),
      title: String(t.title || 'Урамшуулал').slice(0, 60),
      value: Math.max(0, Math.floor(Number(t.value) || 0)),
    }))
    .sort((a, b) => a.points - b.points);
}

// Хэрэглэгчийн урамшууллын төлөв: одоо эдэлж болох дээд шат, дараагийн зорилтот шат
function rewardStatus(points, loyalty) {
  const tiers = sortedRewardTiers(loyalty);
  const affordable = tiers.filter((t) => points >= t.points);
  const current = affordable.length ? affordable[affordable.length - 1] : null;
  const next = tiers.find((t) => t.points > points) || null;
  const top = tiers[tiers.length - 1];
  const target = next ? next.points : top.points;
  return { tiers, current, next, top, base: tiers[0], target };
}

// Үйлчилгээний нэр → оноо (тохиргооноос)
function servicePointsMap() {
  const services = getSetting('services');
  const m = new Map();
  if (Array.isArray(services)) {
    for (const s of services) {
      const p = Number.isFinite(Number(s.points)) ? Math.floor(Number(s.points)) : defaultServicePoints(s.name);
      m.set(s.name, Math.max(0, p));
    }
  }
  return m;
}

// ---- Промо код ----
const findPromoStmt = db.prepare('SELECT * FROM promo_codes WHERE code = ?');
function findPromo(code) {
  if (!code) return null;
  return findPromoStmt.get(String(code).trim().toUpperCase()) || null;
}
function promoStatus(promo, onDate = localDate()) {
  if (!promo) return { ok: false, reason: 'Ийм промо код олдсонгүй' };
  if (!promo.is_active) return { ok: false, reason: 'Энэ код идэвхгүй байна' };
  if (onDate < promo.valid_from) return { ok: false, reason: 'Энэ кодын хугацаа эхлээгүй байна' };
  if (onDate > promo.valid_to) return { ok: false, reason: 'Энэ кодын хугацаа дууссан байна' };
  if (promo.usage_limit > 0 && promo.used_count >= promo.usage_limit)
    return { ok: false, reason: 'Энэ кодын ашиглах хязгаар дүүрсэн байна' };
  return { ok: true };
}

// ---- Эрхийн бичиг (voucher — бэлгийн эрхийн бичиг) ----
const findVoucherStmt = db.prepare('SELECT * FROM vouchers WHERE code = ?');
function findVoucher(code) {
  if (!code) return null;
  return findVoucherStmt.get(String(code).trim().toUpperCase()) || null;
}
function voucherStatus(v, onDate = localDate()) {
  if (!v) return { ok: false, reason: 'Ийм эрхийн бичиг олдсонгүй' };
  if (v.status === 'redeemed') return { ok: false, reason: 'Энэ эрхийн бичиг аль хэдийн ашиглагдсан' };
  if (v.status === 'void') return { ok: false, reason: 'Энэ эрхийн бичиг цуцлагдсан байна' };
  if (onDate > v.valid_to) return { ok: false, reason: 'Энэ эрхийн бичгийн хугацаа дууссан байна' };
  return { ok: true };
}
// Ойлгомжгүй тэмдэгтгүй (O,0,I,1 хассан) код үүсгэнэ
const VOUCHER_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function randomChunk(len) {
  const bytes = crypto.randomBytes(len);
  let s = '';
  for (let i = 0; i < len; i++) s += VOUCHER_ALPHABET[bytes[i] % VOUCHER_ALPHABET.length];
  return s;
}
function generateVoucherCode() {
  for (let i = 0; i < 25; i++) {
    const code = `MOON-${randomChunk(4)}-${randomChunk(4)}`;
    if (!findVoucher(code)) return code;
  }
  return `MOON-${randomChunk(6)}-${randomChunk(6)}`;
}

// ---- Картын бонус ----
// NFC карт холбосон хэрэглэгчид олгох нэмэлт хувь. Админ хэсгээс унтраавал 0.
function cardBonusPct(loyalty) {
  if (!loyalty || loyalty.card_bonus_enabled === false) return 0;
  const p = Math.floor(Number(loyalty.card_bonus_pct));
  if (!Number.isFinite(p) || p <= 0) return 0;
  return Math.min(50, p);
}

// ---- Тооцоолол (нэг эх сурвалж) ----
// input: { customer|null, items|null, amount|null, promo_code, redeem, onDate }
// items: [{ name, qty, price }]
function quote(input) {
  const loyalty = getSetting('loyalty');
  const errors = [];
  const customer = input.customer || null;
  const onDate = input.onDate || localDate();

  let items = null;
  let subtotal = 0;
  if (Array.isArray(input.items) && input.items.length) {
    items = input.items
      .map((it) => ({
        name: String(it.name || '').slice(0, 80),
        qty: Math.max(0, Math.floor(Number(it.qty) || 0)),
        price: Math.max(0, Math.floor(Number(it.price) || 0)),
      }))
      .filter((it) => it.qty > 0 && it.name);
    subtotal = items.reduce((s, it) => s + it.qty * it.price, 0);
  } else {
    subtotal = Math.max(0, Math.floor(Number(input.amount) || 0));
  }
  if (subtotal <= 0) errors.push('Дүн 0-ээс их байх ёстой');

  // 1) Түвшний хөнгөлөлт
  const tier = customer ? tierFor(customer.lifetime_points, loyalty) : sortedTiers(loyalty)[0];
  const tierPct = tier.discount || 0;
  const tierDiscount = Math.min(subtotal, Math.round((subtotal * tierPct) / 100));
  let remaining = subtotal - tierDiscount;

  // 1.5) Картын бонус — NFC карт холбосон хэрэглэгчид НЭМЭЛТ хувь.
  // Түвшний хөнгөлөлттэй адил үндсэн дүнгээс тооцно (тайлбарлахад ойлгомжтой:
  // «Silver 7% + карт 2% = 9%»). Админ унтраавал 0 болно.
  const cardPct = cardBonusPct(loyalty);
  const hasCard = !!(customer && customer.nfc_uid);
  let cardBonus = null;
  let cardDiscount = 0;
  if (hasCard && cardPct > 0) {
    cardDiscount = Math.min(remaining, Math.round((subtotal * cardPct) / 100));
    cardBonus = { pct: cardPct, discount: cardDiscount };
    remaining -= cardDiscount;
  }

  // 2) Промо код
  let promo = null;
  let promoDiscount = 0;
  if (input.promo_code) {
    const row = findPromo(input.promo_code);
    const st = promoStatus(row, onDate);
    if (!st.ok) {
      errors.push(st.reason);
    } else {
      promoDiscount =
        row.type === 'percent'
          ? Math.round((remaining * row.value) / 100)
          : Math.min(row.value, remaining);
      promo = { code: row.code, type: row.type, value: row.value, discount: promoDiscount };
      remaining -= promoDiscount;
    }
  }

  // 2.5) Эрхийн бичиг (voucher) — нэг удаагийн бэлгийн эрхийн бичиг
  let voucher = null;
  let voucherDiscount = 0;
  if (input.voucher_code) {
    const row = findVoucher(input.voucher_code);
    const st = voucherStatus(row, onDate);
    if (!st.ok) {
      errors.push(st.reason);
    } else {
      voucherDiscount =
        row.type === 'percent'
          ? Math.round((remaining * row.value) / 100)
          : Math.min(row.value, remaining);
      voucher = {
        code: row.code,
        type: row.type,
        value: row.value,
        discount: voucherDiscount,
        title: row.title,
      };
      remaining -= voucherDiscount;
    }
  }

  // 3) Урамшуулал эдлэх — оноонд тохирсон шатаар (reward ladder)
  let redeem = null;
  if (input.redeem) {
    if (!customer) {
      errors.push('Урамшуулал эдлэхийн тулд хэрэглэгч бүртгэлтэй байх ёстой');
    } else {
      const rTiers = sortedRewardTiers(loyalty);
      const affordable = rTiers.filter((t) => customer.points >= t.points);
      if (!affordable.length) {
        errors.push(`Оноо хүрэлцэхгүй байна (${customer.points}/${rTiers[0].points})`);
      } else {
        // Хүсэлтээр тодорхой шат сонгосон бол түүнийг, эс бол эдэлж болох дээд шатыг
        let chosen = affordable[affordable.length - 1];
        if (input.reward_points != null) {
          const req = affordable.find((t) => t.points === Math.floor(Number(input.reward_points)));
          if (req) chosen = req;
        }
        const discount = Math.min(chosen.value, remaining);
        redeem = { points: chosen.points, discount, title: chosen.title };
        remaining -= discount;
      }
    }
  }

  const total = Math.max(0, remaining);

  // 4) Цуглуулах оноо — үйлчилгээ тус бүрийн оноогоор (урамшуулал эдэлсэн үед оноо олгохгүй)
  let pointsEarned = 0;
  if (!redeem) {
    if (loyalty.points_mode === 'per_amount') {
      pointsEarned = Math.floor(total / Math.max(1, loyalty.amount_per_point));
    } else if (loyalty.points_mode === 'per_service') {
      const dflt = Number.isFinite(Number(loyalty.default_points))
        ? Math.max(0, Math.floor(loyalty.default_points))
        : 1;
      if (items && items.length) {
        const svcPts = servicePointsMap();
        pointsEarned = items.reduce(
          (sum, it) => sum + it.qty * (svcPts.has(it.name) ? svcPts.get(it.name) : dflt),
          0
        );
      } else {
        pointsEarned = dflt;
      }
    } else {
      pointsEarned = loyalty.points_per_visit;
    }
  }

  return {
    ok: errors.length === 0,
    errors,
    items,
    subtotal,
    tier: { key: tier.key, name: tier.name, pct: tierPct, discount: tierDiscount },
    card_bonus: cardBonus,
    promo,
    voucher,
    redeem,
    total,
    points_earned: pointsEarned,
    service_type:
      items && items.length
        ? items.map((it) => (it.qty > 1 ? `${it.name} ×${it.qty}` : it.name)).join(', ')
        : String(input.service_type || 'Бусад').slice(0, 120),
  };
}

// ---- Хэрэглэгч ----
const getCustomerStmt = db.prepare('SELECT * FROM customers WHERE phone = ?');
function getCustomer(phone) {
  return getCustomerStmt.get(phone) || null;
}
function createCustomer(phone, name = '', createdAt = localDateTime()) {
  db.prepare('INSERT INTO customers (phone, name, created_at) VALUES (?, ?, ?)').run(
    phone,
    String(name || '').trim().slice(0, 60),
    createdAt
  );
  return getCustomer(phone);
}
function refreshTier(phone) {
  const loyalty = getSetting('loyalty');
  const c = getCustomer(phone);
  if (!c) return;
  const t = tierFor(c.lifetime_points, loyalty);
  if (t.key !== c.tier) db.prepare('UPDATE customers SET tier = ? WHERE phone = ?').run(t.key, phone);
}

// ---- NFC карт ----
// UID-г нэг хэлбэрт оруулна: том үсэг, зөвхөн hex (тусгаарлагчгүй)
function normalizeUid(uid) {
  return String(uid || '').toUpperCase().replace(/[^0-9A-F]/g, '');
}
const getCustomerByNfcStmt = db.prepare('SELECT * FROM customers WHERE nfc_uid = ?');
function getCustomerByNfc(uid) {
  const canon = normalizeUid(uid);
  if (!canon) return null;
  return getCustomerByNfcStmt.get(canon) || null;
}
// Хэрэглэгчид NFC карт холбох (uid хоосон бол салгана). Өөр хэрэглэгчийнх бол 409.
function setCustomerNfc(phone, uid) {
  const c = getCustomer(phone);
  if (!c) throw httpError(404, 'Хэрэглэгч олдсонгүй');
  if (uid === null || uid === undefined || String(uid).trim() === '') {
    db.prepare('UPDATE customers SET nfc_uid = NULL WHERE phone = ?').run(phone);
    return getCustomer(phone);
  }
  const canon = normalizeUid(uid);
  if (canon.length < 6 || canon.length > 20) throw httpError(400, 'NFC UID буруу байна');
  const other = getCustomerByNfcStmt.get(canon);
  if (other && other.phone !== phone)
    throw httpError(409, `Энэ карт аль хэдийн ${other.phone} дугаарт холбогдсон байна`);
  db.prepare('UPDATE customers SET nfc_uid = ? WHERE phone = ?').run(canon, phone);
  return getCustomer(phone);
}

// ---- Гүйлгээ бүртгэх ----
// opts: { phone, name?, create_if_missing?, items?, amount?, service_type?,
//         promo_code?, redeem?, payment_method?, date?, note? }
function recordTransaction(opts) {
  if (!isPhone(opts.phone)) throw httpError(400, 'Утасны дугаар 8 оронтой байх ёстой');

  let customer = getCustomer(opts.phone);
  if (!customer) {
    if (!opts.create_if_missing) throw httpError(404, 'Хэрэглэгч олдсонгүй');
  }

  const date = opts.date || localDateTime();
  const onDate = date.slice(0, 10);
  const pm = ['Бэлэн', 'Карт', 'Данс'].includes(opts.payment_method) ? opts.payment_method : 'Бэлэн';

  const q = quote({
    customer,
    items: opts.items,
    amount: opts.amount,
    service_type: opts.service_type,
    promo_code: opts.promo_code,
    voucher_code: opts.voucher_code,
    redeem: opts.redeem,
    reward_points: opts.reward_points,
    onDate,
  });
  if (!q.ok) throw httpError(400, q.errors.join('. '));

  db.exec('BEGIN');
  try {
    if (!customer) customer = createCustomer(opts.phone, opts.name, date);

    const info = db
      .prepare(
        `INSERT INTO transactions
         (customer_phone, date, service_type, items, subtotal, tier_discount, card_discount,
          promo_code, promo_discount, voucher_code, voucher_discount,
          points_redeemed, redeem_discount,
          amount, payment_method, points_earned, note)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        customer.phone,
        date,
        q.service_type,
        q.items ? JSON.stringify(q.items) : null,
        q.subtotal,
        q.tier.discount,
        q.card_bonus ? q.card_bonus.discount : 0,
        q.promo ? q.promo.code : null,
        q.promo ? q.promo.discount : 0,
        q.voucher ? q.voucher.code : null,
        q.voucher ? q.voucher.discount : 0,
        q.redeem ? q.redeem.points : 0,
        q.redeem ? q.redeem.discount : 0,
        q.total,
        pm,
        q.points_earned,
        String(opts.note || '').slice(0, 200)
      );

    db.prepare(
      `UPDATE customers SET
         total_visits = total_visits + 1,
         total_spent = total_spent + ?,
         points = points + ? - ?,
         lifetime_points = lifetime_points + ?
       WHERE phone = ?`
    ).run(q.total, q.points_earned, q.redeem ? q.redeem.points : 0, q.points_earned, customer.phone);

    if (q.promo)
      db.prepare('UPDATE promo_codes SET used_count = used_count + 1 WHERE code = ?').run(
        q.promo.code
      );

    if (q.voucher)
      db.prepare(
        "UPDATE vouchers SET status = 'redeemed', redeemed_at = ?, redeemed_phone = ? WHERE code = ? AND status = 'active'"
      ).run(date, customer.phone, q.voucher.code);

    db.exec('COMMIT');
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
  refreshTier(customer.phone);
  return {
    transaction: db
      .prepare('SELECT * FROM transactions WHERE id = last_insert_rowid()')
      .get(),
    customer: getCustomer(customer.phone),
    quote: q,
  };
}

// ---- Гүйлгээ буцаах (алдаатай бичилтийг засах) ----
function reverseTransaction(id) {
  const tx = db.prepare('SELECT * FROM transactions WHERE id = ?').get(id);
  if (!tx) throw httpError(404, 'Гүйлгээ олдсонгүй');
  db.exec('BEGIN');
  try {
    db.prepare(
      `UPDATE customers SET
         total_visits = MAX(0, total_visits - 1),
         total_spent = MAX(0, total_spent - ?),
         points = MAX(0, points - ? + ?),
         lifetime_points = MAX(0, lifetime_points - ?)
       WHERE phone = ?`
    ).run(tx.amount, tx.points_earned, tx.points_redeemed, tx.points_earned, tx.customer_phone);
    if (tx.promo_code)
      db.prepare('UPDATE promo_codes SET used_count = MAX(0, used_count - 1) WHERE code = ?').run(
        tx.promo_code
      );
    if (tx.voucher_code)
      db.prepare(
        "UPDATE vouchers SET status = 'active', redeemed_at = NULL, redeemed_phone = NULL WHERE code = ?"
      ).run(tx.voucher_code);
    db.prepare('DELETE FROM transactions WHERE id = ?').run(id);
    db.exec('COMMIT');
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
  refreshTier(tx.customer_phone);
  return { reversed: tx, customer: getCustomer(tx.customer_phone) };
}

// ---- Хэрэглэгчийн нээлттэй харагдац (бонус шалгах хуудас) ----
function customerPublicView(phone) {
  const c = getCustomer(phone);
  if (!c) return null;
  const loyalty = getSetting('loyalty');
  const prog = tierProgress(c.lifetime_points, loyalty);
  const rs = rewardStatus(c.points, loyalty);
  const history = db
    .prepare(
      `SELECT date, service_type, amount, points_earned, points_redeemed
       FROM transactions WHERE customer_phone = ? ORDER BY date DESC, id DESC LIMIT 5`
    )
    .all(phone);
  // Картын штампд зориулж сүүлийн үйлчилгээнүүдийн төрөл (хуучнаас шинэ рүү)
  const cardServices = db
    .prepare(
      `SELECT service_type FROM transactions WHERE customer_phone = ? ORDER BY date DESC, id DESC LIMIT 10`
    )
    .all(phone)
    .map((r) => r.service_type)
    .reverse();
  const cardPct = cardBonusPct(loyalty);
  const hasCard = !!c.nfc_uid;
  return {
    phone: c.phone,
    name: c.name,
    points: c.points,
    lifetime_points: c.lifetime_points,
    total_visits: c.total_visits,
    tier: { key: prog.current.key, name: prog.current.name, discount: prog.current.discount },
    // Картын бонус — карттай эсэх, хэдэн хувь, нийт хөнгөлөлт хэд болох
    card: {
      has_card: hasCard,
      bonus_pct: cardPct,
      active: hasCard && cardPct > 0,
      total_discount: (prog.current.discount || 0) + (hasCard ? cardPct : 0),
    },
    next_tier: prog.next
      ? { name: prog.next.name, remaining: prog.remaining, pct: prog.pct, discount: prog.next.discount }
      : null,
    reward: {
      // Хуучин талбарууд (нийцтэй байдлын үүднээс)
      threshold: rs.base.points,
      title: (rs.current || rs.base).title,
      progress: Math.min(c.points, rs.target),
      available_count: rs.current ? 1 : 0,
      // Шинэ: урамшууллын шат
      points: c.points,
      target: rs.target,
      tiers: rs.tiers,
      current: rs.current,
      next: rs.next,
    },
    card_services: cardServices,
    history,
  };
}

function activePromosPublic() {
  const today = localDate();
  return db
    .prepare(
      `SELECT code, type, value, valid_to, description FROM promo_codes
       WHERE is_active = 1 AND valid_from <= ? AND valid_to >= ?
         AND (usage_limit = 0 OR used_count < usage_limit)
       ORDER BY valid_to ASC`
    )
    .all(today, today);
}

function httpError(status, message) {
  const e = new Error(message);
  e.status = status;
  return e;
}

module.exports = {
  localDateTime,
  localDate,
  isPhone,
  tierFor,
  tierProgress,
  sortedTiers,
  sortedRewardTiers,
  rewardStatus,
  servicePointsMap,
  findPromo,
  promoStatus,
  findVoucher,
  voucherStatus,
  generateVoucherCode,
  cardBonusPct,
  quote,
  getCustomer,
  createCustomer,
  recordTransaction,
  reverseTransaction,
  customerPublicView,
  activePromosPublic,
  normalizeUid,
  getCustomerByNfc,
  setCustomerNfc,
  httpError,
};
