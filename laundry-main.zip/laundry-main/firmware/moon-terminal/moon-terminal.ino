// ===========================================================================
//  MOON LAUNDRY — NFC терминал · v8  «Хөвөн» — 24/7 найдвартай ажиллагаа
//  • Touch watchdog: клон FT6336G-ийн idle-гацалтыг сэргийлнэ/сэргээнэ
//  • Дэлгэц унтуулагч: 10 мин идэвхгүйд маскот анимаци, хүрэхэд сэрнэ
//  • Карт уншигч БҮХ дэлгэцээс ажиллана (унтаа үед ч)
//  • Дулаан cream дизайн · дугуй карт · нүд/амтай маскот · зөөлөн clay/sage
//  • Сервер дуудлага АРЫН CORE дээр (FreeRTOS task) → UI гацахгүй, spinner эргэнэ
//  • Бүх анимац жижиг мужаар (partial redraw) → анивчихгүй, маш хурдан
//  • Ирмэг-илрүүлэлт touch (нэг товшилт=нэг үйлдэл) · Wi-Fi/Буцах бүх дэлгэцэд
//  Дэлгэц: 2.8" ILI9341 (ХӨНДЛӨН 320×240, rotation=1) + FT6336G touch · RC522 · ugaalga.app
//  Компайл: --fqbn "esp32:esp32:esp32:PartitionScheme=huge_app"
// ===========================================================================
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#define LGFX_USE_V1
#include <LovyanGFX.hpp>
#include <SPI.h>
#include <MFRC522.h>
#include <esp_task_wdt.h>
#include "moon_fonts.h"

#if __has_include("wifi_config.h")
  #include "wifi_config.h"
#endif
#ifndef MY_WIFI_SSID
  #define MY_WIFI_SSID ""
#endif
#ifndef MY_WIFI_PASS
  #define MY_WIFI_PASS ""
#endif
#ifndef MY_DEV_KEY
  #define MY_DEV_KEY "qcC8G5pLpOKrNTafLbHK0FH-FL2zdON0"
#endif
// Серверийн хаяг — wifi_config.h дотор MY_SRV_HOST-оор дарж болно
#ifndef MY_SRV_HOST
  #define MY_SRV_HOST "ugaalga.app"
#endif
const char* SEED_SSID = MY_WIFI_SSID;
const char* SEED_PASS = MY_WIFI_PASS;
const char* SRV_HOST  = MY_SRV_HOST;
const char* DEV_KEY    = MY_DEV_KEY;

// ---- 24/7 найдвартай ажиллагааны тогтмолууд ----
#define WDT_TIMEOUT_S    30     // энэ хугацаанд loop эргэхгүй бол автоматаар дахин асна
#define WIFI_RETRY_MS    20000  // салсан үед дахин холбогдох завсар
#define TAP_MIN_GAP_MS   220    // хоёр товшилтын хамгийн бага завсар (давхар даралт хаана)
#define TAP_GLITCH_MS    60     // touch чипийн богино «тасалдал» — нэг даралтыг хоёр болгохгүй
#define STUCK_SCREEN_MS  180000 // ямар ч дэлгэц дээр 3 мин зогсвол нүүр рүү (сүүлчийн хамгаалалт)
#define TP_DEAD_REBOOT_MS 900000 // touch 15 мин сэргэхгүй бол нэг удаа дахин ачаална

#define RC_SCK 14
#define RC_MISO 26
#define RC_MOSI 13
#define RC_SS 16
#define RC_RST 17
#define CTP_RST_PIN 33
#define CTP_INT_PIN 27
#define I2C_SDA 21
#define I2C_SCL 22

// ============================ Өнгө (Хөвөн палитр) ===========================
#define RGB(r, g, b) ((uint16_t)((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | ((b) >> 3)))
const uint16_t C_BG     = RGB(0xF6, 0xF1, 0xEE);  // cream фон (= HOME доторх маскот самбар)
const uint16_t C_CARD   = RGB(0xFF, 0xFC, 0xFA);  // цагаан карт / pill
const uint16_t C_CLAY   = RGB(0xB0, 0x7E, 0x6D);  // шавар аккент (гол товч)
const uint16_t C_SAGE   = RGB(0xA9, 0xC4, 0xB6);  // sage (баяр царай, OK)
const uint16_t C_SAGEINK= RGB(0x2F, 0x4A, 0x3D);  // sage дээрх бараан
const uint16_t C_BLUSH  = RGB(0xEF, 0xE2, 0xDC);  // маскот царай
const uint16_t C_BLUSH2 = RGB(0xF1, 0xE4, 0xDE);  // маскот (unknown)
const uint16_t C_INK    = RGB(0x43, 0x39, 0x36);  // гарчиг текст
const uint16_t C_MUT    = RGB(0x6E, 0x62, 0x5D);  // бүдэг текст
const uint16_t C_LBL    = RGB(0x8A, 0x7C, 0x76);  // жижиг шошго
const uint16_t C_EYE    = RGB(0x4A, 0x3C, 0x36);  // нүд/ам
const uint16_t C_CHEEK  = RGB(0xE5, 0xB3, 0xA4);  // хацар
const uint16_t C_WHITE  = 0xFFFF;
const uint16_t C_EMPTY  = RGB(0xEF, 0xE2, 0xDC);  // явцын хоосон зураас
const uint16_t C_ROW    = RGB(0x5E, 0x52, 0x4E);

// ============================ Геометр / төрөл ==============================
const int W = 320, H = 240;   // ХӨНДЛӨН (landscape) — setRotation(1)
enum Screen { SC_BOOT, SC_HOME, SC_LOADING, SC_MENU, SC_BALANCE, SC_UNKNOWN, SC_SENT, SC_BOUND, SC_CONFIRM, SC_SAVER };
Screen screen = SC_BOOT;
String curUid = "";
uint32_t screenAt = 0;
bool rcOK = false;
bool wasDown = false;                 // touch ирмэг илрүүлэлт
uint32_t lastUserAt = 0;              // сүүлийн хүний үйлдэл (10 мин → дэлгэц унтуулагч)
uint32_t wakeIgnoreUntil = 0;         // сэрээсэн даралтыг товчны даралт гэж тооцохгүй
uint32_t tpLastPing = 0, tpDownAt = 0, tpLastProactive = 0;   // touch watchdog төлөв
uint32_t tpNextTryAt = 0;             // чип огт хариу өгөхгүй үед 60с завсарлагатай оролдоно
uint8_t tpFails = 0, tpDeadRuns = 0;
uint8_t tpLevel = 0;                  // сэргээлтийн хүч: 0=богино RST · 1=урт RST · 2=I2C шугам цэвэрлээд урт RST
uint32_t tpDeadSince = 0;             // touch хэзээнээс хойш үхсэн (дахин ачаалах шийдвэрт)
uint32_t lastTapAt = 0, upSince = 0;  // товшилтын давхардал/тасалдал шүүлт
uint32_t wifiLostAt = 0, wifiNextTry = 0;   // WiFi автомат сэргээлт
bool rebootedForTp = false;           // touch-ийн улмаас нэг л удаа дахин ачаална

struct Bal {
  bool known; String mode; String name; long points; String tier; long target;
  bool rewardReady; String rewardTitle; String nextTitle; long remaining;
} bal;

struct Rect { int x, y, w, h; };
const Rect BTN_BACK = { 0, 0, 160, 52 };    // топбар зүүн ХАГАС — дээд булан бүхэлдээ (маш өгөөмөр)
const Rect BTN_WIFI = { 160, 0, 160, 52 };  // топбар баруун ХАГАС
bool hit(const Rect& r, int x, int y) { return x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h; }

// ============================ Дэлгэц =======================================
class LGFX : public lgfx::LGFX_Device {
  lgfx::Panel_ILI9341 _panel; lgfx::Bus_SPI _bus; lgfx::Light_PWM _light;
  lgfx::Touch_FT5x06 _touch;
public:
  LGFX(void) {
    { auto c = _bus.config();
      c.spi_host = SPI2_HOST; c.spi_mode = 0; c.freq_write = 40000000; c.freq_read = 16000000;
      c.spi_3wire = false; c.use_lock = true; c.dma_channel = SPI_DMA_CH_AUTO;
      c.pin_sclk = 18; c.pin_mosi = 23; c.pin_miso = 19; c.pin_dc = 2;
      _bus.config(c); _panel.setBus(&_bus); }
    { auto c = _panel.config();
      c.pin_cs = 15; c.pin_rst = 4; c.pin_busy = -1; c.panel_width = 240; c.panel_height = 320;
      c.dummy_read_pixel = 8; c.dummy_read_bits = 1; c.readable = true;
      c.invert = true; c.rgb_order = false; c.dlen_16bit = false; c.bus_shared = true;
      _panel.config(c); }
    { auto c = _light.config();
      c.pin_bl = 32; c.invert = false; c.freq = 44100; c.pwm_channel = 7;
      _light.config(c); _panel.setLight(&_light); }
    { auto c = _touch.config();
      c.i2c_port = 0; c.i2c_addr = 0x38; c.pin_sda = I2C_SDA; c.pin_scl = I2C_SCL;
      c.pin_int = -1; c.pin_rst = -1; c.freq = 400000;   // INT-ээр биш шууд I2C poll → touch найдвартай (алгасалтгүй)
      c.x_min = 239; c.x_max = 0; c.y_min = 319; c.y_max = 0;
      c.bus_shared = false; c.offset_rotation = 0;
      _touch.config(c); _panel.setTouch(&_touch); }
    setPanel(&_panel);
  }
};
static LGFX lcd;

// ============================ VLW фонтууд (DejaVu regular) ===================
static lgfx::VLWfont f11, f13, f15, f16, f30, f54;
static lgfx::PointerWrapper p11, p13, p15, p16, p30, p54;
#define F11 (&f11)   // 11px — шошго, pill, uid
#define F13 (&f13)   // 13px — wifi
#define F15 (&f15)   // 15px — товч, loading
#define F16 (&f16)   // 16px — гарчиг
#define F30 (&f30)   // 30px — MENU оноо (цифр)
#define F54 (&f54)   // 54px — BALANCE оноо (цифр)
#define UI_FONT F13
void initFonts() {
  p11.set(moon_f11, moon_f11_len); f11.loadFont(&p11);
  p13.set(moon_f13, moon_f13_len); f13.loadFont(&p13);
  p15.set(moon_f15, moon_f15_len); f15.loadFont(&p15);
  p16.set(moon_f16, moon_f16_len); f16.loadFont(&p16);
  p30.set(moon_f30, moon_f30_len); f30.loadFont(&p30);
  p54.set(moon_f54, moon_f54_len); f54.loadFont(&p54);
}

MFRC522 rfid(RC_SS, RC_RST);

// ============================ Зурах туслахууд ==============================
uint16_t blend(uint16_t a, uint16_t b, uint8_t t) {   // a→b, t=0..255
  int ra = (a >> 11) & 31, ga = (a >> 5) & 63, ba = a & 31;
  int rb = (b >> 11) & 31, gb = (b >> 5) & 63, bb = b & 31;
  int r = ra + ((rb - ra) * t) / 255, g = ga + ((gb - ga) * t) / 255, bl = ba + ((bb - ba) * t) / 255;
  return (uint16_t)((r << 11) | (g << 5) | bl);
}
void txt(const char* s, int x, int y, const lgfx::IFont* f, uint16_t fg, uint16_t bg = C_BG,
         textdatum_t d = textdatum_t::middle_center) {
  lcd.setFont(f); lcd.setTextColor(fg, bg); lcd.setTextDatum(d); lcd.drawString(s, x, y);
}
void rrect(int x, int y, int w, int h, int r, uint16_t c) { lcd.fillRoundRect(x, y, w, h, r, c); }

// Товч дарагдсаныг ШУУД харуулна. Дэлгэц бүтнээрээ дахин зурагдах хүртэл 100–200мс
// зарцуулагддаг тул энэ анивчилтгүйгээр «мэдрэгч хүлээж авсангүй» мэт санагддаг.
void pressFx(int x, int y, int w, int h, int r) { rrect(x, y, w, h, r, C_SAGE); }

// ---- Маскот царай (нүд/ам/хацар) ----
enum { EX_HAPPY, EX_FLAT, EX_SAGE };
void smile(int cx, int cy, int w, uint16_t c) {   // ‿ инээмсэглэл (голоороо доош)
  int hw = w / 2; if (hw < 3) hw = 3; int amp = (int)(w * 0.28f);
  for (int dx = -hw; dx <= hw; dx++) {
    int dip = (int)((1.0f - (float)(dx * dx) / (float)(hw * hw)) * amp);
    lcd.fillRect(cx + dx, cy + dip, 1, 2, c);
  }
}
void archEye(int cx, int cy, int w, uint16_t c) { // ∩ баяр нүд (голоороо дээш)
  int hw = w / 2; if (hw < 2) hw = 2; int amp = (int)(w * 0.5f);
  for (int dx = -hw; dx <= hw; dx++) {
    int up = (int)((1.0f - (float)(dx * dx) / (float)(hw * hw)) * amp);
    lcd.fillRect(cx + dx, cy - up, 1, 2, c);
  }
}
void faceFeatures(int cx, int cy, int R, uint8_t ex) {
  int eo = (int)(R * 0.34f), ey = cy - (int)(R * 0.02f), es = max(2, (int)(R * 0.11f));
  uint16_t ink = (ex == EX_SAGE) ? C_SAGEINK : C_EYE;
  if (ex == EX_SAGE) {
    archEye(cx - eo, ey + 2, (int)(R * 0.34f), ink);
    archEye(cx + eo, ey + 2, (int)(R * 0.34f), ink);
  } else {
    lcd.fillCircle(cx - eo, ey, es, ink);
    lcd.fillCircle(cx + eo, ey, es, ink);
  }
  int my = cy + (int)(R * 0.34f);
  if (ex == EX_FLAT) lcd.fillRoundRect(cx - 8, my - 1, 16, 2, 1, ink);
  else smile(cx, my, (int)(R * 0.52f), ink);
  if (ex == EX_HAPPY) {
    int chx = (int)(R * 0.62f), chy = cy + (int)(R * 0.30f);
    lcd.fillEllipse(cx - chx, chy, 4, 3, C_CHEEK);
    lcd.fillEllipse(cx + chx, chy, 4, 3, C_CHEEK);
  }
}
void faceCircle(int cx, int cy, int R, uint16_t col, uint8_t ex) {
  lcd.fillCircle(cx, cy, R, col); faceFeatures(cx, cy, R, ex);
}

// ---- Топбар: зүүн ‹ Буцах, баруун Wi-Fi (эсвэл clay төлөв) ----
// kind: 0 = Wi-Fi + төлөвийн цэг · 1 = clay "Хайж байна" · 2 = clay "Wi-Fi"
// Төлөвийн цэг: ногоон(sage) = холбогдсон · улаавтар(clay) = холбогдоогүй.
// Ингэснээр ажилтан харангуутаа интернэт байгаа эсэхийг мэднэ.
void topbar(uint8_t kind = 0) {
  rrect(16, 14, 67, 25, 12, C_CARD);
  txt("‹ Буцах", 49, 27, F11, C_MUT, C_CARD);
  if (kind == 1) { rrect(211, 14, 93, 25, 12, C_CLAY); txt("Хайж байна", 257, 27, F11, C_WHITE, C_CLAY); }
  else if (kind == 2) { rrect(254, 14, 50, 25, 12, C_CLAY); txt("Wi-Fi", 279, 27, F11, C_WHITE, C_CLAY); }
  else {
    rrect(242, 14, 62, 25, 12, C_CARD);
    lcd.fillCircle(258, 26, 3, WiFi.status() == WL_CONNECTED ? C_SAGE : C_CLAY);
    txt("Wi-Fi", 277, 27, F11, C_MUT, C_CARD);
  }
}

// ---- Spinner (эргэдэг цагираг) — жижиг мужаар (анивчихгүй) ----
uint32_t spinLast = 0; int spinAng = 0;
void animateSpinner(int cx, int cy, uint16_t bgc) {
  if (millis() - spinLast < 55) return;
  spinLast = millis(); spinAng = (spinAng + 34) % 360;
  lcd.fillRect(cx - 18, cy - 18, 36, 36, bgc);
  lcd.drawArc(cx, cy, 15, 17, 0, 360, C_BLUSH);
  lcd.drawArc(cx, cy, 15, 17, spinAng, (spinAng + 95) % 360, C_CLAY);
}

// ============================ Дэлгэцүүд =====================================
void drawBoot(const char* msg) {
  lcd.fillScreen(C_BG);
  faceCircle(160, 90, 35, C_BLUSH, EX_HAPPY);
  txt("MOON LAUNDRY", 160, 150, F11, C_LBL);
  if (msg && *msg) txt(msg, 160, 190, F11, C_MUT, C_BG);
}

// HOME — маскот "карт" зүүн талд + текст баруун талд (хөндлөн зохиомж)
int PULSE_CX = 146, PULSE_CY = 128;
void enterHome() {
  screen = SC_HOME; screenAt = millis(); curUid = ""; wasDown = false;
  lastUserAt = millis();               // унтуулагчийн 10 мин тоолол эндээс эхэлнэ
  lcd.fillScreen(C_BG);
  topbar(0);
  rrect(20, 52, 280, 160, 24, C_CARD);              // үндсэн карт
  rrect(52, 101, 96, 62, 16, C_BG);                 // маскот "угаалгын карт" (зүүн)
  lcd.fillCircle(81, 126, 3, C_EYE);                // нүд
  lcd.fillCircle(103, 126, 3, C_EYE);
  smile(92, 140, 14, C_EYE);                         // ам
  lcd.fillEllipse(72, 138, 4, 3, C_CHEEK);           // хацар
  lcd.fillEllipse(111, 138, 4, 3, C_CHEEK);
  txt("Картаа", 224, 118, F16, C_INK, C_CARD);       // баруун тал
  txt("уншуулна уу", 224, 146, F16, C_INK, C_CARD);
}
void animatePulse() {   // NFC цагираг лугшина (жижиг муж)
  static uint32_t last = 0; static int ph = 0;
  if (millis() - last < 70) return;
  last = millis(); ph = (ph + 1) % 20;
  float f = (ph < 10) ? ph / 10.0f : (20 - ph) / 10.0f;
  int rr = 8 + (int)(f * 3);
  uint16_t c = blend(C_CARD, C_CLAY, (uint8_t)(55 + f * 200));
  lcd.fillRect(133, 115, 15, 26, C_BG);       // зүүн тал — маскот самбар өнгө
  lcd.fillRect(148, 115, 12, 26, C_CARD);     // баруун тал — карт өнгө
  lcd.drawCircle(PULSE_CX, PULSE_CY, rr, c);
  lcd.drawCircle(PULSE_CX, PULSE_CY, rr - 1, c);
}

void drawLoading(const char* title) {
  screen = SC_LOADING; screenAt = millis(); wasDown = false;
  lcd.fillScreen(C_BG);
  topbar(0);
  txt(title, 160, 178, F15, C_MUT, C_BG);
  spinLast = 0;   // spinner-ийг шууд эхлүүл
}

const char* tierMn(const String& t) {
  if (t.indexOf("old") >= 0 || t.indexOf("лт") >= 0) return "АЛТ";
  if (t.indexOf("ilver") >= 0 || t.indexOf("нгө") >= 0) return "МӨНГӨ";
  if (t.indexOf("ronze") >= 0 || t.indexOf("рэл") >= 0) return "ХҮРЭЛ";
  return "ГИШҮҮН";
}
void drawMenu() {
  screen = SC_MENU; screenAt = millis(); wasDown = false;
  lcd.fillScreen(C_BG);
  topbar(0);
  char greet[72];
  if (bal.name.length()) snprintf(greet, sizeof(greet), "Сайн уу, %s", bal.name.c_str());
  else snprintf(greet, sizeof(greet), "Сайн байна уу!");
  lcd.setFont(F13);
  txt(greet, 160, 58, lcd.textWidth(greet) <= 300 ? F13 : F11, C_MUT, C_BG);  // нэрээр мэндчилгээ
  String pts = String(bal.points);
  lcd.setFont(F30);
  int gx = 160 - (17 * 2 + 9 + lcd.textWidth(pts.c_str())) / 2 + 17;  // маскот+оноог хамт голлуулна
  faceCircle(gx, 96, 17, C_BLUSH, EX_HAPPY);         // жижиг маскот
  txt(pts.c_str(), gx + 26, 96, F30, C_INK, C_BG, textdatum_t::middle_left);
  rrect(24, 138, 130, 56, 28, C_CLAY);               // хөндлөн: 2 товч зэрэгцээ
  txt("Үлдэгдэл", 89, 166, F15, C_WHITE, C_CLAY);
  rrect(166, 138, 130, 56, 28, C_CARD);
  txt("Үйлчилгээ", 231, 166, F15, C_INK, C_CARD);
  txt("Үйлчилгээгээ сонгоно уу", 160, 218, F11, C_LBL, C_BG);   // доод hint
}
void drawBalance() {
  screen = SC_BALANCE; screenAt = millis(); wasDown = false;
  lcd.fillScreen(C_BG);
  topbar(0);
  rrect(20, 50, 280, 174, 24, C_CARD);
  txt(String(bal.points).c_str(), 160, 106, F54, C_INK, C_CARD);
  char lab[48]; snprintf(lab, sizeof(lab), "ОНОО · %s", tierMn(bal.tier));
  txt(lab, 160, 146, F11, C_LBL, C_CARD);
  int filled = 3;
  if (bal.target > 0) { filled = (int)(4L * bal.points / bal.target); if (filled > 4) filled = 4; if (filled < 0) filled = 0; }
  for (int i = 0; i < 4; i++) rrect(103 + i * 30, 168, 24, 5, 3, i < filled ? C_CLAY : C_EMPTY);
  char nx[48];
  if (bal.rewardReady) snprintf(nx, sizeof(nx), "Урамшуулал бэлэн");
  else snprintf(nx, sizeof(nx), "%ld оноо хүртэл", bal.remaining > 0 ? bal.remaining : 0);
  txt(nx, 160, 196, F11, C_MUT, C_CARD);
}
void drawUnknown(const String& uid) {
  screen = SC_UNKNOWN; screenAt = millis(); wasDown = false;
  lcd.fillScreen(C_BG);
  topbar(0);
  rrect(20, 52, 280, 160, 24, C_CARD);
  faceCircle(160, 104, 28, C_BLUSH2, EX_FLAT);
  txt("Карт бүртгэлгүй", 160, 158, F16, C_INK, C_CARD);
  txt(uid.c_str(), 160, 188, F11, C_LBL, C_CARD);
}
void drawSent() {
  screen = SC_SENT; screenAt = millis(); wasDown = false;
  lcd.fillScreen(C_BG);
  topbar(0);
  rrect(20, 52, 280, 160, 24, C_CARD);
  faceCircle(160, 102, 29, C_SAGE, EX_SAGE);
  txt("Илгээгдлээ", 160, 166, F16, C_INK, C_CARD);
}
void drawBound() {
  screen = SC_BOUND; screenAt = millis(); wasDown = false;
  lcd.fillScreen(C_BG);
  topbar(0);
  rrect(20, 52, 280, 160, 24, C_CARD);
  faceCircle(160, 102, 32, C_BLUSH, EX_HAPPY);
  txt("Карт холбогдлоо", 160, 166, F16, C_INK, C_CARD);
}

// Үйлчилгээ авахаас өмнөх БАТАЛГААЖУУЛАЛТ — санамсаргүй үйлдлийг цуцлах боломж
// («Үгүй»/«Буцах» → цэс рүү ухарна, юу ч илгээхгүй)
void drawConfirm() {
  screen = SC_CONFIRM; screenAt = millis(); wasDown = false;
  lcd.fillScreen(C_BG);
  topbar(0);
  faceCircle(160, 76, 26, C_BLUSH, EX_HAPPY);
  txt("Үйлчилгээ авах уу?", 160, 122, F16, C_INK, C_BG);
  txt("Ажилтанд хүсэлт очно", 160, 146, F11, C_MUT, C_BG);
  rrect(28, 170, 124, 54, 26, C_CARD);         // Үгүй (зүүн, аюулгүй сонголт)
  txt("Үгүй", 90, 197, F15, C_INK, C_CARD);
  rrect(168, 170, 124, 54, 26, C_CLAY);        // Тийм (баруун, үйлдэл)
  txt("Тийм", 230, 197, F15, C_WHITE, C_CLAY);
}

// ---- Дэлгэц унтуулагч (24/7 ажиллагаа) ----
// 10 мин идэвхгүй бол boot дэлгэцийн маскот (image-18 дизайн) амьсгалж, нүд
// аниулж анимаци хийнэ; гэрэл бүдгэрнэ. Дэлгэцэд хүрэхэд сэрнэ. Карт уншигч
// унтаа үед ч БҮРЭН идэвхтэй — карт ойртуулбал шууд уншина.
void enterSaver() {
  screen = SC_SAVER; screenAt = millis(); wasDown = false;
  lcd.fillScreen(C_BG);
  txt("MOON LAUNDRY", 160, 196, F11, C_LBL, C_BG);
  txt("Картаа уншуулна уу", 160, 220, F11, C_LBL, C_BG);
  lcd.setBrightness(60);                 // бүдэг — дэлгэц/нүдэнд ээлтэй, 24/7-д тохиромжтой
  tpLastProactive = millis();
}
void animateSaver() {                    // жижиг мужаар (84×96) — анивчихгүй
  static uint32_t last = 0; static int ph = 0;
  if (millis() - last < 100) return;
  last = millis(); ph = (ph + 1) % 64;
  int dy = (int)lroundf(sinf(ph * 6.2832f / 64.0f) * 4.0f);   // зөөлөн амьсгал ±4px
  bool blink = (ph >= 58);                                     // 6.4с тутам нүд аниулна
  int cy = 112 + dy;
  lcd.fillRect(118, 68, 84, 96, C_BG);
  lcd.fillCircle(160, cy, 35, C_BLUSH);
  int eo = 12, ey = cy - 1;
  if (blink) { archEye(160 - eo, ey + 2, 12, C_EYE); archEye(160 + eo, ey + 2, 12, C_EYE); }
  else { lcd.fillCircle(160 - eo, ey, 4, C_EYE); lcd.fillCircle(160 + eo, ey, 4, C_EYE); }
  smile(160, cy + 12, 18, C_EYE);
  lcd.fillEllipse(160 - 22, cy + 10, 4, 3, C_CHEEK);
  lcd.fillEllipse(160 + 22, cy + 10, 4, 3, C_CHEEK);
}
void wakeFromSaver() {
  lcd.setBrightness(225);
  wakeIgnoreUntil = millis() + 400;      // сэрээсэн даралт ямар ч товч дарахгүй
  enterHome();
}

// ---- Гацалтын эсрэг үндсэн хамгаалалт ----
// Аппын дурын БЛОКЛОГЧ давталт (WiFi сонгогч, гар, скан) энэ функцийг дуудна.
// Дуудагдахаа больвол hardware watchdog 30с дараа төхөөрөмжийг өөрөө дахин асаана —
// «үүрд гацах» гэж байхгүй болно.
bool g_wdtOn = false;
inline void appAlive() { if (g_wdtOn) esp_task_wdt_reset(); }

// Дахин ачаалах нэгдсэн цэг (шалтгааныг логлож, дэлгэцийг цэвэрлэнэ)
void appReboot(const char* why) {
  Serial.printf("[sys] ДАХИН АЧААЛЖ БАЙНА — %s\n", why);
  Serial.flush();
  delay(120);
  ESP.restart();
}

// Дэлгэц дээрх Wi-Fi сонгогч — Хөвөн загвар (topbar/rrect/txt/faceCircle/spinner-ийг дахин ашиглана)
bool tpPing();                       // сонгогчийн блоклогч давталтууд watchdog ашиглана
void tpRecover(const char* why);
#include "wifi_setup_ui.h"

// ============================ Сервер (АРЫН CORE) ============================
bool httpScan(const String& uid, const char* intent, Bal& out) {
  if (WiFi.status() != WL_CONNECTED) return false;
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http;
  String url = String("https://") + SRV_HOST + "/api/device/scan";
  if (!http.begin(client, url)) return false;
  http.addHeader("Content-Type", "application/json");
  http.addHeader("x-device-key", DEV_KEY);
  http.setConnectTimeout(4000);
  http.setTimeout(5000);
  String body = String("{\"uid\":\"") + uid + "\",\"intent\":\"" + intent + "\"}";
  int code = http.POST(body);
  if (code != 200) { Serial.printf("[http] code=%d\n", code); http.end(); return false; }
  String resp = http.getString();
  http.end();
  JsonDocument doc;
  if (deserializeJson(doc, resp)) return false;
  const char* mode = doc["mode"] | "";
  out = Bal{};
  out.mode = String(mode);
  if (!strcmp(mode, "bound")) { out.name = String((const char*)(doc["name"] | "")); out.known = false; return true; }
  if (!strcmp(mode, "known")) {
    JsonObject v = doc["view"];
    out.known = true;
    out.name = String((const char*)(v["name"] | ""));
    out.points = v["points"] | 0;
    out.tier = String((const char*)(v["tier"]["name"] | "Bronze"));
    out.target = v["reward"]["target"] | 0;
    if (!v["reward"]["current"].isNull()) { out.rewardReady = true; out.rewardTitle = String((const char*)(v["reward"]["current"]["title"] | "")); }
    if (!v["reward"]["next"].isNull()) {
      out.nextTitle = String((const char*)(v["reward"]["next"]["title"] | ""));
      long np = v["reward"]["next"]["points"] | 0;
      out.remaining = np > out.points ? np - out.points : 0;
    }
    return true;
  }
  out.known = false; return true;
}

// Сервертэй холбоо БАТАЛГААЖУУЛАХ — Wi-Fi холбогдмогц нэг удаа дуудна.
// Ингэснээр «интернэт бий ч сервер рүү хүрэхгүй» (домэйн/түлхүүр/SSL) асуудлыг
// карт уншуулахаас ӨМНӨ логоос шууд харна.
void httpHello() {
  if (WiFi.status() != WL_CONNECTED) return;
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http;
  String url = String("https://") + SRV_HOST + "/api/device/hello";
  if (!http.begin(client, url)) { Serial.println("[srv] хаяг нээгдсэнгүй"); return; }
  http.addHeader("x-device-key", DEV_KEY);
  http.setConnectTimeout(4000);
  http.setTimeout(5000);
  int code = http.GET();
  String body = code == 200 ? http.getString() : String("");
  http.end();
  appAlive();
  if (code == 200)      Serial.printf("[srv] ✓ %s холбогдлоо — %s\n", SRV_HOST, body.c_str());
  else if (code == 401) Serial.printf("[srv] ✗ %s — ТӨХӨӨРӨМЖИЙН ТҮЛХҮҮР БУРУУ\n", SRV_HOST);
  else                  Serial.printf("[srv] ✗ %s — хүрсэнгүй (code=%d)\n", SRV_HOST, code);
}

// async scan төлөв: 0 idle · 1 running · 2 ok · 3 fail
volatile int g_scanState = 0;
// ХУВИЛБАРЫН ДУГААР: хэрэглэгч «Буцах» дараад шинэ карт уншуулбал ХУУЧИН хүсэлт
// сүүлд дуусаж, ӨӨР хүний мэдээллийг үзүүлэх эрсдэлтэй байсан. Зөвхөн хамгийн
// сүүлийн хүсэлтийн хариуг хүлээж авна.
volatile uint32_t g_scanGen = 0;
volatile bool g_scanBusy = false;
String g_uid; char g_intent[12];

void scanTaskFn(void* arg) {
  uint32_t gen = (uint32_t)(uintptr_t)arg;
  Bal tmp;
  bool ok = httpScan(g_uid, g_intent, tmp);
  if (gen == g_scanGen) {          // хоцорсон хариуг хаяна
    if (ok) bal = tmp;
    g_scanState = ok ? 2 : 3;
  }
  g_scanBusy = false;
  vTaskDelete(NULL);
}

void startScan(const char* intent) {
  if (WiFi.status() != WL_CONNECTED) {
    enterHome();
    txt("Интернэт алга — Wi-Fi холбоно уу", 160, 226, F11, C_CLAY, C_BG);
    return;
  }
  if (g_scanBusy) {                // өмнөх хүсэлт дуусаагүй — давхар task үүсгэхгүй
    g_scanGen++;                   // хуучныг хүчингүй болгоод хүлээнэ
    Serial.println("[scan] өмнөх хүсэлт дуусаагүй — хүлээнэ");
  }
  g_uid = curUid; strncpy(g_intent, intent, 11); g_intent[11] = 0;
  g_scanState = 1;
  uint32_t gen = ++g_scanGen;
  drawLoading(!strcmp(intent, "service") ? "Илгээж байна" : "Уншиж байна");
  g_scanBusy = true;
  if (xTaskCreatePinnedToCore(scanTaskFn, "scan", 24576, (void*)(uintptr_t)gen, 1, NULL, 0) != pdPASS) {
    g_scanBusy = false;
    g_scanState = 3;               // task үүсэхгүй бол шууд алдаа гэж үзнэ (гацахгүй)
    Serial.println("[scan] task үүсгэж чадсангүй");
  }
}

// UID унших — REQA + WUPA (HALT-лагдсан картыг ч сэрээнэ → «заримдаа уншдаггүй»
// асуудлыг багасгана). Картын ТӨРЛИЙГ логлоно; илэрсэн ч уншигдаагүйг мөн логлоно.
// Огт лог гарахгүй карт = 125kHz (EM4100 г.м) — RC522 зөвхөн 13.56MHz уншина.
bool g_viaWupa = false;
String readUidRaw() {
  byte atqa[2]; byte sz = 2;
  MFRC522::StatusCode st = rfid.PICC_RequestA(atqa, &sz);
  g_viaWupa = false;
  if (st != MFRC522::STATUS_OK && st != MFRC522::STATUS_COLLISION) {
    sz = 2; st = rfid.PICC_WakeupA(atqa, &sz);
    g_viaWupa = true;
  }
  if (st != MFRC522::STATUS_OK && st != MFRC522::STATUS_COLLISION) return "";
  bool sel = rfid.PICC_ReadCardSerial();
  for (int r = 0; r < 3 && !sel; r++) {   // сул RF холбоотой карт (жижиг антентай, шинэ
    delay(8);                             // картууд): богино завсартай 3 удаа дахин сонгоно
    byte a2[2]; byte s2 = 2;
    if (rfid.PICC_WakeupA(a2, &s2) != MFRC522::STATUS_OK) {
      s2 = 2;
      if (rfid.PICC_RequestA(a2, &s2) != MFRC522::STATUS_OK) continue;
    }
    sel = rfid.PICC_ReadCardSerial();
  }
  if (!sel) {
    static uint32_t lastWarn = 0;
    if (millis() - lastWarn > 2000) {
      lastWarn = millis();
      Serial.printf("[card] карт илэрсэн ч UID уншигдсангүй (ATQA=%02X%02X) — тогтоон барьж ойртуулна уу\n", atqa[1], atqa[0]);
    }
    return "";
  }
  String s = "";
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) s += "0";
    s += String(rfid.uid.uidByte[i], HEX);
    if (i + 1 < rfid.uid.size) s += ":";
  }
  s.toUpperCase();
  MFRC522::PICC_Type t = rfid.PICC_GetType(rfid.uid.sak);
  Serial.printf("[card] UID=%s SAK=0x%02X %s\n", s.c_str(), rfid.uid.sak, String(rfid.PICC_GetTypeName(t)).c_str());
  return s;
}
void cardDone() { rfid.PICC_HaltA(); rfid.PCD_StopCrypto1(); }

// ---- RF ТАЛБАРЫГ ӨӨРӨӨ ТААРУУЛАХ (антенн бүрт өөр өөр таарна) ----
// Клон RC522 модулиудын антенны тааруулга (matching) үйлдвэр бүрт өөр. Хэт хүчтэй
// түлхэлт + хэт өндөр RX өсгөлт хосолбол хүлээн авагч «дүлийрч» (saturation) картын
// сул хариуг ОГТ сонсохгүй болдог — карт ойртуулахад ямар ч лог гарахгүй. Тиймээс
// нэг утга хатуу бичихийн оронд хэд хэдэн хослолыг ЭЭЛЖЛЭН туршиж, аль нь карт
// уншсаныг олоод түүнийгээ NVS-д хадгалж дараагийн ачаалалтад шууд ашиглана.
struct RfCfg { uint8_t gsn; uint8_t rx; const char* name; };
static const RfCfg RF_CFGS[] = {
  { 0x88, MFRC522::RxGain_avg,  "GsN=88 RX=33dB (үйлдвэрийн анхдагч)" },
  { 0x88, MFRC522::RxGain_43dB, "GsN=88 RX=43dB" },
  { 0x88, MFRC522::RxGain_max,  "GsN=88 RX=48dB" },
  { 0xF4, MFRC522::RxGain_avg,  "GsN=F4 RX=33dB" },
  { 0xF4, MFRC522::RxGain_43dB, "GsN=F4 RX=43dB" },
  { 0xF4, MFRC522::RxGain_max,  "GsN=F4 RX=48dB" },
  { 0xFF, MFRC522::RxGain_38dB, "GsN=FF RX=38dB" },
};
static const uint8_t RF_N = sizeof(RF_CFGS) / sizeof(RF_CFGS[0]);
uint8_t  rfIdx = 0;           // одоо ашиглаж буй хослол
bool     rfLocked = false;    // карт уншигдмагц түгжинэ (эргэлт зогсоно)
uint32_t rfSweepAt = 0;
static Preferences rf_prefs;

void rfLoad() {                       // сүүлд ажилласан хослолыг сэргээнэ
  rf_prefs.begin("rf", true);
  rfIdx = rf_prefs.getUChar("idx", 0);
  rfLocked = rf_prefs.getBool("ok", false);
  rf_prefs.end();
  if (rfIdx >= RF_N) { rfIdx = 0; rfLocked = false; }
  Serial.printf("[rf] эхлэх тохиргоо #%u %s%s\n", rfIdx, RF_CFGS[rfIdx].name,
                rfLocked ? " (өмнө ажилласан)" : " (хайлт хийнэ)");
}
void rfSave() {
  rf_prefs.begin("rf", false);
  rf_prefs.putUChar("idx", rfIdx);
  rf_prefs.putBool("ok", true);
  rf_prefs.end();
}

// ---- RC522 клон уншигчийг НАЙДВАРТАЙ ажиллуулах (гол засвар) ----
// Клон уншигч ачаалсны дараа хэсэг ажиллаад «уншихаа больдог»: WiFi TX-ийн гүйдлийн
// хэлбэлзэл / удаан идэвхгүй байдал дээр дотоод регистр/командын төлөв нь эвдэрдэг.
// Зөвхөн антенн асаах нь ХҮРЭЛЦДЭГГҮЙ (өмнө туршсан). Тиймээс тодорхой хугацаанд нэг
// удаа PCD_Init-ийн БҮХ тохиргоог дахин бичиж (soft-reset-ийн delay(50)-гүй тул анимац
// гацахгүй) уншигчийг цэвэр, унших чадвартай төлөвт байнга байлгана.
uint32_t rcLastPoll = 0, rcLastInit = 0;
void rcReinit() {
  rfid.PCD_WriteRegister(MFRC522::CommandReg, MFRC522::PCD_Idle);  // гацсан командыг таслах
  rfid.PCD_StopCrypto1();                                          // үлдэгдэл crypto унтраах
  rfid.PCD_WriteRegister(MFRC522::TxModeReg, 0x00);               // ↓ PCD_Init-ийн тохиргоог
  rfid.PCD_WriteRegister(MFRC522::RxModeReg, 0x00);               //   delay-гүйгээр давтана
  rfid.PCD_WriteRegister(MFRC522::ModWidthReg, 0x26);
  rfid.PCD_WriteRegister(MFRC522::TModeReg, 0x80);
  rfid.PCD_WriteRegister(MFRC522::TPrescalerReg, 0xA9);
  rfid.PCD_WriteRegister(MFRC522::TReloadRegH, 0x03);
  rfid.PCD_WriteRegister(MFRC522::TReloadRegL, 0xE8);
  rfid.PCD_WriteRegister(MFRC522::TxASKReg, 0x40);
  rfid.PCD_WriteRegister(MFRC522::ModeReg, 0x3D);
  rfid.PCD_WriteRegister(MFRC522::GsNReg, RF_CFGS[rfIdx].gsn);   // TX түлхэлт — эргэлтээр таарна
  rfid.PCD_SetAntennaGain(RF_CFGS[rfIdx].rx);                    // RX өсгөлт — мөн адил
  rfid.PCD_AntennaOn();
  byte v = rfid.PCD_ReadRegister(MFRC522::VersionReg);
  bool ok = !(v == 0x00 || v == 0xFF);
  static uint8_t hb = 0;
  if (ok != rcOK || (++hb % 5) == 0)             // өөрчлөгдвөл / ~5с тутам heartbeat лог
    Serial.printf("[rc522] %s ver=0x%02X\n", ok ? "OK" : "УНШИХГҮЙ", v);
  rcOK = ok;
}

// ---- FT6336G touch watchdog (удаан идэвхгүйд «үхэх» → унтраа-асаагаар л
// засардаг байсан гацалтын жинхэнэ засвар) ----
// Клон touch чип idle үедээ гацдаг. Гурван давхар хамгаалалт:
//  1) Monitor (унтаа) горимыг бүрмөсөн унтраана — гацдаг шилжилт огт болохгүй
//  2) 2с тутам I2C ping — чип хариу өгөхгүй бол RST хөлөөр нь дахин асаана
//  3) 15с дараалан «дарагдсан» мэдээлбэл гацсан гэж үзэж мөн сэргээнэ
bool tpPing() {   // driver-ийн ажилладаг transactionWriteRead хэлбэрээр (клонд найдвартай)
  uint8_t reg = 0x00, v = 0;
  return lgfx::i2c::transactionWriteRead(0, 0x38, &reg, 1, &v, 1, 400000).has_value();
}
// I2C шугамын сэргээлт: гацсан боол (slave нь SDA-г доош барьсан) SCL-ийг 9 удаа
// гараар цохиж чөлөөлнө. Үүнгүйгээр ESP32-ийн I2C периферал үүрд «завгүй» хэвээр үлддэг.
void i2cBusUnstick() {
  lgfx::i2c::release(0);
  pinMode(I2C_SDA, INPUT_PULLUP);
  pinMode(I2C_SCL, OUTPUT_OPEN_DRAIN);
  digitalWrite(I2C_SCL, HIGH);
  for (int i = 0; i < 9 && digitalRead(I2C_SDA) == LOW; i++) {
    digitalWrite(I2C_SCL, LOW);  delayMicroseconds(6);
    digitalWrite(I2C_SCL, HIGH); delayMicroseconds(6);
  }
  // STOP нөхцөл (SDA нам→өндөр, SCL өндөр байхад)
  pinMode(I2C_SDA, OUTPUT_OPEN_DRAIN);
  digitalWrite(I2C_SDA, LOW);  delayMicroseconds(6);
  digitalWrite(I2C_SCL, HIGH); delayMicroseconds(6);
  digitalWrite(I2C_SDA, HIGH); delayMicroseconds(6);
  pinMode(I2C_SDA, INPUT_PULLUP);
}

// ШАТЛАСАН сэргээлт — сул аргаас эхэлж, бүтэхгүй бол улам хүчтэйрүүлнэ.
// Түвшин 0: богино RST (10ms) — ихэнх тохиолдолд хангалттай, хурдан
// Түвшин 1: урт RST (400ms) — чипийн дотоод тэжээл бүрэн тайлагдана
// Түвшин 2: I2C шугам чөлөөлөх + 1с RST — тэжээл салгахтай хамгийн ойр програмын арга
void tpRecover(const char* why) {
  const uint16_t holdMs[3] = { 10, 400, 1000 };
  uint8_t lv = tpLevel > 2 ? 2 : tpLevel;
  Serial.printf("[tp] touch сэргээв (%s) — түвшин %u\n", why, (unsigned)lv);

  if (lv >= 2) i2cBusUnstick();
  digitalWrite(CTP_RST_PIN, LOW);
  for (uint16_t t = 0; t < holdMs[lv]; t += 50) { delay(50); appAlive(); }
  digitalWrite(CTP_RST_PIN, HIGH);

  lgfx::i2c::release(0);                     // мастер тал (ESP32 I2C) гацсан бол мөн сэргээнэ
  lgfx::i2c::init(0, I2C_SDA, I2C_SCL);
  // FT6336 reset-ийн дараа ~300ms ачаалдаг — хэт эрт шалгавал «үхсэн» гэж
  // андуурч сэргээлт талаар өнгөрдөг байсан. Шатлан хүлээж шалгана.
  for (int i = 0; i < 4; i++) { delay(120); appAlive(); if (tpPing()) break; }
  wasDown = false; tpFails = 0; tpDownAt = 0; upSince = 0;
}

// ---- Картад NDEF URL бичих (утсаар шүргэхэд онооны хуудас нээгдэнэ) ----
// ⚠️ UID/лоялти БҮҮ хөндөгдөнө (block 0 үргэлж уншигдана). Зөвхөн хоосон
// (default FFFFFF түлхүүртэй) картыг форматлана; форматтай/өөр түлхүүртэйг алгасна.
static const uint8_t KEY_FF[6] = { 0xFF,0xFF,0xFF,0xFF,0xFF,0xFF };
#define NDEF_HOST MY_SRV_HOST "/check?uid="   // 0x04 = "https://" prefix авто

bool mfAuth(byte block, const uint8_t* k) {
  MFRC522::MIFARE_Key key; memcpy(key.keyByte, k, 6);
  return rfid.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, block, &key, &(rfid.uid)) == MFRC522::STATUS_OK;
}
bool mfWrite(byte block, uint8_t* d) { return rfid.MIFARE_Write(block, d, 16) == MFRC522::STATUS_OK; }
uint8_t madCrc8(const uint8_t* d, int n) {   // MAD CRC-8 (poly 0x1D, init 0xC7)
  uint8_t crc = 0xC7;
  for (int i = 0; i < n; i++) { crc ^= d[i]; for (int b = 0; b < 8; b++) crc = (crc & 0x80) ? ((crc << 1) ^ 0x1D) : (crc << 1); }
  return crc;
}
static const uint8_t KEY_NDEF[6] = { 0xD3,0xF7,0xD3,0xF7,0xD3,0xF7 };

bool cardReselect() {                 // auth алдаа/HALT-ын дараа карт руу дахин орох
  rfid.PCD_StopCrypto1();
  byte atqa[2]; byte sz = 2;
  if (rfid.PICC_WakeupA(atqa, &sz) != MFRC522::STATUS_OK) return false;
  return rfid.PICC_ReadCardSerial();
}
// Classic картаас NDEF URL-ийг УНШИЖ буцаана (бичилтийг баталгаажуулахад)
bool ndefReadClassic(String& url) {
  if (!mfAuth(4, KEY_NDEF)) return false;
  uint8_t d[48];
  for (int b = 0; b < 3; b++) {
    uint8_t t[18]; byte n = 18;
    if (rfid.MIFARE_Read(4 + b, t, &n) != MFRC522::STATUS_OK) return false;
    memcpy(d + b * 16, t, 16);
  }
  if (d[0] != 0x03 || d[2] != 0xD1 || d[5] != 0x55) return false;
  url = (d[6] == 0x04) ? "https://" : "";
  for (int i = 7; i < 48 && d[i] != 0xFE; i++) url += (char)d[i];
  return true;
}
// NTAG/Ultralight: хуудас 4-өөс NDEF уншина (auth хэрэггүй)
bool ndefReadUL(String& url) {
  uint8_t d[48]; uint8_t t[18]; byte n = 18;
  if (rfid.MIFARE_Read(4, t, &n) != MFRC522::STATUS_OK) return false;
  memcpy(d, t, 16);
  if (d[0] != 0x03 || d[2] != 0xD1 || d[5] != 0x55) return false;
  n = 18; if (rfid.MIFARE_Read(8, t, &n) == MFRC522::STATUS_OK) memcpy(d + 16, t, 16);
  n = 18; if (rfid.MIFARE_Read(12, t, &n) == MFRC522::STATUS_OK) memcpy(d + 32, t, 16);
  url = (d[6] == 0x04) ? "https://" : "";
  for (int i = 7; i < 48 && d[i] != 0xFE; i++) url += (char)d[i];
  return true;
}
bool ndefWriteUL(const uint8_t* rec, int len) {   // NTAG: хуудас 4+ рүү 4 байтаар
  for (int off = 0; off < len; off += 4) {
    uint8_t pg[4] = { 0, 0, 0, 0 };
    for (int i = 0; i < 4 && off + i < len; i++) pg[i] = rec[off + i];
    if (rfid.MIFARE_Ultralight_Write(4 + off / 4, pg, 4) != MFRC522::STATUS_OK) return false;
  }
  return true;
}

// Картад «профайл» (онооны хуудасны URL) бичих + БУЦААЖ УНШИЖ БАТАЛГААЖУУЛАХ.
// Classic (MAD+NDEF) болон NTAG/Ultralight хоёуланг дэмжинэ. Аль хэдийн
// бичигдсэн картыг дахин бичихгүй (лог дээр ✓ харуулна). UID/лоялти аюулгүй.
void provisionNdef(const String& uid) {
  String hex = uid; hex.replace(":", "");
  String path = String(NDEF_HOST) + hex;
  int plen = 1 + path.length();
  uint8_t rec[48]; int n = 0;
  rec[n++] = 0x03; rec[n++] = (uint8_t)(4 + plen);        // NDEF TLV
  rec[n++] = 0xD1; rec[n++] = 0x01; rec[n++] = (uint8_t)plen; rec[n++] = 0x55; rec[n++] = 0x04;
  for (size_t i = 0; i < path.length() && n < 46; i++) rec[n++] = path[i];
  rec[n++] = 0xFE; int used = n; while (n < 48) rec[n++] = 0;
  String cur;

  MFRC522::PICC_Type t = rfid.PICC_GetType(rfid.uid.sak);
  if (t == MFRC522::PICC_TYPE_MIFARE_UL) {                // NTAG213/215/216 гэх мэт
    if (ndefReadUL(cur)) {
      if (cur.indexOf(NDEF_HOST) >= 0 && cur.indexOf(hex) >= 0) {
        Serial.printf("[ndef] NTAG аль хэдийн зөв ✓  %s\n", cur.c_str());
        return;
      }
      // ХУУЧИН домэйн (ж: өөрчлөгдсөн хаяг) — утсаар шүргэхэд үхсэн холбоос
      // нээгдэхээс сэргийлж дарж бичнэ.
      Serial.printf("[ndef] NTAG хуучин хаягтай (%s) → шинэчилж байна\n", cur.c_str());
    }
    if (!cardReselect()) { Serial.println("[ndef] NTAG дахин сонгогдсонгүй"); return; }
    bool ok = ndefWriteUL(rec, used);
    bool ver = ok && cardReselect() && ndefReadUL(cur) && cur.indexOf(hex) >= 0;
    Serial.printf("[ndef] NTAG %s  https://%s\n",
                  ver ? "✓ бичиж БАТАЛГААЖЛАА" : (ok ? "⚠ бичсэн ч баталгаажуулалт бүтсэнгүй" : "✗ бичилт алдаа"),
                  path.c_str());
    return;
  }
  if (!(rfid.uid.sak & 0x08)) {                           // Classic биш (DESFire/банк г.м)
    Serial.printf("[ndef] %s — NDEF автоматаар бичихгүй (уншилт хэвийн)\n",
                  String(rfid.PICC_GetTypeName(t)).c_str());
    return;
  }
  // ---- Mifare Classic 1K ----
  if (ndefReadClassic(cur)) {
    if (cur.indexOf(NDEF_HOST) >= 0 && cur.indexOf(hex) >= 0) {
      Serial.printf("[ndef] аль хэдийн зөв ✓  %s\n", cur.c_str());
      return;
    }
    // ХУУЧИН домэйнтэй карт — форматлагдсан тул зөвхөн NDEF мужийг (block 4–6)
    // NDEF түлхүүрээр дарж бичнэ. MAD болон UID хөндөгдөхгүй.
    Serial.printf("[ndef] хуучин хаягтай (%s) → шинэчилж байна\n", cur.c_str());
    if (!cardReselect() || !mfAuth(4, KEY_NDEF)) {
      Serial.println("[ndef] шинэчлэх эрх авч чадсангүй");
      return;
    }
    bool uok = mfWrite(4, rec) && mfWrite(5, rec + 16) && mfWrite(6, rec + 32);
    bool uver = uok && cardReselect() && ndefReadClassic(cur) &&
                cur.indexOf(NDEF_HOST) >= 0 && cur.indexOf(hex) >= 0;
    Serial.printf("[ndef] шинэчлэлт %s  https://%s\n",
                  uver ? "✓ БАТАЛГААЖЛАА" : (uok ? "⚠ бичсэн ч баталгаажсангүй" : "✗ бичилт алдаа"),
                  path.c_str());
    return;
  }
  if (!cardReselect()) { Serial.println("[ndef] карт дахин сонгогдсонгүй"); return; }
  if (!mfAuth(3, KEY_FF)) { Serial.println("[ndef] өөр түлхүүртэй карт — алгасав (лоялти аюулгүй)"); return; }
  // MAD (sector 0): sector 1-д NDEF (AID 0x03E1)
  uint8_t mad1[16] = { 0, 0x01, 0x03, 0xE1, 0,0,0,0,0,0,0,0,0,0,0,0 };
  uint8_t mad2[16] = { 0 };
  uint8_t crcbuf[31]; crcbuf[0] = mad1[1];
  for (int i = 0; i < 14; i++) crcbuf[1 + i] = mad1[2 + i];
  for (int i = 0; i < 16; i++) crcbuf[15 + i] = mad2[i];
  mad1[0] = madCrc8(crcbuf, 31);
  uint8_t tr0[16] = { 0xA0,0xA1,0xA2,0xA3,0xA4,0xA5, 0x78,0x77,0x88, 0xC1, 0xFF,0xFF,0xFF,0xFF,0xFF,0xFF };
  if (!mfWrite(1, mad1) || !mfWrite(2, mad2) || !mfWrite(3, tr0)) { Serial.println("[ndef] MAD бичилт амжилтгүй"); return; }
  if (!mfAuth(7, KEY_FF)) { Serial.println("[ndef] sector1 auth амжилтгүй"); return; }
  bool ok = mfWrite(4, rec) && mfWrite(5, rec + 16) && mfWrite(6, rec + 32);
  uint8_t tr1[16] = { 0xD3,0xF7,0xD3,0xF7,0xD3,0xF7, 0x7F,0x07,0x88, 0x40, 0xFF,0xFF,0xFF,0xFF,0xFF,0xFF };
  ok = ok && mfWrite(7, tr1);
  // БАТАЛГААЖУУЛАЛТ: дахин сонгож, бичсэн URL-ээ буцааж уншина
  bool ver = ok && cardReselect() && ndefReadClassic(cur) && cur.indexOf(hex) >= 0;
  Serial.printf("[ndef] %s  https://%s\n",
                ver ? "✓ бичиж БАТАЛГААЖЛАА" : (ok ? "⚠ бичсэн ч баталгаажуулалт бүтсэнгүй" : "✗ бичилт алдаа"),
                path.c_str());
}

void openWifiSettings() { wui_runSetup(); wasDown = false; enterHome(); }

// ============================ setup / loop =================================
void setup() {
  setCpuFrequencyMhz(160);   // 3.3V шугамын суурь ачааллыг багасгана (touch-ийн тэжээлийн зай)
  Serial.begin(115200); delay(300);
  Serial.println("\n[MOON TERMINAL v8 · Хөвөн · 24/7] эхэллээ (CPU 160MHz)");
  pinMode(CTP_RST_PIN, OUTPUT);
  digitalWrite(CTP_RST_PIN, LOW); delay(10);
  digitalWrite(CTP_RST_PIN, HIGH); delay(300);

  lcd.init(); lcd.setRotation(1); lcd.setBrightness(225);   // ХӨНДЛӨН 320×240
  // Touch чип өмнөх гацалтаасаа NACK хийж байвал RST-ээр 3 удаа сэргээж үзнэ
  for (int i = 0; i < 3 && !tpPing(); i++) tpRecover("boot");
  Serial.printf("[tp] boot ping=%d (1=эрүүл; 0 бол тэжээлийг нэг салгаж залгаарай)\n", (int)tpPing());
  initFonts();
  drawBoot("");

  SPI.begin(RC_SCK, RC_MISO, RC_MOSI, RC_SS);
  rfid.PCD_Init(RC_SS, RC_RST); delay(40);
  byte v = rfid.PCD_ReadRegister(MFRC522::VersionReg);
  rcOK = !(v == 0x00 || v == 0xFF);
  rfLoad();                                        // сүүлд ажилласан RF хослолыг сэргээх
  rfid.PCD_WriteRegister(MFRC522::GsNReg, RF_CFGS[rfIdx].gsn);
  rfid.PCD_SetAntennaGain(RF_CFGS[rfIdx].rx);
  rfid.PCD_AntennaOff(); delay(5); rfid.PCD_AntennaOn();
  byte txc = rfid.PCD_ReadRegister(MFRC522::TxControlReg);
  Serial.printf("[rc522] ver=0x%02X ok=%d · TxControl=0x%02X %s\n", v, rcOK, txc,
                (txc & 0x03) == 0x03 ? "антенн асаалттай ✓" : "АНТЕНН УНТРААЛТТАЙ ✗ (модуль/утас шалга)");

  drawBoot("Wi-Fi холбогдож байна");
  // Сканддаг ухаалаг холболт — харагдахгүй сүлжээ рүү (ж: Redmi hotspot) сохроор оролдохгүй
  bool ok = wui_smartConnect(SEED_SSID, SEED_PASS);
  // ⚠️ ГОЛ ЗАСВАР (гацалт): өмнө нь холбогдож чадаагүй үед дэлгэцийн сонгогчийг
  // нээж, хүн ирж дарах хүртэл ТЭНД ҮҮРД зогсдог байсан — терминал асаад ажиллахгүй,
  // карт ч уншихгүй. Одоо шууд НҮҮР рүү орж ажиллаж эхэлнэ; Wi-Fi-г ард нь автоматаар
  // оролдож байдаг ба хүн хүсвэл баруун дээд Wi-Fi товчоор гараар холбоно.
  if (!ok) Serial.println("[wifi] авто холбогдсонгүй → нүүр рүү орж, ард нь оролдоно");
  Serial.printf("[wifi] final %s ip=%s\n", WiFi.status() == WL_CONNECTED ? "OK" : "FAIL",
                WiFi.localIP().toString().c_str());

  // Салсан үед драйвер өөрөө эргэж холбогдоно (loop доторх сэргээлтийг нөхнө)
  WiFi.setAutoReconnect(true);
  WiFi.persistent(true);

  // ХАРДВАР WATCHDOG — энэ мөрөөс хойш loop() 30 секунд эргэхээ болих юм бол
  // (ямар нэг дуудлага үүрд блоклосон) төхөөрөмж ӨӨРӨӨ дахин ачаална.
  // Ингэснээр «гацаад зогсчихсон» байдал бүрмөсөн арилна.
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  // ESP32 core 3.x (IDF5): TWDT-г core өөрөө асаасан байдаг тул дахин тохируулна
  esp_task_wdt_config_t wdtCfg = {
    .timeout_ms = WDT_TIMEOUT_S * 1000,
    .idle_core_mask = 0,          // idle таскуудыг хянахгүй — зөвхөн бидний loop
    .trigger_panic = true,        // хугацаа хэтэрвэл дахин ачаална
  };
  // core өөрөө TWDT-г асаасан байдаг тул эхлээд reconfigure — эс бөгөөс init
  if (esp_task_wdt_reconfigure(&wdtCfg) != ESP_OK) esp_task_wdt_init(&wdtCfg);
#else
  esp_task_wdt_init(WDT_TIMEOUT_S, true);
#endif
  esp_err_t wdtAdd = esp_task_wdt_add(NULL);
  // ESP_ERR_INVALID_ARG = энэ task аль хэдийн бүртгэлтэй (мөн зөв төлөв)
  g_wdtOn = (wdtAdd == ESP_OK || wdtAdd == ESP_ERR_INVALID_ARG);
  Serial.printf("[sys] watchdog %s (%ds, add=%d) · сул санах ой %u\n",
                g_wdtOn ? "ИДЭВХТЭЙ ✓" : "АСААГДСАНГҮЙ ✗",
                WDT_TIMEOUT_S, (int)wdtAdd, (unsigned)ESP.getFreeHeap());

  httpHello();   // сервертэй холбоог ачаалахдаа шалгаж логлоно

  enterHome();
}

// Карт уншигчийг ямар ч «амарч буй» дэлгэцээс шалгана → шинэ карт ойртуулбал
// хаанаас ч шууд тухайн картын мэдээлэл рүү үсэрнэ («уншигч үргэлж ажиллана»).
String lastUid = ""; uint32_t lastUidAt = 0;
void pollCard() {
  uint32_t now = millis();
  if (now - rcLastInit >= 700) { rcLastInit = now; rcReinit(); }    // уншигчийг амьд байлгах

  // RF ХАЙЛТ: карт уншигдаагүй байхад хослолуудыг 1.5с тутам ээлжлэн туршина.
  // Түгжигдсэн (өмнө ажилласан) хослол 90с уншихаа болиулбал хайлтыг дахин эхлүүлнэ
  // — антенн/орчин өөрчлөгдөхөд ч терминал өөрөө сэргэнэ.
  if (rcOK) {
    if (rfLocked && lastUidAt && now - lastUidAt > 90000 && now - rfSweepAt > 90000) {
      rfLocked = false;
      Serial.println("[rf] 90с карт уншаагүй — тохиргооны хайлтыг дахин эхлүүллээ");
    }
    if (!rfLocked && now - rfSweepAt >= 1500) {
      rfSweepAt = now;
      rfIdx = (rfIdx + 1) % RF_N;
      rcReinit();
      byte tx = rfid.PCD_ReadRegister(MFRC522::TxControlReg);
      Serial.printf("[rf] #%u %s · TxControl=0x%02X %s\n", rfIdx, RF_CFGS[rfIdx].name, tx,
                    (tx & 0x03) == 0x03 ? "антенн асаалттай" : "АНТЕНН УНТРААЛТТАЙ ✗");
    }
  }

  if (rcOK && now - rcLastPoll >= 60) {
    rcLastPoll = now;
    String uid = readUidRaw();
    if (uid.length()) {
      if (!rfLocked) {          // ажилласан хослолыг түгжиж, дараагийн ачаалалтад хадгална
        rfLocked = true;
        rfSave();
        Serial.printf("[rf] ✓ ТААРСАН #%u %s — түгжиж хадгаллаа\n", rfIdx, RF_CFGS[rfIdx].name);
      }
      // Уншигч дээр ОРХИСОН карт (WUPA-аар дахин сэрсэн, мөн адил UID, 15с дотор)
      // давтан скан үүсгэхгүй; картаа авч дахин ойртуулбал шууд уншина.
      if (g_viaWupa && uid == lastUid && now - lastUidAt < 15000) { cardDone(); lastUidAt = now; return; }
      lastUid = uid; lastUidAt = now;
      curUid = uid;
      provisionNdef(uid);   // хоосон карт бол URL-г нэг удаа бичнэ (баталгаажуулалттай)
      cardDone();
      rcReinit();           // скан дараа цэвэр төлөв
      startScan("balance");
    }
  }
}

void loop() {
  appAlive();   // hardware watchdog-д «би амьд» гэж мэдэгдэнэ (30с чимээгүй бол дахин асна)

  // таймаут — терминал дэлгэцүүд нүүр рүү
  uint32_t idle = millis() - screenAt;
  if ((screen == SC_MENU && idle > 120000) || (screen == SC_BALANCE && idle > 120000) ||
      (screen == SC_CONFIRM && idle > 60000) ||
      (screen == SC_UNKNOWN && idle > 25000) || (screen == SC_SENT && idle > 15000) ||
      (screen == SC_BOUND && idle > 15000)) {
    enterHome();
  }
  // СҮҮЛЧИЙН ХАМГААЛАЛТ: ямар ч дэлгэц (шинээр нэмэгдсэн ч) 3 минутаас удвал нүүр рүү.
  // Ингэснээр төхөөрөмж ямар ч тохиолдолд «гацсан дэлгэц дээр» үлдэхгүй.
  if (screen != SC_HOME && screen != SC_SAVER && screen != SC_BOOT && idle > STUCK_SCREEN_MS) {
    Serial.printf("[sys] %d дэлгэц дээр гацсан тул нүүр рүү буцлаа\n", (int)screen);
    g_scanState = 0;
    enterHome();
  }
  // 24/7: нүүрэн дээр 10 мин хүн үйлдэл хийгээгүй бол унтуулагч-анимаци руу
  if (screen == SC_HOME && millis() - lastUserAt > 600000 && idle > 3000) enterSaver();

  int32_t x, y;
  bool raw = lcd.getTouch(&x, &y);
  // ⚠️ ГОЛ ЗАСВАР: FT6336G хааяа ХИЙ (phantom) touch-ийг гаж координаттай (ж: x=-1804)
  // мэдээлдэг. Шүүхгүй бол wasDown байнга true болж, ЖИНХЭНЭ товшилтын ирмэгийг далдалж
  // → товч «ажиллахгүй/удаан» болдог. Дэлгэцийн мужаас гарсныг touch БИШ гэж үзнэ.
  if (raw && (x < 0 || x > W || y < 0 || y > H)) raw = false;

  // Богино ТАСАЛДАЛ залгих: клон чип нэг даралтын дунд 1–2 хүрээ алддаг. Үүнийг
  // «суллаад дахин дарлаа» гэж уншвал нэг даралт хоёр үйлдэл болж, дэлгэц үсэрдэг.
  bool down = raw;
  if (!raw && wasDown) {
    if (!upSince) upSince = millis();
    if (millis() - upSince < TAP_GLITCH_MS) down = true;   // хараахан суллаагүй гэж үзнэ
  }
  if (raw) upSince = 0;

  if (down) { lastUserAt = millis(); }
  bool tap = down && !wasDown; wasDown = down;
  if (millis() < wakeIgnoreUntil) tap = false;                    // сэрээсэн даралтыг залгих
  if (tap && millis() - lastTapAt < TAP_MIN_GAP_MS) tap = false;  // санамсаргүй давхар даралт
  if (tap) lastTapAt = millis();

  // DIAG: товшилт бүрийг лог (координат+дэлгэц) + давталтын хамгийн удаан хугацаа
  if (tap) Serial.printf("[touch] sc=%d x=%d y=%d\n", screen, (int)x, (int)y);
  static uint32_t dLast = 0, dMax = 0, dRep = 0;
  uint32_t dNow = millis();
  if (dLast) { uint32_t dt = dNow - dLast; if (dt > dMax) dMax = dt; }
  dLast = dNow;
  if (dNow - dRep > 5000) { dRep = dNow; Serial.printf("[loop] max=%ums\n", (unsigned)dMax); dMax = 0; }

  // TOUCH WATCHDOG — чип «үхсэн» бол унтраа-асаа хийлгүйгээр өөрөө сэргээнэ.
  // Сэргээлт бүтэхгүй бол хүчээ нэмнэ (богино RST → урт RST → I2C шугам цэвэрлэх).
  if (millis() - tpLastPing >= 800) {                       // хурдан илрүүлэлт (~1.6с)
    tpLastPing = millis();
    if (!tpPing()) {
      if (!tpDeadSince) tpDeadSince = millis();
      if (++tpFails >= 2 && (int32_t)(millis() - tpNextTryAt) >= 0) {
        tpRecover("I2C хариу алга");
        if (tpPing()) {
          tpDeadRuns = 0; tpLevel = 0; tpDeadSince = 0;
          Serial.println("[tp] сэргэлээ ✓");
        } else {
          if (tpLevel < 2) tpLevel++;                       // дараагийн удаа илүү хүчтэй арга
          if (++tpDeadRuns >= 3) {
            tpNextTryAt = millis() + 20000;                 // богино завсарлага — амьд цонх олон
            tpDeadRuns = 0;
            Serial.println("[tp] чип огт хариугүй — 20с дараа дахин оролдоно (тэжээл салгаж залгавал шууд эрүүлжинэ)");
          }
        }
      }
    } else { tpFails = 0; tpDeadRuns = 0; tpLevel = 0; tpDeadSince = 0; }
  }
  // Хамгийн сүүлчийн арга: touch удаан хугацаанд сэргэхгүй бол НЭГ удаа дахин ачаална.
  // Зөвхөн нүүрэн дээр, картын ажиллагаагүй тайван үед — хэрэглэгчийн үйлдлийг тасалдуулахгүй.
  if (tpDeadSince && !rebootedForTp && millis() - tpDeadSince > TP_DEAD_REBOOT_MS &&
      (screen == SC_HOME || screen == SC_SAVER) && millis() - lastUidAt > 60000) {
    rebootedForTp = true;
    appReboot("touch 15 мин сэргэсэнгүй");
  }
  if (down) { if (!tpDownAt) tpDownAt = millis(); else if (millis() - tpDownAt > 15000) tpRecover("15с гацсан даралт"); }
  else tpDownAt = 0;

  // WI-FI АВТОМАТ СЭРГЭЭЛТ — 24/7 ажиллагаанд салсан холболт өөрөө эргэж холбогдоно
  // (өмнө нь салвал хүн гараас сонгогч нээх хүртэл офлайн үлддэг байсан).
  if (WiFi.status() != WL_CONNECTED) {
    if (!wifiLostAt) {
      wifiLostAt = millis();
      wifiNextTry = millis() + 3000;
      Serial.println("[wifi] холболт тасарлаа — автоматаар сэргээхийг оролдоно");
    }
    if ((int32_t)(millis() - wifiNextTry) >= 0) {
      wifiNextTry = millis() + WIFI_RETRY_MS;
      wui_bgReconnect(SEED_SSID, SEED_PASS);  // блоклохгүй — үр дүнг дараагийн эргэлтэд шалгана
    }
  } else if (wifiLostAt) {
    Serial.printf("[wifi] сэргэлээ ✓ ip=%s\n", WiFi.localIP().toString().c_str());
    wifiLostAt = 0;
    httpHello();                        // сервер рүү хүрч байгааг шууд баталгаажуулна
  }
  // Топбарын Wi-Fi цэгийг төлөв ӨӨРЧЛӨГДӨХ үед л дахин зурна (анивчихгүй)
  static bool lastWifiUp = false;
  bool wifiUp = WiFi.status() == WL_CONNECTED;
  if (wifiUp != lastWifiUp) {
    lastWifiUp = wifiUp;
    if (screen != SC_BOOT && screen != SC_SAVER && screen != SC_LOADING)
      lcd.fillCircle(258, 26, 3, wifiUp ? C_SAGE : C_CLAY);
  }

  // САНАХ ОЙ — 24/7 ажиллагаанд алдагдал хуримтлагдвал өөрөө шинэчилнэ
  if (ESP.getFreeHeap() < 20000 && screen == SC_HOME) appReboot("сул санах ой дуусч байна");

  // УНТУУЛАГЧ — карт үргэлж уншина; хүрэхэд сэрнэ (топбар товчнуудаас ӨМНӨ)
  if (screen == SC_SAVER) {
    pollCard();
    if (screen != SC_SAVER) { lcd.setBrightness(225); return; }   // карт уншигдав → сэрж илгээв
    animateSaver();
    if (down) { wakeFromSaver(); return; }
    if (millis() - tpLastProactive > 300000) { tpLastProactive = millis(); tpRecover("унтаа үеийн тогтмол сэргээлт"); }
    delay(3);
    return;
  }

  // Wi-Fi — БҮХ дэлгэцээс (баруун pill)
  if (tap && screen != SC_BOOT && hit(BTN_WIFI, x, y)) { openWifiSettings(); return; }
  // Буцах — топбар зүүн pill (HOME-оос бусад). Аль ч дэлгэцээс найдвартай ухарна.
  if (tap && screen != SC_HOME && screen != SC_BOOT && hit(BTN_BACK, x, y)) {
    if (screen == SC_LOADING) { g_scanState = 0; g_scanGen++; }    // хүлээж буй scan-г цуцална
    if (screen == SC_BALANCE || screen == SC_CONFIRM) drawMenu();  // цэс рүү нэг алхам ухарна
    else enterHome();
    return;
  }

  switch (screen) {
    case SC_HOME: {
      animatePulse();
      // Дурын даралтад ШУУД хариу — «амьд» мэдрэмж: заавар товчхон анивчина.
      // (Өмнө нь картын хэсэгт дарахад юу ч болдоггүй → «мэдрэгч муу» мэт санагддаг байв)
      static uint32_t homeHintAt = 0;
      if (tap && y > 52) {
        homeHintAt = millis();
        txt("Картаа", 224, 118, F16, C_CLAY, C_CARD);
        txt("уншуулна уу", 224, 146, F16, C_CLAY, C_CARD);
      }
      if (homeHintAt && millis() - homeHintAt > 350) {
        homeHintAt = 0;
        txt("Картаа", 224, 118, F16, C_INK, C_CARD);
        txt("уншуулна уу", 224, 146, F16, C_INK, C_CARD);
      }
      pollCard();
      break;
    }
    case SC_LOADING:
      animateSpinner(160, 112, C_BG);
      if (g_scanState == 2) {                         // амжилттай
        if (!strcmp(g_intent, "service")) drawSent();
        else if (bal.mode == "bound") drawBound();
        else if (bal.known) drawMenu();
        else drawUnknown(g_uid);
        g_scanState = 0;
      } else if (g_scanState == 3) {                  // алдаа
        enterHome();
        txt("Сүлжээ алдаа — дахин уншуулна уу", 160, 226, F11, C_CLAY, C_BG);
        g_scanState = 0;
      } else if (millis() - screenAt > 12000) {       // BACKSTOP: task гацвал ч дэлгэц гацахгүй
        g_scanState = 0; g_scanGen++;
        enterHome();
        txt("Сүлжээ удаан байна — дахин уншуулна уу", 160, 226, F11, C_CLAY, C_BG);
      }
      break;
    case SC_MENU:
      pollCard();   // цэсэн дээр ч шинэ карт ойртуулбал уншина
      // Товчнуудын муж өгөөмөр — ГЭХДЭЭ мэндчилгээ/маскот/hint дээр дарахад
      // санамсаргүй үйлдэл гарахгүй (зөвхөн жинхэнэ 2 товч л ажиллана).
      if (tap && y >= 124 && y <= 214) {                 // 2 товчны бүс (зэрэгцээ)
        if (x < 160) { pressFx(24, 138, 130, 56, 28); drawBalance(); }   // «Үлдэгдэл» (зүүн)
        else { pressFx(166, 138, 130, 56, 28); drawConfirm(); }          // «Үйлчилгээ» (баруун)
      }
      break;
    case SC_CONFIRM:
      pollCard();   // баталгаажуулах үед ч өөр карт ойртуулбал уншина
      if (tap && y >= 158) {                 // доод 2 товчны муж (өгөөмөр)
        if (x < 160) { pressFx(28, 170, 124, 54, 26); drawMenu(); }      // Үгүй → цэс рүү буц
        else { pressFx(168, 170, 124, 54, 26); startScan("service"); }   // Тийм → илгээх
      }
      break;
    case SC_BALANCE:
      pollCard();   // үлдэгдэл харж байхад ч шинэ карт ойртуулбал уншина
      break;
    case SC_UNKNOWN: case SC_SENT: case SC_BOUND:
      pollCard();
      if (tap) enterHome();
      break;
    default: break;
  }
  delay(3);
}
