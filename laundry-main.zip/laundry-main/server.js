// Moon Laundry — лоялти ба удирдлагын систем
'use strict';

const path = require('node:path');
const express = require('express');

const { ensureDefaultAdmin, cleanupSessions } = require('./src/auth');
const publicRoutes = require('./src/routes/public');
const adminRoutes = require('./src/routes/admin');
const deviceRoutes = require('./src/routes/device');

const app = express();
app.disable('x-powered-by');
// nginx зэрэг reverse proxy-гийн ард ажиллана — req.ip, req.secure зөв болно
app.set('trust proxy', 1);

// Аюулгүй байдлын толгойнууд (гадны сан ашиглахгүй)
const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src 'self' https://fonts.gstatic.com",
  "img-src 'self' data: blob:",
  "connect-src 'self'",
  "frame-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'self'",
  'upgrade-insecure-requests',
].join('; ');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-XSS-Protection', '0');
  // Хөтчийн эмзэг чадваруудыг хаах (энэ сайтад хэрэггүй)
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', CSP);
  if (req.secure) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  next();
});

app.use(express.json({ limit: '200kb' }));

app.use('/api/public', publicRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/device', deviceRoutes);

// Админ SPA — static-аас ӨМНӨ (эс бөгөөс лавлах руу 301 redirect хийж нэмэлт эргэлт үүсгэнэ)
app.get(['/admin', '/admin/'], (req, res) =>
  res.sendFile(path.join(__dirname, 'public', 'admin', 'index.html'))
);

app.use(
  express.static(path.join(__dirname, 'public'), {
    extensions: ['html'],
    etag: true,
    lastModified: true,
    redirect: false,
    setHeaders(res, filePath) {
      // HTML — үргэлж шинэчилж шалгуулна (deploy хийсэн дор шинэ агуулга шууд харагдана).
      // Бусад статик (css/js/img) — 5 мин кэш + ETag revalidate (давтан ачаалал хурдан).
      res.setHeader('Cache-Control', filePath.endsWith('.html') ? 'no-cache' : 'public, max-age=300');
    },
  })
);

app.use('/api', (req, res) => res.status(404).json({ error: 'Ийм зам олдсонгүй' }));

// Алдааны нэгдсэн боловсруулалт
app.use((err, req, res, next) => {
  const status = err.status || err.statusCode || 500;
  if (status >= 500) console.error(err);
  // Дотоод/parser алдааны техник мессежийг задлахгүй; өөрсдийн Монгол алдааг л харуулна
  const msg =
    status >= 500 ? 'Серверийн алдаа гарлаа'
    : typeof err.type === 'string' ? 'Хүсэлтийн формат буруу байна'
    : err.message || 'Буруу хүсэлт';
  res.status(status).json({ error: msg });
});

ensureDefaultAdmin();
cleanupSessions();

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '127.0.0.1';
app.listen(PORT, HOST, () => {
  console.log(`✓ Moon Laundry систем: http://${HOST}:${PORT}`);
  console.log(`  Нүүр:        http://${HOST}:${PORT}/`);
  console.log(`  Бонус шалгах: http://${HOST}:${PORT}/check`);
  console.log(`  Админ:       http://${HOST}:${PORT}/admin`);
});
