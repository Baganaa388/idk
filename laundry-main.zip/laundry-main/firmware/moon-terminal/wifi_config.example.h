// Загвар: энэ файлыг хуулж "wifi_config.h" болгоод өөрийн утгаар солино.
// wifi_config.h нь git-д орохгүй (нууц үг агуулна).
#define MY_WIFI_SSID "WIFI-НЭР"
#define MY_WIFI_PASS "WIFI-НУУЦ-ҮГ"
// Серверийн түлхүүр: админ → GET /api/admin/device/key
#define MY_DEV_KEY   "СЕРВЕРИЙН-DEVICE-KEY"
