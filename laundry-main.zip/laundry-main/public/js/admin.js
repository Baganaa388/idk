// Админ удирдлагын SPA — hash router, Chart.js график, live баримт.
// Бүх хэрэглэгчийн өгөгдөл esc()-ээр дамжиж DOM-д орно.
'use strict';

/* ================= Global ================= */
const PAL = ['#0284C7', '#D97706', '#7C3AED', '#E11D48', '#94A3B8'];
const WEEKDAYS = ['Да', 'Мя', 'Лх', 'Пү', 'Ба', 'Бя', 'Ня'];
const state = { user: null, rules: null };
let charts = [];

Chart.defaults.font.family = "'Inter', 'Segoe UI', sans-serif";
Chart.defaults.font.size = 12;
Chart.defaults.color = '#46586E';
Chart.defaults.plugins.legend.display = false;
Object.assign(Chart.defaults.plugins.tooltip, {
  backgroundColor: '#0F172A',
  padding: 11,
  cornerRadius: 9,
  titleFont: { family: "'Inter', sans-serif", weight: '600' },
  bodyFont: { family: "'Inter', sans-serif" },
  displayColors: false,
});

function makeChart(canvas, cfg) {
  const c = new Chart(canvas, cfg);
  charts.push(c);
  return c;
}
function destroyCharts() {
  charts.forEach((c) => c.destroy());
  charts = [];
}
const compact = (v) =>
  v >= 1_000_000 ? `${+(v / 1_000_000).toFixed(1)}сая` : v >= 1000 ? `${+(v / 1000).toFixed(0)}мян` : v;

function areaGradient(ctx, color) {
  const { chartArea, ctx: c } = ctx.chart;
  if (!chartArea) return 'rgba(2,132,199,.08)';
  const g = c.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
  g.addColorStop(0, color + '3D');
  g.addColorStop(1, color + '00');
  return g;
}

/* ================= Modal ================= */
function openModal(title, bodyHtml) {
  const host = $('#modalHost');
  host.innerHTML = `
    <div class="modal-back" id="modalBack">
      <div class="modal" role="dialog" aria-modal="true">
        <div class="modal__head">
          <h3>${esc(title)}</h3>
          <button class="btn btn--icon btn--ghost" id="modalX">${ICONS.x}</button>
        </div>
        <div class="modal__body">${bodyHtml}</div>
      </div>
    </div>`;
  $('#modalX').onclick = closeModal;
  $('#modalBack').addEventListener('mousedown', (e) => { if (e.target.id === 'modalBack') closeModal(); });
  return host;
}
function closeModal() { $('#modalHost').innerHTML = ''; }

function confirmModal(msg, { danger = 'Тийм, үргэлжлүүлэх', onYes }) {
  openModal('Баталгаажуулах', `
    <p style="color:var(--ink-2);font-size:14.5px">${msg}</p>
    <div style="display:flex;gap:10px;justify-content:flex-end">
      <button class="btn btn--ghost" id="cfNo">Болих</button>
      <button class="btn btn--danger" id="cfYes">${esc(danger)}</button>
    </div>`);
  $('#cfNo').onclick = closeModal;
  $('#cfYes').onclick = async () => {
    $('#cfYes').disabled = true;
    try { await onYes(); closeModal(); }
    catch (e) { toast(e.message, 'err'); $('#cfYes').disabled = false; }
  };
}

/* ================= Boot ================= */
$$('[data-ic]').forEach((el) => { el.innerHTML = ICONS[el.dataset.ic] || ''; });

const TITLES = {
  dashboard: 'Хяналтын самбар', service: 'Үйлчилгээ бүртгэх', customers: 'Хэрэглэгчид',
  promos: 'Промо код', vouchers: 'Эрхийн бичиг', reports: 'Тайлан ба аналитик', settings: 'Тохиргоо',
};

async function boot() {
  try {
    const me = await api('/api/admin/me');
    state.user = me.username;
    await enterApp();
  } catch {
    showLogin();
  }
}

function showLogin() {
  $('#appView').hidden = true;
  $('#loginView').hidden = false;
  api('/api/public/site').then(({ business }) => {
    $('#loginBizName').textContent = business.name;
    document.title = `Удирдлага — ${business.name}`;
  }).catch(() => {});
  $('#loginForm').onsubmit = async (e) => {
    e.preventDefault();
    const btn = $('#loginBtn');
    btn.disabled = true; btn.textContent = 'Нэвтэрч байна…';
    $('#loginError').hidden = true;
    try {
      const r = await api('/api/admin/login', {
        method: 'POST',
        body: { username: $('#loginUser').value.trim(), password: $('#loginPass').value },
      });
      state.user = r.username;
      await enterApp();
    } catch (err) {
      $('#loginError').textContent = err.message;
      $('#loginError').hidden = false;
    } finally {
      btn.disabled = false; btn.textContent = 'Нэвтрэх';
    }
  };
}

async function enterApp() {
  $('#loginView').hidden = true;
  $('#appView').hidden = false;
  $('#userName').textContent = state.user;
  $('#userAvatar').textContent = state.user[0] || 'A';

  state.rules = await api('/api/admin/rules');
  ensureLogoUri(); // логог урьдчилан кэшлэх (эрхийн бичиг шуурхай нээгдэнэ)
  $$('[data-biz-name]').forEach((el) => (el.textContent = state.rules.business.name));
  document.title = `Удирдлага — ${state.rules.business.name}`;

  const d = new Date();
  const wd = ['Ням', 'Даваа', 'Мягмар', 'Лхагва', 'Пүрэв', 'Баасан', 'Бямба'][d.getDay()];
  $('#topDate').textContent = `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, '0')}.${String(d.getDate()).padStart(2, '0')}, ${wd}`;

  $('#logoutBtn').onclick = async () => {
    await api('/api/admin/logout', { method: 'POST' }).catch(() => {});
    location.reload();
  };
  $('#burger').onclick = () => $('#sidebar').classList.toggle('open');
  $$('#sideNav a').forEach((a) => a.addEventListener('click', () => $('#sidebar').classList.remove('open')));

  window.onhashchange = route;
  if (!location.hash) location.hash = '#/dashboard';
  else route();
  startDeviceWatch();
}

/* ================= NFC / төхөөрөмж ================= */
const NFC_ICON =
  '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M7 9.5c1.7 1.5 1.7 4.5 0 6"/><path d="M10 8c2.6 2 2.6 6 0 8"/></svg>';

// Канон hex UID-г A3:2F:1B:04 хэлбэрт
function fmtUid(canon) {
  const s = String(canon || '').toUpperCase();
  return (s.match(/.{1,2}/g) || [s]).join(':');
}

let deviceWatchOn = false;
let lastSeenScanAt = 0;
// Төхөөрөмж дээр "Үйлчилгээ авах"-аар карт уншуулбал админд мэдэгдэнэ
function startDeviceWatch() {
  if (deviceWatchOn) return;
  deviceWatchOn = true;
  setInterval(async () => {
    try {
      const d = await api('/api/admin/device/last-scan');
      const s = d && d.scan;
      if (s && s.intent === 'service' && s.phone && s.at !== lastSeenScanAt && s.age_ms < 20000) {
        lastSeenScanAt = s.at;
        showDeviceScanBanner(s);
      }
    } catch (_) {}
  }, 3000);
}

function showDeviceScanBanner(s) {
  let el = $('#deviceScanBanner');
  if (!el) {
    el = document.createElement('div');
    el.id = 'deviceScanBanner';
    el.className = 'device-scan-banner';
    document.body.appendChild(el);
  }
  el.innerHTML = `
    <div class="dsb-card">
      <span class="device-scan-banner__dot"></span>
      <p class="dsb-title">Үйлчилгээний хүсэлт</p>
      <div class="dsb-name">${esc(s.name || fmtPhone(s.phone))}</div>
      <div class="dsb-phone num">${fmtPhone(s.phone)}</div>
      <div class="dsb-actions">
        <a class="btn btn--primary btn--lg" href="#/service?phone=${esc(s.phone)}" id="dsbGo">Бүртгэх</a>
        <button class="btn btn--ghost btn--lg" id="dsbClose">Хаах</button>
      </div>
    </div>`;
  el.classList.add('show');
  $('#dsbClose').onclick = () => el.classList.remove('show');
  $('#dsbGo').onclick = () => el.classList.remove('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 30000);
}

/* ================= Router ================= */
async function route() {
  const hash = location.hash.slice(2) || 'dashboard';
  const [pathPart, queryPart] = hash.split('?');
  const parts = pathPart.split('/');
  const name = parts[0] || 'dashboard';
  const params = new URLSearchParams(queryPart || '');

  $$('#sideNav a').forEach((a) => a.classList.toggle('active', a.dataset.route === name));
  $('#pageTitle').textContent = TITLES[name] || TITLES.dashboard;
  $('.topbar__quick').style.display = name === 'service' ? 'none' : '';

  destroyCharts();
  const view = $('#view');
  view.innerHTML = '<div class="empty"><p>Ачаалж байна…</p></div>';
  try {
    if (name === 'dashboard') await vDashboard(view);
    else if (name === 'service') await vService(view, params);
    else if (name === 'customers' && parts[1]) await vCustomerDetail(view, parts[1]);
    else if (name === 'customers') await vCustomers(view);
    else if (name === 'promos') await vPromos(view);
    else if (name === 'vouchers') await vVouchers(view);
    else if (name === 'reports') await vReports(view, params.get('g') || 'day');
    else if (name === 'settings') await vSettings(view);
    else await vDashboard(view);
  } catch (e) {
    if (e.status === 401) { showLogin(); return; }
    view.innerHTML = `<div class="empty">${ICONS.alert}<p>${esc(e.message)}</p></div>`;
  }
}

/* ================= Dashboard ================= */
async function vDashboard(view) {
  const d = await api('/api/admin/dashboard');
  view.innerHTML = `
    <div class="stats">
      <div class="card stat">
        <span class="stat__ic">${ICONS.coin}</span>
        <span class="stat__label">Өнөөдрийн орлого</span>
        <span class="stat__value num">${fmtT(d.today.revenue)}</span>
        <span class="stat__sub num">${d.today.cnt} үйлчилгээ</span>
      </div>
      <div class="card stat">
        <span class="stat__ic">${ICONS.calendar}</span>
        <span class="stat__label">Энэ сарын орлого</span>
        <span class="stat__value num">${fmtT(d.month.revenue)}</span>
        <span class="stat__sub num">${d.month.cnt} үйлчилгээ</span>
      </div>
      <div class="card stat">
        <span class="stat__ic">${ICONS.users}</span>
        <span class="stat__label">Нийт хэрэглэгч</span>
        <span class="stat__value num">${fmtNum(d.customers)}</span>
        <span class="stat__sub">Энэ сард <b>+${d.new_customers} шинэ</b></span>
      </div>
      <div class="card stat">
        <span class="stat__ic">${ICONS.washer}</span>
        <span class="stat__label">Өнөөдрийн үйлчилгээ</span>
        <span class="stat__value num">${d.today.cnt}</span>
        <span class="stat__sub num">Дундаж ${fmtT(d.today.cnt ? d.today.revenue / d.today.cnt : 0)}</span>
      </div>
    </div>

    <div class="grid-23">
      <div class="card">
        <div class="card__head"><h2>Орлого — сүүлийн 30 өдөр</h2></div>
        <div class="card__body"><div class="chart-box"><canvas id="chRev"></canvas></div></div>
      </div>
      <div class="card">
        <div class="card__head"><h2>Үйлчилгээний тоо</h2></div>
        <div class="card__body"><div class="chart-box"><canvas id="chCnt"></canvas></div></div>
      </div>
    </div>

    <div class="card">
      <div class="card__head">
        <h2>Сүүлийн бүртгэлүүд</h2>
        <div class="spacer"></div>
        <a class="btn btn--soft btn--sm" href="#/reports">Тайлан харах ${ICONS.arrow}</a>
      </div>
      <div class="card__body--flush tbl-wrap">
        <table class="tbl">
          <thead><tr><th>Огноо</th><th>Хэрэглэгч</th><th>Үйлчилгээ</th><th>Төлбөр</th><th class="r">Дүн</th><th class="r">Оноо</th></tr></thead>
          <tbody>
            ${d.recent.map((t) => `
              <tr>
                <td class="num nowrap muted">${fmtDT(t.date)}</td>
                <td><b>${esc(t.name || fmtPhone(t.customer_phone))}</b><div class="muted num">${fmtPhone(t.customer_phone)}</div></td>
                <td>${esc(t.service_type)}</td>
                <td><span class="pay-tag pay-tag--${esc(t.payment_method)}"><i></i>${esc(t.payment_method)}</span></td>
                <td class="r strong num">${fmtT(t.amount)}</td>
                <td class="r num">${t.points_redeemed > 0
                  ? `<span class="chip chip--warn">−${t.points_redeemed}</span>`
                  : `<span class="chip chip--ok">+${t.points_earned}</span>`}</td>
              </tr>`).join('') || `<tr><td colspan="6"><div class="empty">${ICONS.washer}<p>Бүртгэл алга байна</p></div></td></tr>`}
          </tbody>
        </table>
      </div>
    </div>`;

  const labels = d.series.map((r) => r.p.slice(5).replace('-', '.'));
  makeChart($('#chRev'), {
    type: 'line',
    data: {
      labels,
      datasets: [{
        data: d.series.map((r) => r.revenue),
        borderColor: PAL[0], borderWidth: 2, tension: 0.35,
        pointRadius: 0, pointHoverRadius: 4.5, pointHoverBackgroundColor: PAL[0],
        fill: true, backgroundColor: (ctx) => areaGradient(ctx, PAL[0]),
      }],
    },
    options: {
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: { tooltip: { callbacks: { label: (c) => ` ${fmtT(c.parsed.y)}` } } },
      scales: {
        x: { grid: { display: false }, ticks: { maxTicksLimit: 8 } },
        y: { border: { display: false }, grid: { color: '#EEF2F6' }, ticks: { callback: (v) => compact(v), maxTicksLimit: 6 }, beginAtZero: true },
      },
    },
  });
  makeChart($('#chCnt'), {
    type: 'bar',
    data: {
      labels,
      datasets: [{ data: d.series.map((r) => r.cnt), backgroundColor: PAL[0] + 'CC', hoverBackgroundColor: PAL[0], borderRadius: 4, maxBarThickness: 14 }],
    },
    options: {
      maintainAspectRatio: false,
      plugins: { tooltip: { callbacks: { label: (c) => ` ${c.parsed.y} үйлчилгээ` } } },
      scales: {
        x: { grid: { display: false }, ticks: { maxTicksLimit: 6 } },
        y: { border: { display: false }, grid: { color: '#EEF2F6' }, ticks: { precision: 0, maxTicksLimit: 5 }, beginAtZero: true },
      },
    },
  });
}

/* ================= Үйлчилгээ бүртгэх ================= */
async function vService(view, params) {
  const services = state.rules.services;
  const loyalty = state.rules.loyalty;
  const svc = {
    phone: '', customer: null, notFound: false, name: '',
    qty: services.map(() => 0), manual: 0,
    promo: '', voucher: '', redeem: false, rewardPoints: null,
    payment: 'Бэлэн', note: '',
    quote: null, saving: false,
  };

  view.innerHTML = `
    <div class="svc-layout">
      <div style="display:grid;gap:20px">
        <div class="card">
          <div class="card__head"><h2>1 · Хэрэглэгч</h2></div>
          <div class="card__body form-grid">
            <div class="field">
              <label for="svcPhone">Утасны дугаар</label>
              <input class="input input--lg num" id="svcPhone" type="tel" inputmode="numeric" maxlength="8" placeholder="99123456" autocomplete="off">
            </div>
            <div id="custBox"></div>
          </div>
        </div>

        <div class="card">
          <div class="card__head"><h2>2 · Үйлчилгээ сонгох</h2></div>
          <div class="card__body">
            ${services.map((s, i) => `
              <div class="qty-row">
                <span class="qty-row__name">${esc(s.name)}</span>
                <span class="qty-row__price num">${fmtT(s.price)}</span>
                <span class="stepper">
                  <button type="button" data-minus="${i}" aria-label="Хасах">−</button>
                  <b class="num" id="qty${i}">0</b>
                  <button type="button" data-plus="${i}" aria-label="Нэмэх">+</button>
                </span>
              </div>`).join('')}
            <div class="qty-row">
              <span class="qty-row__name">Бусад / гараар дүн</span>
              <input class="input num" id="svcManual" type="number" min="0" step="500" placeholder="0₮" style="max-width:150px">
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card__head"><h2>3 · Хөнгөлөлт ба төлбөр</h2></div>
          <div class="card__body form-grid">
            <div class="form-row">
              <div class="field">
                <label for="svcPromo">Промо код</label>
                <input class="input" id="svcPromo" placeholder="ЖИШ: WELCOME10" autocomplete="off" style="text-transform:uppercase">
              </div>
              <div class="field">
                <label for="svcVoucher">Эрхийн бичиг</label>
                <input class="input num" id="svcVoucher" placeholder="MOON-XXXX-XXXX" autocomplete="off" style="text-transform:uppercase">
              </div>
            </div>
            <div class="field">
              <label for="svcDate">Огноо</label>
              <input class="input num" id="svcDate" type="datetime-local">
            </div>
            <div id="redeemBox"></div>
            <div class="field">
              <label>Төлбөрийн хэлбэр</label>
              <div class="seg" id="paySeg">
                ${['Бэлэн', 'Карт', 'Данс'].map((p) => `<button type="button" data-pay="${p}" class="${p === 'Бэлэн' ? 'active' : ''}">${p}</button>`).join('')}
              </div>
            </div>
            <div class="field">
              <label for="svcNote">Тэмдэглэл <span style="font-weight:400;color:var(--ink-3)">(заавал биш)</span></label>
              <input class="input" id="svcNote" maxlength="200" placeholder="Жиш: хөнжил, том ачаалал…">
            </div>
          </div>
        </div>
      </div>

      <div class="receipt" id="receiptCol"></div>
    </div>

    <div class="card">
      <div class="card__head">
        <h2>Өнөөдрийн бүртгэл</h2>
        <div class="spacer"></div>
        <span class="chip" id="journalTotal"></span>
      </div>
      <div class="card__body--flush tbl-wrap" id="journalBox"></div>
    </div>`;

  const phoneInput = $('#svcPhone');
  if (params.get('phone')) phoneInput.value = params.get('phone');

  // Одоогийн огноо datetime-local формат
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  $('#svcDate').value = now.toISOString().slice(0, 16);

  /* ---- Хэрэглэгч хайх ---- */
  const lookup = debounce(async () => {
    const p = phoneInput.value.replace(/\D/g, '');
    svc.phone = p;
    svc.customer = null; svc.notFound = false; svc.redeem = false;
    if (p.length === 8) {
      try {
        const r = await api(`/api/admin/customers/${p}`);
        svc.customer = r.customer;
      } catch { svc.notFound = true; }
    }
    renderCust(); refreshQuote();
  }, 280);
  phoneInput.addEventListener('input', () => {
    phoneInput.value = phoneInput.value.replace(/\D/g, '').slice(0, 8);
    lookup();
  });

  function renderCust() {
    const box = $('#custBox');
    if (svc.customer) {
      const c = svc.customer;
      const eligible = c.points >= loyalty.reward_threshold;
      box.innerHTML = `
        <div class="cust-hit">
          <span class="cust-hit__avatar">${esc((c.name || c.phone)[0].toUpperCase())}</span>
          <div class="cust-hit__info">
            <b>${esc(c.name || 'Нэргүй хэрэглэгч')}</b> ${tierBadge(c.tier, tierName(c.tier))}
            <p class="num">${fmtPhone(c.phone)} · ${c.points} оноо · ${c.total_visits} ирэлт</p>
          </div>
          ${eligible ? `<span class="chip chip--ok">${ICONS.gift} Урамшуулалтай!</span>` : ''}
        </div>`;
    } else if (svc.notFound) {
      box.innerHTML = `
        <div class="cust-hit cust-hit--new">
          <span class="cust-hit__avatar">+</span>
          <div class="cust-hit__info">
            <b>Шинэ хэрэглэгч</b>
            <p>Энэ дугаар бүртгэлгүй — хадгалахад автоматаар бүртгэгдэнэ.</p>
          </div>
          <input class="input" id="newName" placeholder="Нэр (заавал биш)" style="max-width:170px">
        </div>`;
      $('#newName').addEventListener('input', (e) => { svc.name = e.target.value; });
    } else {
      box.innerHTML = `<p class="hint">Дугаар оруулахад хэрэглэгчийн мэдээлэл энд гарна.</p>`;
    }
    renderRedeem();
  }

  function renderRedeem() {
    const box = $('#redeemBox');
    const c = svc.customer;
    const rtiers = rewardTiersOf(loyalty);
    const affordable = c ? rtiers.filter((t) => c.points >= t.points) : [];
    if (!affordable.length) { box.innerHTML = ''; svc.redeem = false; svc.rewardPoints = null; return; }
    // Анхдагчаар эдэлж болох дээд шатыг сонгоно
    if (svc.rewardPoints == null || !affordable.some((t) => t.points === svc.rewardPoints)) {
      svc.rewardPoints = affordable[affordable.length - 1].points;
    }
    box.innerHTML = `
      <label class="toggle">
        <input type="checkbox" id="redeemChk" ${svc.redeem ? 'checked' : ''}>
        <span class="toggle__track"></span>
        <span><b>Урамшуулал эдлэх</b>
          <span class="hint" style="display:block">${c.points} оноотой — доорхоос сонгоно</span>
        </span>
      </label>
      <div id="rewardChoices" class="reward-choices"${svc.redeem ? '' : ' hidden'}>
        ${affordable.map((t) => `
          <label class="reward-choice${svc.rewardPoints === t.points ? ' active' : ''}">
            <input type="radio" name="rwd" value="${t.points}" ${svc.rewardPoints === t.points ? 'checked' : ''}>
            <b>${esc(t.title)}</b>
            <span class="num">−${t.points} оноо · ${fmtT(t.value)} хүртэл</span>
          </label>`).join('')}
      </div>`;
    $('#redeemChk').addEventListener('change', (e) => {
      svc.redeem = e.target.checked;
      const rc = $('#rewardChoices'); if (rc) rc.hidden = !svc.redeem;
      refreshQuote();
    });
    $$('#rewardChoices input[name="rwd"]').forEach((r) =>
      r.addEventListener('change', (e) => {
        svc.rewardPoints = +e.target.value;
        $$('#rewardChoices .reward-choice').forEach((l) => l.classList.toggle('active', l.querySelector('input').checked));
        refreshQuote();
      })
    );
  }

  /* ---- Тоо хэмжээ ---- */
  // #view биш шинээр үүссэн элемент дээр listener залгана (давхардахаас сэргийлж)
  $('.svc-layout', view).addEventListener('click', (e) => {
    const plus = e.target.closest('[data-plus]');
    const minus = e.target.closest('[data-minus]');
    if (plus) { const i = +plus.dataset.plus; svc.qty[i]++; $(`#qty${i}`).textContent = svc.qty[i]; refreshQuote(); }
    if (minus) { const i = +minus.dataset.minus; svc.qty[i] = Math.max(0, svc.qty[i] - 1); $(`#qty${i}`).textContent = svc.qty[i]; refreshQuote(); }
    const pay = e.target.closest('[data-pay]');
    if (pay) {
      svc.payment = pay.dataset.pay;
      $$('#paySeg button').forEach((b) => b.classList.toggle('active', b === pay));
      renderReceipt();
    }
  });
  $('#svcManual').addEventListener('input', (e) => { svc.manual = Math.max(0, +e.target.value || 0); refreshQuote(); });
  $('#svcPromo').addEventListener('input', debounce((e) => { svc.promo = e.target.value.trim().toUpperCase(); refreshQuote(); }, 350));
  $('#svcVoucher').addEventListener('input', debounce((e) => { svc.voucher = e.target.value.trim().toUpperCase(); refreshQuote(); }, 350));
  $('#svcNote').addEventListener('input', (e) => { svc.note = e.target.value; });

  function buildItems() {
    const items = services
      .map((s, i) => ({ name: s.name, qty: svc.qty[i], price: s.price }))
      .filter((it) => it.qty > 0);
    if (svc.manual > 0) items.push({ name: 'Бусад', qty: 1, price: svc.manual });
    return items;
  }

  /* ---- Тооцоо ---- */
  const refreshQuote = debounce(async () => {
    const items = buildItems();
    if (!items.length) { svc.quote = null; renderReceipt(); return; }
    try {
      const r = await api('/api/admin/quote', {
        method: 'POST',
        body: {
          phone: svc.phone,
          items,
          promo_code: svc.promo || undefined,
          voucher_code: svc.voucher || undefined,
          redeem: svc.redeem,
          reward_points: svc.redeem ? svc.rewardPoints : undefined,
        },
      });
      svc.quote = r.quote;
    } catch { svc.quote = null; }
    renderReceipt();
  }, 200);

  function renderReceipt() {
    const q = svc.quote;
    const col = $('#receiptCol');
    const canSave = q && q.ok !== false && q.subtotal > 0 && svc.phone.length === 8 && !svc.saving;
    col.innerHTML = `
      <div class="receipt__paper">
        <div class="receipt__head">${ICONS.receipt}<b>ТООЦООНЫ БАРИМТ</b></div>
        <div class="receipt__body">
          ${!q || !q.subtotal ? `<p class="hint" style="text-align:center;padding:16px 0">Үйлчилгээгээ сонгоход<br>тооцоо энд гарна.</p>` : `
            ${(q.items || []).map((it) => `
              <div class="receipt__row"><span>${esc(it.name)}${it.qty > 1 ? ` ×${it.qty}` : ''}</span><b class="num">${fmtT(it.qty * it.price)}</b></div>`).join('')}
            <div class="receipt__row"><span>Нийт дүн</span><b class="num">${fmtT(q.subtotal)}</b></div>
            ${q.tier.discount > 0 ? `<div class="receipt__row receipt__row--disc"><span>${esc(q.tier.name)} түвшин −${q.tier.pct}%</span><b class="num">−${fmtT(q.tier.discount)}</b></div>` : ''}
            ${q.card_bonus ? `<div class="receipt__row receipt__row--disc"><span>Картын бонус −${q.card_bonus.pct}%</span><b class="num">−${fmtT(q.card_bonus.discount)}</b></div>` : ''}
            ${q.promo ? `<div class="receipt__row receipt__row--disc"><span>Промо ${esc(q.promo.code)}</span><b class="num">−${fmtT(q.promo.discount)}</b></div>` : ''}
            ${q.voucher ? `<div class="receipt__row receipt__row--disc"><span>Эрхийн бичиг ${esc(q.voucher.code)}</span><b class="num">−${fmtT(q.voucher.discount)}</b></div>` : ''}
            ${q.redeem ? `<div class="receipt__row receipt__row--disc"><span>${esc(q.redeem.title)} (−${q.redeem.points} оноо)</span><b class="num">−${fmtT(q.redeem.discount)}</b></div>` : ''}
            <div class="receipt__total"><span>ТӨЛӨХ ДҮН</span><b class="num">${fmtT(q.total)}</b></div>
            ${q.points_earned > 0 ? `<span class="receipt__pts">${ICONS.sparkle}+${q.points_earned} оноо цуглуулна</span>` : ''}
            ${(q.errors || []).map((er) => `<p class="error-text receipt__err">${esc(er)}</p>`).join('')}
          `}
          <button class="btn btn--primary btn--lg receipt__save" id="saveTx" ${canSave ? '' : 'disabled'}>
            ${svc.saving ? 'Хадгалж байна…' : 'Бүртгэх'}
          </button>
          <p class="hint" style="margin-top:10px;text-align:center">Төлбөр: <b>${esc(svc.payment)}</b></p>
        </div>
      </div>`;
    const btn = $('#saveTx');
    if (btn) btn.onclick = save;
  }

  async function save() {
    if (svc.saving) return;
    svc.saving = true; renderReceipt();
    try {
      const r = await api('/api/admin/transactions', {
        method: 'POST',
        body: {
          phone: svc.phone,
          name: svc.name,
          create_if_missing: true,
          items: buildItems(),
          promo_code: svc.promo || undefined,
          voucher_code: svc.voucher || undefined,
          redeem: svc.redeem,
          reward_points: svc.redeem ? svc.rewardPoints : undefined,
          payment_method: svc.payment,
          date: $('#svcDate').value.replace('T', ' '),
          note: svc.note,
        },
      });
      const c = r.customer;
      toast(`Бүртгэгдлээ — ${c.name || fmtPhone(c.phone)}: одоо ${c.points} оноотой`);
      $('#receiptCol').innerHTML = `
        <div class="receipt__paper"><div class="success-pane">
          <span class="success-pane__ic">${ICONS.check}</span>
          <h3>Амжилттай бүртгэгдлээ</h3>
          <p><b>${esc(c.name || fmtPhone(c.phone))}</b> · ${fmtT(r.transaction.amount)} төлөв<br>
             Одоо <b>${c.points} оноотой</b> (${esc(tierName(c.tier))})</p>
          <button class="btn btn--primary btn--lg" style="margin-top:18px" id="nextTx">Дараагийн бүртгэл</button>
        </div></div>`;
      $('#nextTx').onclick = () => route();
      loadJournal();
    } catch (e) {
      svc.saving = false;
      toast(e.message, 'err');
      renderReceipt();
    }
  }

  /* ---- Өнөөдрийн бүртгэл ---- */
  async function loadJournal() {
    const j = await api('/api/admin/transactions');
    $('#journalTotal').innerHTML = `Өдрийн нийт: <b class="num" style="margin-left:4px">${fmtT(j.total)}</b>`;
    $('#journalBox').innerHTML = j.rows.length ? `
      <table class="tbl">
        <thead><tr><th>Цаг</th><th>Хэрэглэгч</th><th>Үйлчилгээ</th><th>Төлбөр</th><th class="r">Дүн</th><th class="r">Оноо</th><th></th></tr></thead>
        <tbody>
          ${j.rows.map((t) => `
            <tr>
              <td class="num muted">${t.date.slice(11, 16)}</td>
              <td><b>${esc(t.name || fmtPhone(t.customer_phone))}</b><div class="muted num">${fmtPhone(t.customer_phone)}</div></td>
              <td>${esc(t.service_type)}${t.promo_code ? ` <span class="code-chip">${esc(t.promo_code)}</span>` : ''}</td>
              <td><span class="pay-tag pay-tag--${esc(t.payment_method)}"><i></i>${esc(t.payment_method)}</span></td>
              <td class="r strong num">${fmtT(t.amount)}</td>
              <td class="r num">${t.points_redeemed > 0 ? `<span class="chip chip--warn">−${t.points_redeemed}</span>` : `<span class="chip chip--ok">+${t.points_earned}</span>`}</td>
              <td class="r"><button class="btn btn--icon btn--ghost btn--sm" data-del="${t.id}" title="Буцаах">${ICONS.trash}</button></td>
            </tr>`).join('')}
        </tbody>
      </table>` : `<div class="empty">${ICONS.receipt}<p>Өнөөдөр бүртгэл хийгдээгүй байна</p></div>`;
    $$('#journalBox [data-del]').forEach((b) =>
      b.addEventListener('click', () =>
        confirmModal('Энэ бүртгэлийг буцаах уу? Оноо, орлого, ирэлтийн тоо бүгд буцаагдана.', {
          danger: 'Тийм, буцаах',
          onYes: async () => {
            await api(`/api/admin/transactions/${b.dataset.del}`, { method: 'DELETE' });
            toast('Бүртгэл буцаагдлаа');
            loadJournal();
          },
        })
      )
    );
  }

  renderCust(); renderReceipt(); loadJournal();
  if (phoneInput.value) lookup(); else phoneInput.focus();
}

function tierName(key) {
  const t = (state.rules?.loyalty.tiers || []).find((x) => x.key === key);
  return t ? t.name : key;
}

function rewardTiersOf(loyalty) {
  const t = (loyalty.reward_tiers && loyalty.reward_tiers.length)
    ? loyalty.reward_tiers
    : [{ points: loyalty.reward_threshold, title: loyalty.reward_title, value: loyalty.reward_value }];
  return t.slice().sort((a, b) => a.points - b.points);
}

/* ================= Хэрэглэгчид ================= */
async function vCustomers(view) {
  let q = '', offset = 0;
  const LIMIT = 50;

  view.innerHTML = `
    <div class="card">
      <div class="card__head">
        <h2>Бүх хэрэглэгч</h2>
        <div class="spacer"></div>
        <div style="position:relative">
          <input class="input" id="custSearch" placeholder="Утас, нэрээр хайх…" style="padding-left:38px;min-width:240px">
          <span style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--ink-3);display:flex">${ICONS.search}</span>
        </div>
        <button class="btn btn--primary" id="newCustBtn">${ICONS.plus}Шинэ хэрэглэгч</button>
      </div>
      <div class="card__body--flush tbl-wrap" id="custTable"></div>
      <div class="pager" id="custPager"></div>
    </div>`;

  async function load() {
    const d = await api(`/api/admin/customers?q=${encodeURIComponent(q)}&limit=${LIMIT}&offset=${offset}`);
    $('#custTable').innerHTML = d.rows.length ? `
      <table class="tbl tbl--click">
        <thead><tr><th>Утас</th><th>Нэр</th><th>Түвшин</th><th class="r">Оноо</th><th class="r">Ирэлт</th><th class="r">Зарцуулалт</th><th>Сүүлд ирсэн</th></tr></thead>
        <tbody>
          ${d.rows.map((c) => `
            <tr data-phone="${esc(c.phone)}">
              <td class="strong num">${fmtPhone(c.phone)}</td>
              <td>${c.name ? esc(c.name) : '<span class="muted">Нэргүй</span>'}</td>
              <td>${tierBadge(c.tier, tierName(c.tier))}</td>
              <td class="r strong num">${c.points}</td>
              <td class="r num">${c.total_visits}</td>
              <td class="r num">${fmtT(c.total_spent)}</td>
              <td class="num muted nowrap">${c.last_visit ? fmtDT(c.last_visit) : '—'}</td>
            </tr>`).join('')}
        </tbody>
      </table>` : `<div class="empty">${ICONS.users}<p>${q ? 'Хайлтад тохирох хэрэглэгч олдсонгүй' : 'Хэрэглэгч бүртгэгдээгүй байна'}</p></div>`;
    $$('#custTable tr[data-phone]').forEach((tr) =>
      tr.addEventListener('click', () => (location.hash = `#/customers/${tr.dataset.phone}`))
    );
    const from = d.total ? offset + 1 : 0;
    const to = Math.min(offset + LIMIT, d.total);
    $('#custPager').innerHTML = `
      <span class="num">${from}–${to} / нийт ${d.total}</span>
      <div style="display:flex;gap:8px">
        <button class="btn btn--ghost btn--sm" id="pgPrev" ${offset === 0 ? 'disabled' : ''}>Өмнөх</button>
        <button class="btn btn--ghost btn--sm" id="pgNext" ${to >= d.total ? 'disabled' : ''}>Дараах</button>
      </div>`;
    $('#pgPrev').onclick = () => { offset = Math.max(0, offset - LIMIT); load(); };
    $('#pgNext').onclick = () => { offset += LIMIT; load(); };
  }

  $('#custSearch').addEventListener('input', debounce((e) => { q = e.target.value.trim(); offset = 0; load(); }, 300));
  $('#newCustBtn').onclick = () => {
    openModal('Шинэ хэрэглэгч бүртгэх', `
      <div class="field"><label>Утасны дугаар *</label><input class="input input--lg num" id="ncPhone" type="tel" inputmode="numeric" maxlength="8" placeholder="99123456"></div>
      <div class="field"><label>Нэр (заавал биш)</label><input class="input" id="ncName" maxlength="60" placeholder="Жиш: Батбаяр"></div>
      <p class="error-text" id="ncErr" hidden></p>
      <button class="btn btn--primary btn--lg" id="ncSave">Бүртгэх</button>`);
    $('#ncPhone').focus();
    $('#ncSave').onclick = async () => {
      try {
        const r = await api('/api/admin/customers', {
          method: 'POST',
          body: { phone: $('#ncPhone').value, name: $('#ncName').value },
        });
        closeModal();
        toast('Хэрэглэгч бүртгэгдлээ');
        location.hash = `#/customers/${r.customer.phone}`;
      } catch (e) {
        $('#ncErr').textContent = e.message; $('#ncErr').hidden = false;
      }
    };
  };

  await load();
}

/* ================= Хэрэглэгчийн дэлгэрэнгүй ================= */
async function vCustomerDetail(view, phone) {
  const d = await api(`/api/admin/customers/${phone}`);
  const c = d.customer;
  const loyalty = d.loyalty;
  const rtiers = (loyalty.reward_tiers && loyalty.reward_tiers.length
    ? loyalty.reward_tiers
    : [{ points: loyalty.reward_threshold, title: loyalty.reward_title, value: loyalty.reward_value }]
  ).slice().sort((a, b) => a.points - b.points);
  const affordable = rtiers.filter((t) => c.points >= t.points);
  const curReward = affordable.length ? affordable[affordable.length - 1] : null;
  const nextReward = rtiers.find((t) => t.points > c.points) || null;
  const cardTarget = nextReward ? nextReward.points : rtiers[rtiers.length - 1].points;
  const cardVisits = d.transactions.slice(0, 10).map((t) => t.service_type).reverse();

  const tiers = [...loyalty.tiers].sort((a, b) => a.min - b.min);
  let cur = tiers[0];
  for (const t of tiers) if (c.lifetime_points >= t.min) cur = t;
  const next = tiers.find((t) => t.min > c.lifetime_points) || null;
  const pct = next ? Math.round(((c.lifetime_points - cur.min) / (next.min - cur.min)) * 100) : 100;
  const cardBonus = loyalty.card_bonus_enabled === false ? 0 : Math.max(0, +loyalty.card_bonus_pct || 0);

  view.innerHTML = `
    <div>
      <a class="back-link" href="#/customers">${ICONS.back}Хэрэглэгчид рүү буцах</a>
      <div class="card card__pad cust-head">
        <span class="cust-head__avatar">${esc((c.name || c.phone)[0].toUpperCase())}</span>
        <div class="cust-head__info">
          <h2>${c.name ? esc(c.name) : '<span style="color:var(--ink-3)">Нэргүй хэрэглэгч</span>'}
            ${tierBadge(c.tier, tierName(c.tier))}
            <button class="btn btn--icon btn--ghost btn--sm" id="editName" title="Нэр засах">${ICONS.pencil}</button>
          </h2>
          <p class="num">${fmtPhone(c.phone)} · Бүртгүүлсэн: ${fmtDate(c.created_at)}</p>
        </div>
        <a class="btn btn--primary" href="#/service?phone=${esc(c.phone)}">${ICONS.plus}Үйлчилгээ бүртгэх</a>
      </div>
    </div>

    <div class="card card__pad nfc-row">
      <span class="nfc-row__ic">${NFC_ICON}</span>
      <div class="nfc-row__info">
        <span class="nfc-row__label">NFC карт</span>
        ${c.nfc_uid
          ? `<span class="nfc-row__uid num">${esc(fmtUid(c.nfc_uid))}</span>
             ${cardBonus > 0 ? `<span class="chip chip--ok">Картын бонус +${cardBonus}%</span>` : ''}`
          : `<span class="nfc-row__none">Холбоогүй${cardBonus > 0 ? ` — карт холбовол +${cardBonus}% бонус` : ''}</span>`}
      </div>
      <div class="nfc-row__actions">
        <button class="btn btn--sm" id="nfcBind">Төхөөрөмжөөр холбох</button>
        <button class="btn btn--ghost btn--sm" id="nfcManual">Гараар</button>
        ${c.nfc_uid ? `<button class="btn btn--ghost btn--sm" id="nfcUnbind">Салгах</button>` : ''}
      </div>
    </div>

    ${curReward ? `
    <div class="reward-banner">
      ${ICONS.gift}
      <div>
        <strong>Энэ хэрэглэгч «${esc(curReward.title)}» авах эрхтэй!</strong>
        <span>Дараагийн бүртгэл дээр "Урамшуулал ашиглах"-ыг асаагаарай.</span>
      </div>
    </div>` : ''}

    <div class="grid-23">
      <div style="display:grid;gap:16px">
        <div class="stats" style="grid-template-columns:repeat(3,1fr)">
          <div class="card stat"><span class="stat__label">Идэвхтэй оноо</span><span class="stat__value num">${c.points}</span></div>
          <div class="card stat"><span class="stat__label">Нийт ирэлт</span><span class="stat__value num">${c.total_visits}</span></div>
          <div class="card stat"><span class="stat__label">Нийт зарцуулалт</span><span class="stat__value num" style="font-size:22px">${fmtT(c.total_spent)}</span></div>
        </div>
        <div class="card card__pad">
          <div class="tier-progress__row">
            <span>Түвшний явц: <b>${esc(cur.name)}</b></span>
            <span>${next ? `${esc(next.name)} хүртэл <b class="num">${next.min - c.lifetime_points} оноо</b>` : 'Дээд түвшин'}</span>
          </div>
          <div class="progress"><i style="width:${pct}%"></i></div>
        </div>
      </div>
      ${stampCard({
        points: c.points,
        target: cardTarget,
        showTarget: true,
        visits: cardVisits,
        compact: true,
        title: 'ОНООНЫ КАРТ',
        caption: curReward
          ? `«${esc(curReward.title)}» бэлэн!`
          : `${esc((nextReward || rtiers[0]).title)} хүртэл ${Math.max(0, cardTarget - c.points)} оноо`,
      })}
    </div>

    <div class="card">
      <div class="card__head"><h2>Үйлчилгээний түүх</h2><div class="spacer"></div><span class="chip num">${d.transactions.length} бүртгэл</span></div>
      <div class="card__body--flush tbl-wrap">
        ${d.transactions.length ? `
        <table class="tbl">
          <thead><tr><th>Огноо</th><th>Үйлчилгээ</th><th>Төлбөр</th><th class="r">Хөнгөлөлт</th><th class="r">Төлсөн</th><th class="r">Оноо</th><th></th></tr></thead>
          <tbody>
            ${d.transactions.map((t) => {
              const disc =
                t.tier_discount + (t.card_discount || 0) + t.promo_discount +
                (t.voucher_discount || 0) + t.redeem_discount;
              return `
              <tr>
                <td class="num nowrap muted">${fmtDT(t.date)}</td>
                <td>${esc(t.service_type)}${t.promo_code ? ` <span class="code-chip">${esc(t.promo_code)}</span>` : ''}${t.note ? `<div class="muted">${esc(t.note)}</div>` : ''}</td>
                <td><span class="pay-tag pay-tag--${esc(t.payment_method)}"><i></i>${esc(t.payment_method)}</span></td>
                <td class="r num" style="color:${disc ? 'var(--mint-600)' : 'var(--ink-3)'}">${disc ? '−' + fmtT(disc) : '—'}</td>
                <td class="r strong num">${fmtT(t.amount)}</td>
                <td class="r num">${t.points_redeemed > 0 ? `<span class="chip chip--warn">−${t.points_redeemed}</span>` : `<span class="chip chip--ok">+${t.points_earned}</span>`}</td>
                <td class="r"><button class="btn btn--icon btn--ghost btn--sm" data-del="${t.id}" title="Буцаах">${ICONS.trash}</button></td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>` : `<div class="empty">${ICONS.washer}<p>Үйлчилгээ бүртгэгдээгүй байна</p></div>`}
      </div>
    </div>

    <div class="card danger-zone">
      <div class="card__head"><h2>Аюултай бүс</h2></div>
      <div class="card__body" style="display:flex;justify-content:space-between;align-items:center;gap:14px;flex-wrap:wrap">
        <p style="font-size:13.5px;color:var(--ink-2)">Хэрэглэгчийг устгавал бүх гүйлгээний түүх хамт устна. Буцаах боломжгүй.</p>
        <button class="btn btn--danger" id="delCust">${ICONS.trash}Хэрэглэгч устгах</button>
      </div>
    </div>`;

  $('#editName').onclick = () => {
    openModal('Нэр засах', `
      <div class="field"><label>Нэр</label><input class="input" id="enName" maxlength="60" value="${esc(c.name)}"></div>
      <button class="btn btn--primary" id="enSave">Хадгалах</button>`);
    $('#enName').focus();
    $('#enSave').onclick = async () => {
      try {
        await api(`/api/admin/customers/${c.phone}`, { method: 'PUT', body: { name: $('#enName').value } });
        closeModal(); toast('Нэр шинэчлэгдлээ'); route();
      } catch (e) { toast(e.message, 'err'); }
    };
  };

  const nfcBind = $('#nfcBind');
  if (nfcBind) nfcBind.onclick = async () => {
    try {
      await api('/api/admin/device/bind-arm', { method: 'POST', body: { phone: c.phone } });
      openModal('Төхөөрөмжөөр холбох', `
        <div class="nfc-wait">
          <div class="nfc-wait__pulse">${NFC_ICON}</div>
          <p><b>${esc(c.name || c.phone)}</b>-д карт холбохоор хүлээж байна…</p>
          <p class="muted">Төхөөрөмж дээр шинэ картаа <b>уншуулна уу</b> (90 секунд).</p>
        </div>
        <button class="btn btn--ghost btn--lg" id="nfcWaitCancel">Болих</button>`);
      let done = false;
      const t0 = Date.now();
      const poll = setInterval(async () => {
        if (done) return;
        if (Date.now() - t0 > 92000) {
          done = true; clearInterval(poll);
          await api('/api/admin/device/bind-cancel', { method: 'POST' }).catch(() => {});
          closeModal(); toast('Хугацаа дууслаа, дахин оролдоно уу', 'err');
          return;
        }
        try {
          const cu = await api(`/api/admin/customers/${c.phone}`);
          if (cu.customer.nfc_uid) {
            done = true; clearInterval(poll);
            closeModal(); toast('Карт амжилттай холбогдлоо'); route();
          }
        } catch (_) {}
      }, 1500);
      const cancel = $('#nfcWaitCancel');
      if (cancel) cancel.onclick = async () => {
        done = true; clearInterval(poll);
        await api('/api/admin/device/bind-cancel', { method: 'POST' }).catch(() => {});
        closeModal();
      };
    } catch (e) { toast(e.message, 'err'); }
  };

  const nfcManual = $('#nfcManual');
  if (nfcManual) nfcManual.onclick = () => {
    openModal('NFC UID гараар оруулах', `
      <div class="field"><label>Картын UID (hex)</label>
        <input class="input num" id="nfcInput" value="${c.nfc_uid ? esc(c.nfc_uid) : ''}" placeholder="A32F1B04" maxlength="24"></div>
      <p class="hint-inline">Тусгаарлагчгүй эсвэл A3:2F:1B:04 хэлбэрээр. Салгах бол хоосон үлдээ.</p>
      <button class="btn btn--primary btn--lg" id="nfcInputSave">Хадгалах</button>`);
    $('#nfcInput').focus();
    $('#nfcInputSave').onclick = async () => {
      try {
        await api(`/api/admin/customers/${c.phone}`, { method: 'PUT', body: { nfc_uid: $('#nfcInput').value } });
        closeModal(); toast('Хадгалагдлаа'); route();
      } catch (e) { toast(e.message, 'err'); }
    };
  };

  const nfcUnbind = $('#nfcUnbind');
  if (nfcUnbind) nfcUnbind.onclick = () =>
    confirmModal('NFC картыг энэ хэрэглэгчээс салгах уу?', {
      danger: 'Салгах',
      onYes: async () => {
        await api(`/api/admin/customers/${c.phone}`, { method: 'PUT', body: { nfc_uid: '' } });
        toast('Салгалаа'); route();
      },
    });

  $$('#view [data-del]').forEach((b) =>
    b.addEventListener('click', () =>
      confirmModal('Энэ бүртгэлийг буцаах уу? Оноо, орлого, ирэлтийн тоо бүгд буцаагдана.', {
        danger: 'Тийм, буцаах',
        onYes: async () => {
          await api(`/api/admin/transactions/${b.dataset.del}`, { method: 'DELETE' });
          toast('Бүртгэл буцаагдлаа'); route();
        },
      })
    )
  );

  $('#delCust').onclick = () =>
    confirmModal(`<b>${esc(c.name || fmtPhone(c.phone))}</b>-г бүх түүхтэй нь устгах уу? Энэ үйлдлийг буцаах боломжгүй!`, {
      danger: 'Тийм, бүрмөсөн устгах',
      onYes: async () => {
        await api(`/api/admin/customers/${c.phone}`, { method: 'DELETE' });
        toast('Хэрэглэгч устгагдлаа');
        location.hash = '#/customers';
      },
    });
}

/* ================= Промо код ================= */
async function vPromos(view) {
  const d = await api('/api/admin/promos');
  view.innerHTML = `
    <div class="card">
      <div class="card__head">
        <h2>Промо кодууд</h2>
        <div class="spacer"></div>
        <button class="btn btn--primary" id="newPromo">${ICONS.plus}Шинэ код</button>
      </div>
      <div class="card__body--flush tbl-wrap">
        ${d.rows.length ? `
        <table class="tbl">
          <thead><tr><th>Код</th><th>Хөнгөлөлт</th><th>Хугацаа</th><th class="r">Ашиглалт</th><th>Төлөв</th><th class="r">Үйлдэл</th></tr></thead>
          <tbody>
            ${d.rows.map((p) => `
              <tr>
                <td><span class="code-chip">${esc(p.code)}</span>${p.description ? `<div class="muted" style="margin-top:4px">${esc(p.description)}</div>` : ''}</td>
                <td class="strong num">${p.type === 'percent' ? `−${p.value}%` : `−${fmtT(p.value)}`}</td>
                <td class="num nowrap">${fmtDate(p.valid_from)} — ${fmtDate(p.valid_to)}</td>
                <td class="r num">${p.used_count}${p.usage_limit ? ` / ${p.usage_limit}` : ''}</td>
                <td>${p.live ? '<span class="chip chip--ok">Идэвхтэй</span>' : p.is_active ? '<span class="chip chip--warn">Хугацаанаас гадуур</span>' : '<span class="chip chip--off">Идэвхгүй</span>'}</td>
                <td class="r nowrap">
                  <button class="btn btn--icon btn--ghost btn--sm" data-edit="${esc(p.code)}" title="Засах">${ICONS.pencil}</button>
                  <button class="btn btn--sm ${p.is_active ? 'btn--ghost' : 'btn--soft'}" data-toggle="${esc(p.code)}" data-on="${p.is_active}">${p.is_active ? 'Унтраах' : 'Асаах'}</button>
                  ${p.used_count === 0 ? `<button class="btn btn--icon btn--ghost btn--sm" data-drop="${esc(p.code)}" title="Устгах">${ICONS.trash}</button>` : ''}
                </td>
              </tr>`).join('')}
          </tbody>
        </table>` : `<div class="empty">${ICONS.tag}<p>Промо код үүсгээгүй байна</p></div>`}
      </div>
    </div>`;

  function promoForm(p) {
    const isNew = !p;
    openModal(isNew ? 'Шинэ промо код' : `${p.code} засах`, `
      <div class="form-grid">
        ${isNew ? `<div class="field"><label>Код *</label><input class="input" id="pfCode" maxlength="20" placeholder="ЖИШ: SUMMER20" style="text-transform:uppercase"></div>` : ''}
        <div class="form-row">
          <div class="field"><label>Төрөл</label>
            <select class="input" id="pfType">
              <option value="percent" ${!p || p.type === 'percent' ? 'selected' : ''}>Хувь (%)</option>
              <option value="fixed" ${p && p.type === 'fixed' ? 'selected' : ''}>Тогтмол дүн (₮)</option>
            </select>
          </div>
          <div class="field"><label>Хэмжээ *</label><input class="input num" id="pfValue" type="number" min="1" value="${p ? p.value : 10}"></div>
        </div>
        <div class="form-row">
          <div class="field"><label>Эхлэх огноо</label><input class="input num" id="pfFrom" type="date" value="${p ? p.valid_from : new Date().toISOString().slice(0, 10)}"></div>
          <div class="field"><label>Дуусах огноо</label><input class="input num" id="pfTo" type="date" value="${p ? p.valid_to : ''}"></div>
        </div>
        <div class="form-row">
          <div class="field"><label>Ашиглах хязгаар</label><input class="input num" id="pfLimit" type="number" min="0" value="${p ? p.usage_limit : 0}"><span class="hint">0 = хязгааргүй</span></div>
          <div class="field"><label>Тайлбар</label><input class="input" id="pfDesc" maxlength="120" value="${p ? esc(p.description) : ''}"></div>
        </div>
        <p class="error-text" id="pfErr" hidden></p>
        <button class="btn btn--primary btn--lg" id="pfSave">${isNew ? 'Үүсгэх' : 'Хадгалах'}</button>
      </div>`);
    $('#pfSave').onclick = async () => {
      const body = {
        type: $('#pfType').value,
        value: +$('#pfValue').value,
        valid_from: $('#pfFrom').value,
        valid_to: $('#pfTo').value,
        usage_limit: +$('#pfLimit').value,
        description: $('#pfDesc').value,
        is_active: p ? !!p.is_active : true,
      };
      try {
        if (isNew) await api('/api/admin/promos', { method: 'POST', body: { ...body, code: $('#pfCode').value } });
        else await api(`/api/admin/promos/${p.code}`, { method: 'PUT', body });
        closeModal(); toast(isNew ? 'Промо код үүслээ' : 'Хадгалагдлаа'); route();
      } catch (e) { $('#pfErr').textContent = e.message; $('#pfErr').hidden = false; }
    };
  }

  $('#newPromo').onclick = () => promoForm(null);
  $$('#view [data-edit]').forEach((b) => b.addEventListener('click', () => promoForm(d.rows.find((r) => r.code === b.dataset.edit))));
  $$('#view [data-toggle]').forEach((b) =>
    b.addEventListener('click', async () => {
      await api(`/api/admin/promos/${b.dataset.toggle}`, { method: 'PUT', body: { is_active: b.dataset.on !== '1' } });
      toast(b.dataset.on === '1' ? 'Код идэвхгүй боллоо' : 'Код идэвхтэй боллоо'); route();
    })
  );
  $$('#view [data-drop]').forEach((b) =>
    b.addEventListener('click', () =>
      confirmModal(`<b>${esc(b.dataset.drop)}</b> кодыг устгах уу?`, {
        danger: 'Тийм, устгах',
        onYes: async () => {
          await api(`/api/admin/promos/${b.dataset.drop}`, { method: 'DELETE' });
          toast('Код устгагдлаа'); route();
        },
      })
    )
  );
}

/* ================= Эрхийн бичиг (voucher) ================= */
function voucherStatusChip(v) {
  if (v.status === 'redeemed') return '<span class="chip chip--off">Ашиглагдсан</span>';
  if (v.status === 'void') return '<span class="chip chip--warn">Цуцлагдсан</span>';
  if (!v.live) return '<span class="chip chip--warn">Хугацаа дууссан</span>';
  return '<span class="chip chip--ok">Идэвхтэй</span>';
}

function defaultExpiry() {
  const d = new Date();
  d.setMonth(d.getMonth() + 3);
  return d.toISOString().slice(0, 10);
}

// Бэлгийн эрхийн бичгийн загвар — өөрөө хүрэлцэх SVG (гадны нөөц шаардахгүй).
// Системийн фонт (serif/sans/mono) ашигласан тул PNG татахад дэлгэц дээрхтэй ижил гарна.
// Логог нэг удаа татаж data URI болгож кэшлэнэ (эрхийн бичигт шигтгэхэд)
let logoDataUri = null;
async function ensureLogoUri() {
  if (logoDataUri !== null) return logoDataUri;
  try {
    const r = await fetch('/img/logo-mark.png', { cache: 'force-cache' });
    const b = await r.blob();
    logoDataUri = await new Promise((res) => {
      const fr = new FileReader();
      fr.onload = () => res(fr.result);
      fr.onerror = () => res('');
      fr.readAsDataURL(b);
    });
  } catch { logoDataUri = ''; }
  return logoDataUri;
}

// Бэлгийн эрхийн бичиг — нүүр хуудасны онооны карт (угаалгын машины нүүр)-тэй ижил
// хөөрхөн загвар: иллюминатор (ус/давалгаа/хөөс), удирдлагын самбар (товч, LED),
// шураг, cyan гэрэлтэлт. Системийн фонт тул PNG татахад дэлгэц дээрхтэй ижил гарна.
function voucherCert(v, logo) {
  logo = logo || logoDataUri || '';
  const biz = (state.rules && state.rules.business) || { name: 'Moon Laundry', phone: '' };
  const bizName = esc(String(biz.name || 'Moon Laundry').toUpperCase());
  const isPct = v.type === 'percent';
  const bigVal = isPct ? `${v.value}%` : `${Number(v.value).toLocaleString('en-US')}₮`;
  const detailLine = isPct ? `${v.value}% ХӨНГӨЛӨЛТ ЭДЛЭНЭ` : `${Number(v.value).toLocaleString('en-US')}₮ ХҮРТЭЛ ХӨНГӨЛНӨ`;
  const title = v.title || (isPct ? `${v.value}% хөнгөлөлт` : `${bigVal} бэлэг`);
  const tSize = title.length > 26 ? 29 : title.length > 18 ? 35 : 42;
  const vSize = bigVal.length > 7 ? 38 : bigVal.length > 5 ? 46 : 56;
  const rx = 692; // баруун баганын төв
  const rows = [];
  let ry = 322;
  if (v.recipient) { rows.push(`<text x="${rx}" y="${ry}" text-anchor="middle" fill="#CFEFFA" font-size="19">Хүлээн авагч: <tspan fill="#67E8F9" font-weight="bold">${esc(v.recipient)}</tspan></text>`); ry += 31; }
  if (v.sender) { rows.push(`<text x="${rx}" y="${ry}" text-anchor="middle" fill="#CFEFFA" font-size="19">Бэлэглэсэн: <tspan fill="#67E8F9" font-weight="bold">${esc(v.sender)}</tspan></text>`); ry += 31; }
  if (v.message) { rows.push(`<text x="${rx}" y="${ry + 2}" text-anchor="middle" fill="#9FC4D6" font-size="16" font-style="italic">“${esc(v.message)}”</text>`); ry += 28; }
  const codeY = Math.max(ry + 12, 432);
  const brand = logo
    ? `<image href="${logo}" xlink:href="${logo}" x="124" y="42" width="66" height="46" preserveAspectRatio="xMidYMid meet"/>
  <text x="202" y="74" fill="#A5F3FC" font-size="20" font-weight="bold" letter-spacing="3">${bizName}</text>`
    : `<text x="124" y="74" fill="#A5F3FC" font-size="20" font-weight="bold" letter-spacing="3">${bizName}</text>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1000" height="640" viewBox="0 0 1000 640" font-family="'Segoe UI', 'Helvetica Neue', Arial, sans-serif">
  <defs>
    <linearGradient id="cbody" x1="0" y1="0" x2=".4" y2="1"><stop offset="0" stop-color="#0E5A80"/><stop offset=".78" stop-color="#082F49"/><stop offset="1" stop-color="#061F30"/></linearGradient>
    <linearGradient id="csheen" x1="0" y1="0" x2="1" y2="1"><stop offset="26%" stop-color="#fff" stop-opacity="0"/><stop offset="42%" stop-color="#fff" stop-opacity=".06"/><stop offset="58%" stop-color="#fff" stop-opacity="0"/></linearGradient>
    <radialGradient id="cring" cx=".4" cy=".33" r=".85"><stop offset="0" stop-color="#2C86B3"/><stop offset="1" stop-color="#06283F"/></radialGradient>
    <radialGradient id="cglass" cx=".35" cy=".28" r=".9"><stop offset="0" stop-color="#0C3E5C"/><stop offset="1" stop-color="#04182A"/></radialGradient>
    <linearGradient id="cwater" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3FE0F5"/><stop offset="1" stop-color="#0B6FA8"/></linearGradient>
    <radialGradient id="cknob" cx=".35" cy=".3" r=".85"><stop offset="0" stop-color="#9DE4FB"/><stop offset="1" stop-color="#0369A1"/></radialGradient>
    <radialGradient id="cscrew" cx=".35" cy=".3" r=".85"><stop offset="0" stop-color="#A5F3FC" stop-opacity=".55"/><stop offset="1" stop-color="#082F49"/></radialGradient>
    <filter id="cglow" x="-45%" y="-45%" width="190%" height="190%"><feGaussianBlur stdDeviation="3.4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    <clipPath id="cgls"><circle cx="252" cy="372" r="132"/></clipPath>
  </defs>
  <rect width="1000" height="640" rx="30" fill="url(#cbody)"/>
  <rect width="1000" height="640" rx="30" fill="url(#csheen)"/>
  <rect x="15" y="15" width="970" height="610" rx="22" fill="none" stroke="#A5F3FC" stroke-opacity=".2" stroke-width="2"/>
  <circle cx="36" cy="36" r="5" fill="url(#cscrew)"/><circle cx="964" cy="36" r="5" fill="url(#cscrew)"/><circle cx="36" cy="604" r="5" fill="url(#cscrew)"/><circle cx="964" cy="604" r="5" fill="url(#cscrew)"/>
  <!-- Удирдлагын самбар: товч, лого, LED шошго -->
  <circle cx="58" cy="66" r="12" fill="url(#cknob)"/><rect x="57.2" y="57" width="2.2" height="7" rx="1" fill="#04182A"/>
  <circle cx="92" cy="66" r="12" fill="url(#cknob)"/><rect x="91.2" y="57" width="2.2" height="7" rx="1" fill="#04182A" transform="rotate(45 92 62)"/>
  ${brand}
  <rect x="700" y="46" width="244" height="42" rx="12" fill="#03141F" stroke="#67E8F9" stroke-opacity=".35" stroke-width="1.5"/>
  <text x="822" y="72" text-anchor="middle" fill="#67E8F9" font-size="13" font-weight="bold" letter-spacing="2.5" filter="url(#cglow)">БЭЛГИЙН ЭРХИЙН БИЧИГ</text>
  <line x1="28" y1="114" x2="972" y2="114" stroke="#A5F3FC" stroke-opacity=".15" stroke-width="1.5"/>
  <!-- Иллюминатор (зүүн): усны түвшин, давалгаа, хөөс, эргэдэг хүрд, дүнгийн LED -->
  <circle cx="252" cy="372" r="148" fill="url(#cring)"/>
  <circle cx="252" cy="372" r="148" fill="none" stroke="#0A2E44" stroke-width="3"/>
  <circle cx="252" cy="372" r="132" fill="url(#cglass)"/>
  <g clip-path="url(#cgls)">
    <path d="M120 388 Q154 376 188 388 T256 388 T324 388 T392 388 V506 H120 Z" fill="url(#cwater)" opacity=".94"/>
    <path d="M120 388 Q154 376 188 388 T256 388 T324 388 T392 388" fill="none" stroke="#BEF6FF" stroke-opacity=".55" stroke-width="2"/>
    <circle cx="214" cy="452" r="7" fill="#EAFBFF" opacity=".85"/>
    <circle cx="296" cy="470" r="5" fill="#EAFBFF" opacity=".7"/>
    <circle cx="258" cy="436" r="4" fill="#EAFBFF" opacity=".7"/>
  </g>
  <circle cx="252" cy="372" r="110" fill="none" stroke="#A5F3FC" stroke-opacity=".22" stroke-width="2.5" stroke-dasharray="4 13"/>
  <ellipse cx="212" cy="320" rx="46" ry="30" fill="#fff" opacity=".12" transform="rotate(-18 212 320)"/>
  <text x="252" y="360" text-anchor="middle" fill="#8FF0FF" font-size="${vSize}" font-weight="800" filter="url(#cglow)">${esc(bigVal)}</text>
  <!-- Баруун контент -->
  <text x="${rx}" y="214" text-anchor="middle" fill="#FFFFFF" font-size="${tSize}" font-weight="800">${esc(title)}</text>
  <text x="${rx}" y="252" text-anchor="middle" fill="#67E8F9" font-size="17" letter-spacing="1.5">${esc(detailLine)}</text>
  ${rows.join('\n  ')}
  <rect x="${rx - 205}" y="${codeY}" width="410" height="66" rx="13" fill="#03141F" stroke="#67E8F9" stroke-opacity=".4" stroke-width="1.5"/>
  <text x="${rx}" y="${codeY + 24}" text-anchor="middle" fill="#7FC7DE" font-size="11" letter-spacing="4">КОД</text>
  <text x="${rx}" y="${codeY + 50}" text-anchor="middle" fill="#8FF0FF" font-family="'Courier New', monospace" font-size="25" font-weight="bold" letter-spacing="4" filter="url(#cglow)">${esc(v.code)}</text>
  <!-- Өнгөт штампууд — картын хэв маяг -->
  <g>
    <circle cx="200" cy="548" r="11" fill="#7C3AED"/><circle cx="196.5" cy="544.5" r="3.4" fill="#fff" opacity=".5"/>
    <circle cx="226" cy="548" r="11" fill="#0284C7"/><circle cx="222.5" cy="544.5" r="3.4" fill="#fff" opacity=".5"/>
    <circle cx="252" cy="548" r="11" fill="#D97706"/><circle cx="248.5" cy="544.5" r="3.4" fill="#fff" opacity=".5"/>
    <circle cx="278" cy="548" r="11" fill="#E11D48"/><circle cx="274.5" cy="544.5" r="3.4" fill="#fff" opacity=".5"/>
    <circle cx="304" cy="548" r="11" fill="#22D3EE"/><circle cx="300.5" cy="544.5" r="3.4" fill="#fff" opacity=".5"/>
  </g>
  <!-- Хөл -->
  <text x="60" y="598" fill="#89B4C8" font-size="14.5">Хүчинтэй: ${fmtDate(v.valid_to)} хүртэл</text>
  <text x="940" y="598" text-anchor="end" fill="#89B4C8" font-size="14.5">${esc(biz.phone || '')}</text>
</svg>`;
}

function triggerDownload(url, filename) {
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
function svgDownload(svg, filename) {
  triggerDownload(URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml;charset=utf-8' })), filename);
}
async function pngDownload(svg, filename) {
  try {
    if (document.fonts && document.fonts.ready) await document.fonts.ready;
    const scale = 2, W = 1000, H = 640;
    const url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml;charset=utf-8' }));
    const img = new Image();
    await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error('load')); img.src = url; });
    const canvas = document.createElement('canvas');
    canvas.width = W * scale; canvas.height = H * scale;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#05141F'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    ctx.drawImage(img, 0, 0, W, H);
    URL.revokeObjectURL(url);
    canvas.toBlob((png) => {
      if (!png) return toast('PNG үүсгэж чадсангүй', 'err');
      triggerDownload(URL.createObjectURL(png), filename);
    }, 'image/png');
  } catch { toast('PNG татахад алдаа гарлаа', 'err'); }
}
function printSvg(svg) {
  // document.write-ийн оронд iframe srcdoc (XSS-ээс аюулгүй, эрхийн бичгийн бүх талбар esc()-тэй)
  const frame = document.createElement('iframe');
  frame.setAttribute('aria-hidden', 'true');
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
  frame.srcdoc = `<!doctype html><html><head><meta charset="utf-8"><title>Эрхийн бичиг</title><style>@page{size:landscape;margin:12mm}html,body{margin:0}svg{width:100%;height:auto}</style></head><body>${svg}</body></html>`;
  frame.onload = () => {
    try { frame.contentWindow.focus(); frame.contentWindow.print(); } catch { /* noop */ }
    setTimeout(() => frame.remove(), 1500);
  };
  document.body.appendChild(frame);
}

async function showCert(v, isNew) {
  const svg = voucherCert(v, await ensureLogoUri());
  openModal(isNew ? 'Эрхийн бичиг бэлэн боллоо' : `Эрхийн бичиг · ${v.code}`, `
    <div class="cert-preview">${svg}</div>
    <div class="cert-actions">
      <button class="btn btn--primary" id="certPng">${ICONS.download}Зураг (PNG) татах</button>
      <button class="btn btn--soft" id="certSvg">${ICONS.download}SVG татах</button>
      <button class="btn btn--ghost" id="certPrint">${ICONS.printer}Хэвлэх</button>
    </div>
    <p class="hint" style="margin-top:10px">Зургаар татаж аваад цахимаар илгээх, эсвэл хэвлэн бэлэглэж болно.</p>`);
  const m = $('#modalHost .modal'); if (m) m.style.maxWidth = '660px';
  const fname = `erhiin-bichig-${v.code}`;
  $('#certPng').onclick = () => pngDownload(svg, `${fname}.png`);
  $('#certSvg').onclick = () => svgDownload(svg, `${fname}.svg`);
  $('#certPrint').onclick = () => printSvg(svg);
}

function voucherCreateForm() {
  openModal('Шинэ эрхийн бичиг', `
    <div class="form-grid">
      <div class="form-row">
        <div class="field"><label>Төрөл</label>
          <select class="input" id="vfType">
            <option value="fixed">Тогтмол дүн (₮)</option>
            <option value="percent">Хувь (%)</option>
          </select>
        </div>
        <div class="field"><label>Хэмжээ *</label><input class="input num" id="vfValue" type="number" min="1" value="20000"></div>
      </div>
      <div class="field"><label>Гарчиг <span class="hint-inline">(хоосон бол автоматаар)</span></label><input class="input" id="vfTitle" maxlength="60" placeholder="Жиш: Үнэгүй том угаалга"></div>
      <div class="form-row">
        <div class="field"><label>Хүлээн авагч</label><input class="input" id="vfRecipient" maxlength="40" placeholder="Хэнд бэлэглэх вэ?"></div>
        <div class="field"><label>Бэлэглэсэн</label><input class="input" id="vfSender" maxlength="40" placeholder="Хэнээс"></div>
      </div>
      <div class="field"><label>Захиас <span class="hint-inline">(заавал биш)</span></label><input class="input" id="vfMessage" maxlength="200" placeholder="Төрсөн өдрийн мэнд хүргэе!"></div>
      <div class="field"><label>Дуусах хугацаа *</label><input class="input num" id="vfTo" type="date" value="${defaultExpiry()}"></div>
      <p class="error-text" id="vfErr" hidden></p>
      <button class="btn btn--primary btn--lg" id="vfSave">Үүсгэх</button>
    </div>`);
  $('#vfValue').addEventListener('input', () => {
    // percent хязгаар
    if ($('#vfType').value === 'percent' && +$('#vfValue').value > 100) $('#vfValue').value = 100;
  });
  $('#vfSave').onclick = async () => {
    try {
      const r = await api('/api/admin/vouchers', {
        method: 'POST',
        body: {
          type: $('#vfType').value,
          value: +$('#vfValue').value,
          title: $('#vfTitle').value,
          recipient: $('#vfRecipient').value,
          sender: $('#vfSender').value,
          message: $('#vfMessage').value,
          valid_to: $('#vfTo').value,
        },
      });
      closeModal();
      toast('Эрхийн бичиг үүслээ');
      showCert(r.voucher, true);
    } catch (e) { $('#vfErr').textContent = e.message; $('#vfErr').hidden = false; }
  };
}

async function vVouchers(view) {
  const d = await api('/api/admin/vouchers');
  view.innerHTML = `
    <div class="card">
      <div class="card__head">
        <h2>Эрхийн бичгүүд</h2>
        <div class="spacer"></div>
        <button class="btn btn--primary" id="newVoucher">${ICONS.plus}Шинэ эрхийн бичиг</button>
      </div>
      <div class="card__body--flush tbl-wrap">
        ${d.rows.length ? `
        <table class="tbl">
          <thead><tr><th>Код</th><th>Урамшуулал</th><th>Хүлээн авагч</th><th>Хүчинтэй</th><th>Төлөв</th><th class="r">Үйлдэл</th></tr></thead>
          <tbody>
            ${d.rows.map((v) => `
              <tr>
                <td><span class="code-chip">${esc(v.code)}</span></td>
                <td><b>${esc(v.title)}</b><div class="muted num">${v.type === 'percent' ? `−${v.value}%` : `−${fmtT(v.value)}`}</div></td>
                <td>${v.recipient ? esc(v.recipient) : '<span class="muted">—</span>'}</td>
                <td class="num nowrap">${fmtDate(v.valid_to)}</td>
                <td>${voucherStatusChip(v)}</td>
                <td class="r nowrap">
                  <button class="btn btn--soft btn--sm" data-cert="${esc(v.code)}">${ICONS.download}Эрхийн бичиг</button>
                  ${v.status !== 'redeemed' ? `
                  <button class="btn btn--icon btn--ghost btn--sm" data-void="${esc(v.code)}" data-on="${v.status === 'active' ? 1 : 0}" title="${v.status === 'active' ? 'Цуцлах' : 'Сэргээх'}">${v.status === 'active' ? ICONS.x : ICONS.check}</button>
                  <button class="btn btn--icon btn--ghost btn--sm" data-drop="${esc(v.code)}" title="Устгах">${ICONS.trash}</button>` : ''}
                </td>
              </tr>`).join('')}
          </tbody>
        </table>` : `<div class="empty">${ICONS.gift}<p>Эрхийн бичиг үүсгээгүй байна</p><button class="btn btn--primary btn--sm" id="emptyNew" style="margin-top:12px">${ICONS.plus}Эхнийхийг үүсгэх</button></div>`}
      </div>
    </div>`;

  if ($('#newVoucher')) $('#newVoucher').onclick = voucherCreateForm;
  if ($('#emptyNew')) $('#emptyNew').onclick = voucherCreateForm;
  $$('#view [data-cert]').forEach((b) => (b.onclick = () => showCert(d.rows.find((x) => x.code === b.dataset.cert))));
  $$('#view [data-void]').forEach((b) => (b.onclick = async () => {
    try {
      await api(`/api/admin/vouchers/${b.dataset.void}`, { method: 'PUT', body: { status: b.dataset.on === '1' ? 'void' : 'active' } });
      toast(b.dataset.on === '1' ? 'Эрхийн бичиг цуцлагдлаа' : 'Эрхийн бичиг сэргээгдлээ');
      route();
    } catch (e) { toast(e.message, 'err'); }
  }));
  $$('#view [data-drop]').forEach((b) => (b.onclick = () =>
    confirmModal(`<b>${esc(b.dataset.drop)}</b> эрхийн бичгийг устгах уу?`, {
      danger: 'Тийм, устгах',
      onYes: async () => { await api(`/api/admin/vouchers/${b.dataset.drop}`, { method: 'DELETE' }); toast('Устгагдлаа'); route(); },
    })));
}

/* ================= Тайлан ================= */
async function vReports(view, group) {
  const d = await api(`/api/admin/reports?group=${group}`);
  const rangeLabel = { day: 'Сүүлийн 30 өдөр', month: 'Сүүлийн 12 сар', year: 'Бүх жилүүд' }[d.group];

  const from = d.group === 'year' ? '' : d.series[0]?.p.length === 7 ? d.series[0].p + '-01' : d.series[0]?.p;
  const csvQ = from ? `?from=${from}` : '';

  view.innerHTML = `
    <div class="card card__pad" style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">
      <div class="range-chips" role="tablist">
        <button data-g="day" class="${d.group === 'day' ? 'active' : ''}">Өдөр</button>
        <button data-g="month" class="${d.group === 'month' ? 'active' : ''}">Сар</button>
        <button data-g="year" class="${d.group === 'year' ? 'active' : ''}">Жил</button>
      </div>
      <span class="hint">${rangeLabel}</span>
      <div class="spacer" style="flex:1"></div>
      <div class="no-print" style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn btn--ghost btn--sm" href="/api/admin/export/transactions.csv${csvQ}" download>${ICONS.download}Гүйлгээ CSV</a>
        <a class="btn btn--ghost btn--sm" href="/api/admin/export/customers.csv" download>${ICONS.download}Хэрэглэгч CSV</a>
        <button class="btn btn--ghost btn--sm" id="printBtn">${ICONS.printer}Хэвлэх</button>
      </div>
    </div>

    <div class="stats">
      <div class="card stat"><span class="stat__label">Нийт орлого</span><span class="stat__value num" style="font-size:24px">${fmtT(d.totals.revenue)}</span></div>
      <div class="card stat"><span class="stat__label">Гүйлгээний тоо</span><span class="stat__value num">${fmtNum(d.totals.cnt)}</span></div>
      <div class="card stat"><span class="stat__label">Дундаж чек</span><span class="stat__value num" style="font-size:24px">${fmtT(d.totals.avg)}</span></div>
      <div class="card stat"><span class="stat__label">Идэвхтэй хэрэглэгч</span><span class="stat__value num">${d.totals.customers}</span></div>
    </div>

    <div class="card">
      <div class="card__head"><h2>Орлогын динамик — ${rangeLabel.toLowerCase()}</h2></div>
      <div class="card__body"><div class="chart-box"><canvas id="chMain"></canvas></div></div>
    </div>

    <div class="grid-2">
      <div class="card">
        <div class="card__head"><h2>Шилдэг хэрэглэгчид</h2></div>
        <div class="card__body--flush tbl-wrap">
          ${d.top.length ? `
          <table class="tbl tbl--click">
            <thead><tr><th></th><th>Хэрэглэгч</th><th class="r">Ирэлт</th><th class="r">Орлого</th></tr></thead>
            <tbody>
              ${d.top.map((c, i) => `
                <tr data-phone="${esc(c.phone)}">
                  <td><span class="rank rank--${i + 1}">${i + 1}</span></td>
                  <td><b>${c.name ? esc(c.name) : fmtPhone(c.phone)}</b><div class="muted num">${fmtPhone(c.phone)} · ${tierName(c.tier)}</div></td>
                  <td class="r num">${c.cnt}</td>
                  <td class="r strong num">${fmtT(c.revenue)}</td>
                </tr>`).join('')}
            </tbody>
          </table>` : `<div class="empty"><p>Өгөгдөл алга</p></div>`}
        </div>
      </div>

      <div class="card">
        <div class="card__head"><h2>Үйлчилгээний задаргаа</h2></div>
        <div class="card__body">
          <div class="chart-box chart-box--sm"><canvas id="chSvc"></canvas></div>
          <div class="legend" id="svcLegend"></div>
        </div>
      </div>
    </div>

    <div class="grid-2">
      <div class="card">
        <div class="card__head"><h2>Төлбөрийн хэлбэр</h2></div>
        <div class="card__body"><div class="chart-box chart-box--sm"><canvas id="chPay"></canvas></div></div>
      </div>
      <div class="card">
        <div class="card__head"><h2>Ачаалал — гараг ба цагаар</h2></div>
        <div class="card__body">
          <div class="chart-box" style="height:106px"><canvas id="chWd"></canvas></div>
          <div class="chart-box" style="height:106px;margin-top:14px"><canvas id="chHr"></canvas></div>
        </div>
      </div>
    </div>`;

  $$('.range-chips button').forEach((b) =>
    b.addEventListener('click', () => (location.hash = `#/reports?g=${b.dataset.g}`))
  );
  $('#printBtn').onclick = () => window.print();
  $$('#view tr[data-phone]').forEach((tr) =>
    tr.addEventListener('click', () => (location.hash = `#/customers/${tr.dataset.phone}`))
  );

  // Орлогын гол график
  const labels = d.series.map((r) => (d.group === 'day' ? r.p.slice(5).replace('-', '.') : d.group === 'month' ? r.p.replace('-', '.') : r.p));
  makeChart($('#chMain'), {
    type: 'bar',
    data: { labels, datasets: [{ data: d.series.map((r) => r.revenue), backgroundColor: PAL[0] + 'CC', hoverBackgroundColor: PAL[0], borderRadius: 4, maxBarThickness: 26 }] },
    options: {
      maintainAspectRatio: false,
      plugins: { tooltip: { callbacks: { label: (c) => ` ${fmtT(c.parsed.y)} · ${d.series[c.dataIndex].cnt} гүйлгээ` } } },
      scales: {
        x: { grid: { display: false }, ticks: { maxTicksLimit: 12 } },
        y: { border: { display: false }, grid: { color: '#EEF2F6' }, ticks: { callback: compact, maxTicksLimit: 6 }, beginAtZero: true },
      },
    },
  });

  // Үйлчилгээний doughnut + legend
  const svcColors = d.services.map((s, i) => (s.name === 'Бусад' ? PAL[4] : PAL[i % 4]));
  makeChart($('#chSvc'), {
    type: 'doughnut',
    data: {
      labels: d.services.map((s) => s.name),
      datasets: [{ data: d.services.map((s) => s.revenue), backgroundColor: svcColors, borderColor: '#fff', borderWidth: 2, hoverOffset: 6 }],
    },
    options: {
      maintainAspectRatio: false, cutout: '62%',
      plugins: { tooltip: { callbacks: { label: (c) => ` ${fmtT(c.parsed)} (${d.services[c.dataIndex].qty} удаа)` } } },
    },
  });
  $('#svcLegend').innerHTML = d.services
    .map((s, i) => `<div class="legend__item"><i style="background:${svcColors[i]}"></i><span>${esc(s.name)}</span><b class="num">${fmtT(s.revenue)}</b></div>`)
    .join('');

  // Төлбөрийн хэлбэр — хэвтээ бар
  const payColor = { 'Бэлэн': PAL[1], 'Карт': PAL[2], 'Данс': PAL[0] };
  makeChart($('#chPay'), {
    type: 'bar',
    data: {
      labels: d.payments.map((p) => p.method),
      datasets: [{ data: d.payments.map((p) => p.revenue), backgroundColor: d.payments.map((p) => payColor[p.method] || PAL[4]), borderRadius: 4, maxBarThickness: 30 }],
    },
    options: {
      indexAxis: 'y', maintainAspectRatio: false,
      plugins: { tooltip: { callbacks: { label: (c) => ` ${fmtT(c.parsed.x)}` } } },
      scales: {
        x: { border: { display: false }, grid: { color: '#EEF2F6' }, ticks: { callback: compact, maxTicksLimit: 6 }, beginAtZero: true },
        y: { grid: { display: false } },
      },
    },
  });

  // Гараг, цагийн ачаалал
  makeChart($('#chWd'), {
    type: 'bar',
    data: { labels: WEEKDAYS, datasets: [{ data: d.weekday, backgroundColor: PAL[0] + 'B3', hoverBackgroundColor: PAL[0], borderRadius: 3, maxBarThickness: 22 }] },
    options: {
      maintainAspectRatio: false,
      plugins: { tooltip: { callbacks: { label: (c) => ` ${c.parsed.y} гүйлгээ` } } },
      scales: { x: { grid: { display: false } }, y: { display: false, beginAtZero: true } },
    },
  });
  const hrLabels = d.hour.map((_, i) => i);
  makeChart($('#chHr'), {
    type: 'bar',
    data: { labels: hrLabels, datasets: [{ data: d.hour, backgroundColor: '#22D3EE99', hoverBackgroundColor: '#22D3EE', borderRadius: 3, maxBarThickness: 14 }] },
    options: {
      maintainAspectRatio: false,
      plugins: { tooltip: { callbacks: { title: (c) => `${c[0].label}:00 цаг`, label: (c) => ` ${c.parsed.y} гүйлгээ` } } },
      scales: { x: { grid: { display: false }, ticks: { maxTicksLimit: 12, callback: (v, i) => (i % 3 === 0 ? i : '') } }, y: { display: false, beginAtZero: true } },
    },
  });
}

/* ================= Тохиргоо ================= */
async function vSettings(view) {
  const r = state.rules = await api('/api/admin/rules');
  const l = r.loyalty;

  view.innerHTML = `
    <div class="settings-grid">
      <div style="display:grid;gap:20px">
        <div class="card">
          <div class="card__head"><h2>Байгууллагын мэдээлэл</h2></div>
          <div class="card__body form-grid">
            <div class="form-row">
              <div class="field"><label>Нэр</label><input class="input" id="bzName" value="${esc(r.business.name)}"></div>
              <div class="field"><label>Уриа</label><input class="input" id="bzTag" value="${esc(r.business.tagline)}"></div>
            </div>
            <div class="form-row">
              <div class="field"><label>Утас</label><input class="input" id="bzPhone" value="${esc(r.business.phone)}"></div>
              <div class="field"><label>Ажиллах цаг</label><input class="input" id="bzHours" value="${esc(r.business.hours)}"></div>
            </div>
            <div class="field"><label>Хаяг</label><input class="input" id="bzAddr" value="${esc(r.business.address)}"></div>
            <button class="btn btn--primary" id="bzSave">Хадгалах</button>
          </div>
        </div>

        <div class="card">
          <div class="card__head"><h2>Үйлчилгээ, үнэ ба оноо</h2></div>
          <div class="card__body">
            <div class="svc-editor-head"><span>Нэр</span><span>Үнэ (₮)</span><span>Оноо</span><span></span></div>
            <div id="svcEditor"></div>
            <p class="hint">«Оноо» = уг үйлчилгээ авахад олгох оноо (том угаалга илүү оноотой). Энэ нь «Үйлчилгээгээр» горимд ажиллана.</p>
            <div style="display:flex;gap:10px;margin-top:6px">
              <button class="btn btn--soft btn--sm" id="svcAdd">${ICONS.plus}Үйлчилгээ нэмэх</button>
              <div style="flex:1"></div>
              <button class="btn btn--primary" id="svcSave">Хадгалах</button>
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card__head"><h2>Нууц үг солих</h2></div>
          <div class="card__body form-grid">
            <div class="form-row">
              <div class="field"><label>Одоогийн нууц үг</label><input class="input" id="pwCur" type="password" autocomplete="current-password"></div>
              <div class="field"><label>Шинэ нууц үг</label><input class="input" id="pwNew" type="password" autocomplete="new-password"></div>
            </div>
            <button class="btn btn--primary" id="pwSave">Солих</button>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card__head"><h2>Бонусын дүрэм</h2></div>
        <div class="card__body form-grid">
          <div class="field">
            <label>Оноо тооцох арга</label>
            <div class="mode-cards">
              <label class="mode-card ${l.points_mode === 'per_service' ? 'active' : ''}" id="modeService">
                <input type="radio" name="pmode" value="per_service" ${l.points_mode === 'per_service' ? 'checked' : ''}>
                <b>Үйлчилгээгээр</b><span>Төрөл бүр өөр оноотой</span>
              </label>
              <label class="mode-card ${l.points_mode === 'per_visit' ? 'active' : ''}" id="modeVisit">
                <input type="radio" name="pmode" value="per_visit" ${l.points_mode === 'per_visit' ? 'checked' : ''}>
                <b>Ирэлт тутамд</b><span>Бүрт тогтмол оноо</span>
              </label>
              <label class="mode-card ${l.points_mode === 'per_amount' ? 'active' : ''}" id="modeAmount">
                <input type="radio" name="pmode" value="per_amount" ${l.points_mode === 'per_amount' ? 'checked' : ''}>
                <b>Дүнгээр</b><span>Төлбөрийн дүнгээс</span>
              </label>
            </div>
          </div>
          <div class="form-row">
            <div class="field" id="fldPerService"><label>Жагсаалтад байхгүй үйлчилгээний оноо</label><input class="input num" id="lyDP" type="number" min="0" value="${l.default_points ?? 1}"></div>
            <div class="field" id="fldPerVisit"><label>Ирэлт бүрийн оноо</label><input class="input num" id="lyPPV" type="number" min="1" value="${l.points_per_visit}"></div>
            <div class="field" id="fldPerAmount"><label>1 оноо = хэдэн ₮</label><input class="input num" id="lyAPP" type="number" min="100" step="500" value="${l.amount_per_point}"></div>
          </div>
          <hr style="border:none;border-top:1px dashed var(--border-2);margin:4px 0">
          <div class="field">
            <label>Урамшууллын шат (оноо цуглуулбал)</label>
            <p class="hint" style="margin:-2px 0 8px">Оноо их байх тусам илүү сайн урамшуулал. Багаас их рүү автоматаар эрэмбэлэгдэнэ.</p>
            <div class="reward-editor" id="rewardEditor"></div>
            <button class="btn btn--soft btn--sm" id="rewardAdd" style="margin-top:8px">${ICONS.plus}Шат нэмэх</button>
          </div>
          <hr style="border:none;border-top:1px dashed var(--border-2);margin:4px 0">
          <div class="field">
            <label>Түвшингүүд (нийт оноогоор)</label>
            <div class="tier-editor" id="tierEditor"></div>
            <button class="btn btn--soft btn--sm" id="tierAdd" style="margin-top:8px">${ICONS.plus}Түвшин нэмэх</button>
          </div>
          <hr style="border:none;border-top:1px dashed var(--border-2);margin:4px 0">
          <div class="field">
            <label>Картын бонус</label>
            <p class="hint" style="margin:-2px 0 10px">
              NFC карт холбосон хэрэглэгчид түвшний хөнгөлөлт дээр <b>нэмж</b> тооцогдоно.
              Унтраавал картын бонус огт тооцогдохгүй (түвшний хөнгөлөлт хэвээр).
            </p>
            <label class="toggle" style="margin-bottom:10px">
              <input type="checkbox" id="lyCardOn" ${l.card_bonus_enabled === false ? '' : 'checked'}>
              <span class="toggle__track"></span>
              <span><b>Картын бонус идэвхтэй</b>
                <span class="hint" style="display:block">Карттай хэрэглэгч бүрд автоматаар</span>
              </span>
            </label>
            <div class="form-row">
              <div class="field" id="fldCardPct">
                <label>Картын нэмэлт хувь (%)</label>
                <input class="input num" id="lyCardPct" type="number" min="0" max="50" value="${l.card_bonus_pct ?? 2}">
              </div>
            </div>
          </div>
          <button class="btn btn--primary btn--lg" id="lySave">Дүрэм хадгалах</button>
          <p class="hint">Дүрэм өөрчлөгдөхөд бүх хэрэглэгчийн түвшин автоматаар дахин тооцогдоно. Өмнөх гүйлгээний оноо өөрчлөгдөхгүй.</p>
        </div>
      </div>
    </div>`;

  /* Байгууллага */
  $('#bzSave').onclick = async () => {
    try {
      const res = await api('/api/admin/rules', {
        method: 'PUT',
        body: { business: { name: $('#bzName').value, tagline: $('#bzTag').value, phone: $('#bzPhone').value, hours: $('#bzHours').value, address: $('#bzAddr').value } },
      });
      state.rules.business = res.business;
      $$('[data-biz-name]').forEach((el) => (el.textContent = res.business.name));
      toast('Байгууллагын мэдээлэл хадгалагдлаа');
    } catch (e) { toast(e.message, 'err'); }
  };

  /* Үйлчилгээ editor */
  let svcList = r.services.map((s) => ({ ...s }));
  function renderSvcEditor() {
    $('#svcEditor').innerHTML = svcList
      .map((s, i) => `
        <div class="svc-editor-row">
          <input class="input" data-sn="${i}" value="${esc(s.name)}" placeholder="Үйлчилгээний нэр">
          <input class="input num" data-sp="${i}" type="number" min="0" step="500" value="${s.price}" title="Үнэ (₮)">
          <input class="input num" data-spt="${i}" type="number" min="0" value="${s.points ?? 1}" title="Олгох оноо">
          <button class="btn btn--icon btn--ghost btn--sm" data-sx="${i}" ${svcList.length <= 1 ? 'disabled' : ''}>${ICONS.trash}</button>
        </div>`)
      .join('');
    $$('#svcEditor [data-sn]').forEach((inp) => inp.addEventListener('input', (e) => { svcList[+inp.dataset.sn].name = e.target.value; }));
    $$('#svcEditor [data-sp]').forEach((inp) => inp.addEventListener('input', (e) => { svcList[+inp.dataset.sp].price = +e.target.value || 0; }));
    $$('#svcEditor [data-spt]').forEach((inp) => inp.addEventListener('input', (e) => { svcList[+inp.dataset.spt].points = Math.max(0, +e.target.value || 0); }));
    $$('#svcEditor [data-sx]').forEach((btn) => btn.addEventListener('click', () => { svcList.splice(+btn.dataset.sx, 1); renderSvcEditor(); }));
  }
  renderSvcEditor();
  $('#svcAdd').onclick = () => { if (svcList.length < 12) { svcList.push({ name: '', price: 0 }); renderSvcEditor(); } };
  $('#svcSave').onclick = async () => {
    try {
      const res = await api('/api/admin/rules', { method: 'PUT', body: { services: svcList } });
      state.rules.services = res.services;
      toast('Үйлчилгээний жагсаалт хадгалагдлаа');
    } catch (e) { toast(e.message, 'err'); }
  };

  /* Нууц үг */
  $('#pwSave').onclick = async () => {
    try {
      await api('/api/admin/password', { method: 'POST', body: { current: $('#pwCur').value, next: $('#pwNew').value } });
      $('#pwCur').value = ''; $('#pwNew').value = '';
      toast('Нууц үг солигдлоо');
    } catch (e) { toast(e.message, 'err'); }
  };

  /* Лоялти дүрэм */
  let tiers = l.tiers.map((t) => ({ ...t }));
  let rewardTiers = (l.reward_tiers && l.reward_tiers.length
    ? l.reward_tiers
    : [{ points: l.reward_threshold || 10, title: l.reward_title || 'Урамшуулал', value: l.reward_value || 0 }]
  ).map((t) => ({ ...t }));
  function syncModeFields() {
    const mode = $('input[name="pmode"]:checked').value;
    $('#fldPerService').style.opacity = mode === 'per_service' ? 1 : 0.4;
    $('#fldPerVisit').style.opacity = mode === 'per_visit' ? 1 : 0.4;
    $('#fldPerAmount').style.opacity = mode === 'per_amount' ? 1 : 0.4;
    $('#modeService').classList.toggle('active', mode === 'per_service');
    $('#modeVisit').classList.toggle('active', mode === 'per_visit');
    $('#modeAmount').classList.toggle('active', mode === 'per_amount');
  }
  $$('input[name="pmode"]').forEach((rd) => rd.addEventListener('change', syncModeFields));
  syncModeFields();

  /* Картын бонус — унтраасан үед хувийн талбар бүдгэрч, идэвхгүй болно */
  function syncCardBonus() {
    const on = $('#lyCardOn').checked;
    $('#fldCardPct').style.opacity = on ? 1 : 0.4;
    $('#lyCardPct').disabled = !on;
  }
  $('#lyCardOn').addEventListener('change', syncCardBonus);
  syncCardBonus();

  function renderTierEditor() {
    $('#tierEditor').innerHTML = tiers
      .map((t, i) => `
        <div class="qty-row">
          <input class="input" data-tn="${i}" value="${esc(t.name)}" placeholder="Нэр" style="flex:1.2">
          <input class="input num" data-tm="${i}" type="number" min="0" value="${t.min}" title="Босго оноо" ${i === 0 ? 'disabled' : ''} style="max-width:90px">
          <span style="display:flex;align-items:center;gap:4px">
            <input class="input num" data-td="${i}" type="number" min="0" max="90" value="${t.discount}" title="Хөнгөлөлт %" style="max-width:72px">
            <span class="hint">%</span>
          </span>
          <button class="btn btn--icon btn--ghost btn--sm" data-tx="${i}" ${tiers.length <= 1 || i === 0 ? 'disabled' : ''}>${ICONS.trash}</button>
        </div>`)
      .join('');
    $$('#tierEditor [data-tn]').forEach((inp) => inp.addEventListener('input', (e) => { tiers[+inp.dataset.tn].name = e.target.value; }));
    $$('#tierEditor [data-tm]').forEach((inp) => inp.addEventListener('input', (e) => { tiers[+inp.dataset.tm].min = +e.target.value || 0; }));
    $$('#tierEditor [data-td]').forEach((inp) => inp.addEventListener('input', (e) => { tiers[+inp.dataset.td].discount = +e.target.value || 0; }));
    $$('#tierEditor [data-tx]').forEach((btn) => btn.addEventListener('click', () => { tiers.splice(+btn.dataset.tx, 1); renderTierEditor(); }));
  }
  renderTierEditor();
  $('#tierAdd').onclick = () => {
    if (tiers.length < 6) {
      tiers.push({ key: `tier${tiers.length}${Math.floor(Math.random() * 999)}`, name: '', min: 0, discount: 0 });
      renderTierEditor();
    }
  };

  function renderRewardEditor() {
    $('#rewardEditor').innerHTML = rewardTiers
      .map((t, i) => `
        <div class="reward-editor-row">
          <input class="input num" data-rp="${i}" type="number" min="1" value="${t.points}" title="Босго оноо">
          <input class="input" data-rt="${i}" value="${esc(t.title)}" placeholder="Урамшууллын нэр">
          <input class="input num" data-rv="${i}" type="number" min="0" step="500" value="${t.value}" title="₮ хүртэл хөнгөлнө">
          <button class="btn btn--icon btn--ghost btn--sm" data-rx="${i}" ${rewardTiers.length <= 1 ? 'disabled' : ''}>${ICONS.trash}</button>
        </div>`)
      .join('');
    $$('#rewardEditor [data-rp]').forEach((inp) => inp.addEventListener('input', (e) => { rewardTiers[+inp.dataset.rp].points = +e.target.value || 0; }));
    $$('#rewardEditor [data-rt]').forEach((inp) => inp.addEventListener('input', (e) => { rewardTiers[+inp.dataset.rt].title = e.target.value; }));
    $$('#rewardEditor [data-rv]').forEach((inp) => inp.addEventListener('input', (e) => { rewardTiers[+inp.dataset.rv].value = +e.target.value || 0; }));
    $$('#rewardEditor [data-rx]').forEach((btn) => btn.addEventListener('click', () => { rewardTiers.splice(+btn.dataset.rx, 1); renderRewardEditor(); }));
  }
  renderRewardEditor();
  $('#rewardAdd').onclick = () => {
    if (rewardTiers.length < 8) { rewardTiers.push({ points: 10, title: '', value: 0 }); renderRewardEditor(); }
  };

  $('#lySave').onclick = async () => {
    try {
      const res = await api('/api/admin/rules', {
        method: 'PUT',
        body: {
          loyalty: {
            points_mode: $('input[name="pmode"]:checked').value,
            points_per_visit: +$('#lyPPV').value,
            amount_per_point: +$('#lyAPP').value,
            default_points: +$('#lyDP').value,
            card_bonus_enabled: $('#lyCardOn').checked,
            card_bonus_pct: +$('#lyCardPct').value,
            reward_tiers: rewardTiers,
            tiers,
          },
        },
      });
      state.rules.loyalty = res.loyalty;
      toast('Бонусын дүрэм хадгалагдлаа');
    } catch (e) { toast(e.message, 'err'); }
  };
}

boot();
