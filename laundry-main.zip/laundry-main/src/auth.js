// Админ нэвтрэлт — scrypt нууц үг, SQLite session, cookie.
'use strict';

const crypto = require('node:crypto');
const { db } = require('./db');
const { localDateTime } = require('./lib');

const SESSION_DAYS = 7;

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `s2:${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  try {
    const [tag, salt, hash] = String(stored).split(':');
    if (tag !== 's2') return false;
    const calc = crypto.scryptSync(String(password), salt, 64);
    return crypto.timingSafeEqual(calc, Buffer.from(hash, 'hex'));
  } catch {
    return false;
  }
}

function createSession(username) {
  const token = crypto.randomBytes(32).toString('base64url');
  const now = new Date();
  const exp = new Date(now.getTime() + SESSION_DAYS * 86400_000);
  db.prepare('INSERT INTO sessions (token, username, created_at, expires_at) VALUES (?, ?, ?, ?)').run(
    token,
    username,
    localDateTime(now),
    localDateTime(exp)
  );
  return token;
}

function getSession(token) {
  if (!token) return null;
  const row = db.prepare('SELECT * FROM sessions WHERE token = ?').get(token);
  if (!row) return null;
  if (row.expires_at < localDateTime()) {
    db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
    return null;
  }
  return row;
}

function destroySession(token) {
  if (token) db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
}

function cleanupSessions() {
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(localDateTime());
}

function parseCookies(req) {
  const out = {};
  const raw = req.headers.cookie;
  if (!raw) return out;
  for (const part of raw.split(';')) {
    const i = part.indexOf('=');
    if (i > -1) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function requireAdmin(req, res, next) {
  const session = getSession(parseCookies(req).sid);
  if (!session) return res.status(401).json({ error: 'Нэвтрэх шаардлагатай' });
  req.admin = session.username;
  next();
}

// Нэвтрэх оролдлогын энгийн хязгаарлалт (IP тус бүр 15 минутад 10 удаа)
const attempts = new Map();
function loginRateLimit(req, res, next) {
  const ip = req.ip || req.socket.remoteAddress || '?';
  const now = Date.now();
  let a = attempts.get(ip);
  if (!a || now > a.resetAt) a = { count: 0, resetAt: now + 15 * 60_000 };
  if (a.count >= 10)
    return res.status(429).json({ error: 'Хэт олон оролдлого. 15 минутын дараа дахин оролдоно уу.' });
  a.count++;
  attempts.set(ip, a);
  next();
}
function loginSucceeded(req) {
  attempts.delete(req.ip || req.socket.remoteAddress || '?');
}

// Админ хэрэглэгчийн анхдагч нэвтрэх мэдээлэл.
// Эзэмшигчийн хүсэлтээр энгийн, сануулахад хялбар байхаар тогтоосон.
// ADMIN_PASSWORD орчны хувьсагчаар дарж болно.
const DEFAULT_ADMIN_USER = 'admin';
const DEFAULT_ADMIN_PASS = '12345678';

function setAdminPassword(username, password) {
  const hash = hashPassword(password);
  const exists = db.prepare('SELECT 1 FROM admin_users WHERE username = ?').get(username);
  if (exists) db.prepare('UPDATE admin_users SET password_hash = ? WHERE username = ?').run(hash, username);
  else
    db.prepare('INSERT INTO admin_users (username, password_hash, created_at) VALUES (?, ?, ?)').run(
      username,
      hash,
      localDateTime()
    );
  // Нууц үг солигдоход хуучин session-ууд хүчингүй болно
  db.prepare('DELETE FROM sessions WHERE username = ?').run(username);
}

function ensureDefaultAdmin() {
  const row = db.prepare('SELECT COUNT(*) AS n FROM admin_users').get();
  if (row.n === 0) {
    const pw = process.env.ADMIN_PASSWORD || DEFAULT_ADMIN_PASS;
    setAdminPassword(DEFAULT_ADMIN_USER, pw);
    console.log('==================================================');
    console.log(`  Админ хэрэглэгч үүслээ →  нэр: ${DEFAULT_ADMIN_USER}`);
    console.log(`  Нууц үг:                  ${pw}`);
    console.log('  Аюулгүй байдлын үүднээс Тохиргоо → нууц үг солихыг зөвлөнө.');
    console.log('==================================================');
  }
}

// Санах ой хамгаалах: хугацаа дууссан бичлэгүүдийг тогтмол цэвэрлэнэ (Map хязгааргүй өсөхөөс сэргийлнэ)
setInterval(() => {
  const now = Date.now();
  for (const [ip, a] of attempts) if (now > a.resetAt) attempts.delete(ip);
}, 5 * 60_000).unref();
setInterval(() => cleanupSessions(), 6 * 3600_000).unref();

module.exports = {
  hashPassword,
  verifyPassword,
  createSession,
  destroySession,
  getSession,
  cleanupSessions,
  parseCookies,
  requireAdmin,
  loginRateLimit,
  loginSucceeded,
  ensureDefaultAdmin,
  setAdminPassword,
  DEFAULT_ADMIN_USER,
  DEFAULT_ADMIN_PASS,
};
