// Өгөгдөл цэвэрлэх — `npm run reset`
//
// Ажиллагааны бүх өгөгдлийг (хэрэглэгч, гүйлгээ, промо, эрхийн бичиг, session)
// устгаж СИСТЕМИЙГ ХООСОН ЭХЛЭЛД оруулна. Тохиргоо (байгууллага, бонусын дүрэм,
// үйлчилгээний үнэ), админ хэрэглэгч, төхөөрөмжийн түлхүүр ХЭВЭЭР үлдэнэ —
// тиймээс терминал болон нэвтрэлт цэвэрлэсний дараа шууд ажиллана.
//
// Аюулгүй байдал: бодит серверт санамсаргүй ажиллуулахаас сэргийлж
// баталгаажуулалт асууна. Асуулгүй ажиллуулах бол:  npm run reset -- --yes
'use strict';

const readline = require('node:readline');
const { db, DB_PATH } = require('./db');

const TABLES = ['transactions', 'customers', 'promo_codes', 'vouchers', 'sessions'];

function counts() {
  const out = {};
  for (const t of TABLES) out[t] = db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get().n;
  return out;
}

function wipe() {
  db.exec('BEGIN');
  try {
    // transactions эхэлж — customers дээр FK байгаа
    for (const t of TABLES) db.exec(`DELETE FROM ${t}`);
    db.exec("DELETE FROM sqlite_sequence WHERE name IN ('transactions')");
    db.exec('COMMIT');
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
  db.exec('VACUUM');
}

function report(label, c) {
  console.log(
    `  ${label}: хэрэглэгч ${c.customers}, гүйлгээ ${c.transactions}, ` +
      `промо ${c.promo_codes}, эрхийн бичиг ${c.vouchers}, session ${c.sessions}`
  );
}

function run() {
  const before = counts();
  wipe();
  const after = counts();
  console.log('\n✓ Өгөгдөл цэвэрлэгдлээ');
  report('Өмнө', before);
  report('Одоо', after);
  console.log('\nҮлдсэн (зориудаар): тохиргоо, бонусын дүрэм, админ хэрэглэгч, төхөөрөмжийн түлхүүр.\n');
}

const auto = process.argv.includes('--yes') || process.argv.includes('-y');
console.log(`\n⚠  ЦЭВЭРЛЭХ ӨГӨГДЛИЙН САН: ${DB_PATH}`);
report('Одоогийн', counts());

if (auto) {
  run();
} else {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  rl.question('\nБүх хэрэглэгч, гүйлгээг УСТГАХ уу? Батлахын тулд "ustga" гэж бичнэ үү: ', (a) => {
    rl.close();
    if (String(a).trim().toLowerCase() === 'ustga') run();
    else console.log('\n✗ Цуцлагдлаа — юу ч устгасангүй.\n');
  });
}
