// Төхөөрөмж ↔ админ хоорондын түр төлөв (нэг процесс, санах ойд хадгална).
// - lastScan: төхөөрөмж дээр хамгийн сүүлд уншсан карт (админ хуудас poll хийж харна)
// - bindArm : админ "энэ хэрэглэгчид дараагийн картыг холбо" гэж армласан төлөв
'use strict';

let lastScan = null; // { uid, phone, name, intent, at }
let bindArm = null; // { phone, expiresAt }

function recordScan(s) {
  lastScan = {
    uid: s.uid || null,
    phone: s.phone || null,
    name: s.name || null,
    intent: s.intent || 'balance',
    at: Date.now(),
  };
  return lastScan;
}

function getLastScan() {
  if (!lastScan) return { scan: null };
  return { scan: { ...lastScan, age_ms: Date.now() - lastScan.at } };
}

function armBind(phone, ttlMs) {
  bindArm = { phone, expiresAt: Date.now() + (ttlMs || 90_000) };
}

// Нэг удаагийн: армласан утсыг буцааж, армыг цэвэрлэнэ (хугацаа дууссан бол null)
function consumeBindArm() {
  if (!bindArm) return null;
  if (Date.now() > bindArm.expiresAt) {
    bindArm = null;
    return null;
  }
  const phone = bindArm.phone;
  bindArm = null;
  return phone;
}

function peekBindArm() {
  if (!bindArm) return null;
  if (Date.now() > bindArm.expiresAt) {
    bindArm = null;
    return null;
  }
  return { phone: bindArm.phone, expires_in: Math.round((bindArm.expiresAt - Date.now()) / 1000) };
}

function clearBind() {
  bindArm = null;
}

module.exports = { recordScan, getLastScan, armBind, consumeBindArm, peekBindArm, clearBind };
