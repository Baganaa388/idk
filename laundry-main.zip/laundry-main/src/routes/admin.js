// Админ API — нэвтрэлт шаардана. Системийн гол удирдлага энд.
'use strict';

const express = require('express');
const { db, getSetting, setSetting, defaultServicePoints } = require('../db');
const auth = require('../auth');
const {
  isPhone,
  localDate,
  localDateTime,
  quote,
  getCustomer,
  createCustomer,
  recordTransaction,
  reverseTransaction,
  setCustomerNfc,
  findPromo,
  promoStatus,
  findVoucher,
  voucherStatus,
  generateVoucherCode,
} = require('../lib');
const deviceState = require('../device-state');

const router = express.Router();

// ---------- Нэвтрэлт ----------
router.post('/login', auth.loginRateLimit, (req, res) => {
  const { username, password } = req.body || {};
  const user = db.prepare('SELECT * FROM admin_users WHERE username = ?').get(String(username || ''));
  if (!user || !auth.verifyPassword(password, user.password_hash))
    return res.status(401).json({ error: 'Нэвтрэх нэр эсвэл нууц үг буруу байна' });
  auth.loginSucceeded(req);
  const token = auth.createSession(user.username);
  const secure = req.secure ? '; Secure' : '';
  res.setHeader('Set-Cookie', `sid=${token}; HttpOnly; Path=/; SameSite=Strict${secure}; Max-Age=${7 * 86400}`);
  res.json({ ok: true, username: user.username });
});

router.post('/logout', (req, res) => {
  auth.destroySession(auth.parseCookies(req).sid);
  const secure = req.secure ? '; Secure' : '';
  res.setHeader('Set-Cookie', `sid=; HttpOnly; Path=/; SameSite=Strict${secure}; Max-Age=0`);
  res.json({ ok: true });
});

// Эндээс доош бүх зам нэвтрэлт шаардана
router.use(auth.requireAdmin);

router.get('/me', (req, res) => res.json({ username: req.admin }));

router.post('/password', (req, res) => {
  const { current, next } = req.body || {};
  const user = db.prepare('SELECT * FROM admin_users WHERE username = ?').get(req.admin);
  if (!auth.verifyPassword(current, user.password_hash))
    return res.status(400).json({ error: 'Одоогийн нууц үг буруу байна' });
  if (typeof next !== 'string' || next.length < 6)
    return res.status(400).json({ error: 'Шинэ нууц үг дор хаяж 6 тэмдэгт байх ёстой' });
  db.prepare('UPDATE admin_users SET password_hash = ? WHERE username = ?').run(
    auth.hashPassword(next),
    req.admin
  );
  res.json({ ok: true });
});

// ---------- Хяналтын самбар ----------
router.get('/dashboard', (req, res) => {
  const today = localDate();
  const month = today.slice(0, 7);
  const g = (sql, ...p) => db.prepare(sql).get(...p);

  const todayRow = g(
    "SELECT COALESCE(SUM(amount),0) AS revenue, COUNT(*) AS cnt FROM transactions WHERE substr(date,1,10) = ?",
    today
  );
  const monthRow = g(
    "SELECT COALESCE(SUM(amount),0) AS revenue, COUNT(*) AS cnt FROM transactions WHERE substr(date,1,7) = ?",
    month
  );
  const customers = g('SELECT COUNT(*) AS n FROM customers').n;
  const newCustomers = g(
    'SELECT COUNT(*) AS n FROM customers WHERE substr(created_at,1,7) = ?',
    month
  ).n;

  res.json({
    today: todayRow,
    month: monthRow,
    customers,
    new_customers: newCustomers,
    series: daySeries(30),
    recent: db
      .prepare(
        `SELECT t.id, t.date, t.customer_phone, c.name, t.service_type, t.amount,
                t.payment_method, t.points_earned, t.points_redeemed
         FROM transactions t JOIN customers c ON c.phone = t.customer_phone
         ORDER BY t.date DESC, t.id DESC LIMIT 8`
      )
      .all(),
  });
});

function daySeries(days) {
  const from = new Date();
  from.setDate(from.getDate() - (days - 1));
  const fromStr = localDate(from);
  const rows = db
    .prepare(
      `SELECT substr(date,1,10) AS p, SUM(amount) AS revenue, COUNT(*) AS cnt
       FROM transactions WHERE substr(date,1,10) >= ? GROUP BY p`
    )
    .all(fromStr);
  const map = new Map(rows.map((r) => [r.p, r]));
  const out = [];
  const d = new Date(from);
  for (let i = 0; i < days; i++) {
    const key = localDate(d);
    const r = map.get(key);
    out.push({ p: key, revenue: r ? r.revenue : 0, cnt: r ? r.cnt : 0 });
    d.setDate(d.getDate() + 1);
  }
  return out;
}

// ---------- Хэрэглэгчид ----------
router.get('/customers', (req, res) => {
  const q = String(req.query.q || '').trim();
  const limit = Math.min(200, Math.max(1, parseInt(req.query.limit) || 50));
  const offset = Math.max(0, parseInt(req.query.offset) || 0);
  const like = `%${q}%`;
  const where = q ? 'WHERE c.phone LIKE ? OR c.name LIKE ?' : '';
  const params = q ? [like, like] : [];
  const total = db
    .prepare(`SELECT COUNT(*) AS n FROM customers c ${where}`)
    .get(...params).n;
  const rows = db
    .prepare(
      `SELECT c.*,
              (SELECT MAX(date) FROM transactions t WHERE t.customer_phone = c.phone) AS last_visit
       FROM customers c ${where}
       ORDER BY COALESCE(last_visit, c.created_at) DESC
       LIMIT ? OFFSET ?`
    )
    .all(...params, limit, offset);
  res.json({ rows, total });
});

router.post('/customers', (req, res) => {
  const phone = String(req.body?.phone || '').replace(/\D/g, '');
  if (!isPhone(phone)) return res.status(400).json({ error: 'Утасны дугаар 8 оронтой байх ёстой' });
  if (getCustomer(phone)) return res.status(409).json({ error: 'Энэ дугаар аль хэдийн бүртгэлтэй байна' });
  res.json({ customer: createCustomer(phone, req.body?.name) });
});

router.get('/customers/:phone', (req, res) => {
  const c = getCustomer(req.params.phone);
  if (!c) return res.status(404).json({ error: 'Хэрэглэгч олдсонгүй' });
  const transactions = db
    .prepare('SELECT * FROM transactions WHERE customer_phone = ? ORDER BY date DESC, id DESC LIMIT 200')
    .all(c.phone);
  res.json({ customer: c, transactions, loyalty: getSetting('loyalty') });
});

router.put('/customers/:phone', (req, res, next) => {
  try {
    const c = getCustomer(req.params.phone);
    if (!c) return res.status(404).json({ error: 'Хэрэглэгч олдсонгүй' });
    if (typeof req.body?.name === 'string')
      db.prepare('UPDATE customers SET name = ? WHERE phone = ?').run(
        req.body.name.trim().slice(0, 60),
        c.phone
      );
    if (req.body && 'nfc_uid' in req.body) setCustomerNfc(c.phone, req.body.nfc_uid); // 409/400 шидэж болно
    res.json({ customer: getCustomer(c.phone) });
  } catch (e) {
    next(e);
  }
});

// ---------- Төхөөрөмж (NFC терминал) ↔ админ ----------
// Төхөөрөмжийн API түлхүүр (firmware-т тавихад) — зөвхөн нэвтэрсэн админд
router.get('/device/key', (req, res) =>
  res.json({ key: process.env.DEVICE_KEY || getSetting('device_key') || '' })
);

// Сүүлийн уншилт (poll хийж "картаа уншуулсан хэрэглэгч"-ийг харна)
router.get('/device/last-scan', (req, res) => res.json(deviceState.getLastScan()));

// "Дараагийн уншсан картыг энэ хэрэглэгчид холбо" гэж армлах
router.post('/device/bind-arm', (req, res) => {
  const phone = String(req.body?.phone || '').replace(/\D/g, '');
  if (!isPhone(phone)) return res.status(400).json({ error: 'Утасны дугаар буруу байна' });
  if (!getCustomer(phone)) return res.status(404).json({ error: 'Хэрэглэгч олдсонгүй' });
  deviceState.armBind(phone, 90_000);
  res.json({ ok: true, phone, expires_in: 90 });
});

router.post('/device/bind-cancel', (req, res) => {
  deviceState.clearBind();
  res.json({ ok: true });
});

router.delete('/customers/:phone', (req, res) => {
  const c = getCustomer(req.params.phone);
  if (!c) return res.status(404).json({ error: 'Хэрэглэгч олдсонгүй' });
  db.prepare('DELETE FROM customers WHERE phone = ?').run(c.phone);
  res.json({ ok: true });
});

// ---------- Үйлчилгээ бүртгэх ----------
// Урьдчилсан тооцоо (хадгалахгүй) — форм бөглөх явцад шууд харагдана
router.post('/quote', (req, res) => {
  const b = req.body || {};
  const customer = isPhone(String(b.phone || '')) ? getCustomer(b.phone) : null;
  const q = quote({
    customer,
    items: b.items,
    amount: b.amount,
    service_type: b.service_type,
    promo_code: b.promo_code,
    voucher_code: b.voucher_code,
    redeem: b.redeem,
    reward_points: b.reward_points,
  });
  res.json({ quote: q, customer });
});

router.post('/transactions', (req, res, next) => {
  try {
    const b = req.body || {};
    const result = recordTransaction({
      phone: String(b.phone || '').replace(/\D/g, ''),
      name: b.name,
      create_if_missing: !!b.create_if_missing,
      items: b.items,
      amount: b.amount,
      service_type: b.service_type,
      promo_code: b.promo_code,
      voucher_code: b.voucher_code,
      redeem: !!b.redeem,
      reward_points: b.reward_points,
      payment_method: b.payment_method,
      date: validDateTime(b.date),
      note: b.note,
    });
    res.json(result);
  } catch (e) {
    next(e);
  }
});

router.get('/transactions', (req, res) => {
  const date = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.date || '')) ? req.query.date : localDate();
  const rows = db
    .prepare(
      `SELECT t.*, c.name FROM transactions t JOIN customers c ON c.phone = t.customer_phone
       WHERE substr(t.date,1,10) = ? ORDER BY t.date DESC, t.id DESC`
    )
    .all(date);
  const total = rows.reduce((s, r) => s + r.amount, 0);
  res.json({ date, rows, total });
});

router.delete('/transactions/:id', (req, res, next) => {
  try {
    res.json(reverseTransaction(parseInt(req.params.id)));
  } catch (e) {
    next(e);
  }
});

function validDateTime(s) {
  if (typeof s !== 'string') return undefined;
  const m = s.match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})(:\d{2})?$/);
  if (!m) return undefined;
  return `${m[1]} ${m[2]}${m[3] || ':00'}`;
}

// ---------- Промо код ----------
router.get('/promos', (req, res) => {
  const today = localDate();
  const rows = db.prepare('SELECT * FROM promo_codes ORDER BY is_active DESC, valid_to DESC').all();
  res.json({
    rows: rows.map((r) => ({ ...r, live: promoStatus(r, today).ok })),
  });
});

function promoPayload(body, existing) {
  const type = ['percent', 'fixed'].includes(body.type) ? body.type : null;
  const value = Math.floor(Number(body.value) || 0);
  const from = String(body.valid_from || '');
  const to = String(body.valid_to || '');
  const limit = Math.max(0, Math.floor(Number(body.usage_limit) || 0));
  const errors = [];
  if (!type) errors.push('Төрөл сонгоно уу');
  if (type === 'percent' && (value < 1 || value > 100)) errors.push('Хувь 1–100 байх ёстой');
  if (type === 'fixed' && (value < 1 || value > 10_000_000)) errors.push('Дүн буруу байна');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to) || from > to)
    errors.push('Хүчинтэй хугацаа буруу байна');
  return {
    errors,
    row: {
      type,
      value,
      valid_from: from,
      valid_to: to,
      usage_limit: limit,
      is_active: body.is_active === false || body.is_active === 0 ? 0 : 1,
      description: String(body.description || '').trim().slice(0, 120),
    },
  };
}

router.post('/promos', (req, res) => {
  const code = String(req.body?.code || '').trim().toUpperCase();
  if (!/^[A-Z0-9]{3,20}$/.test(code))
    return res.status(400).json({ error: 'Код 3–20 латин үсэг/тоо байх ёстой' });
  if (findPromo(code)) return res.status(409).json({ error: 'Энэ код аль хэдийн байна' });
  const { errors, row } = promoPayload(req.body || {});
  if (errors.length) return res.status(400).json({ error: errors.join('. ') });
  db.prepare(
    `INSERT INTO promo_codes (code, type, value, valid_from, valid_to, usage_limit, is_active, description)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(code, row.type, row.value, row.valid_from, row.valid_to, row.usage_limit, row.is_active, row.description);
  res.json({ promo: findPromo(code) });
});

router.put('/promos/:code', (req, res) => {
  const promo = findPromo(req.params.code);
  if (!promo) return res.status(404).json({ error: 'Промо код олдсонгүй' });
  // Зөвхөн идэвх солих богино хүсэлт
  if (Object.keys(req.body || {}).length === 1 && 'is_active' in req.body) {
    db.prepare('UPDATE promo_codes SET is_active = ? WHERE code = ?').run(
      req.body.is_active ? 1 : 0,
      promo.code
    );
    return res.json({ promo: findPromo(promo.code) });
  }
  const { errors, row } = promoPayload(req.body || {}, promo);
  if (errors.length) return res.status(400).json({ error: errors.join('. ') });
  db.prepare(
    `UPDATE promo_codes SET type=?, value=?, valid_from=?, valid_to=?, usage_limit=?, is_active=?, description=?
     WHERE code=?`
  ).run(row.type, row.value, row.valid_from, row.valid_to, row.usage_limit, row.is_active, row.description, promo.code);
  res.json({ promo: findPromo(promo.code) });
});

router.delete('/promos/:code', (req, res) => {
  const promo = findPromo(req.params.code);
  if (!promo) return res.status(404).json({ error: 'Промо код олдсонгүй' });
  if (promo.used_count > 0)
    return res
      .status(400)
      .json({ error: 'Ашиглагдсан кодыг устгахгүй — идэвхгүй болгоно уу (түүх хадгалагдана)' });
  db.prepare('DELETE FROM promo_codes WHERE code = ?').run(promo.code);
  res.json({ ok: true });
});

// ---------- Эрхийн бичиг (voucher) ----------
router.get('/vouchers', (req, res) => {
  const today = localDate();
  const rows = db
    .prepare("SELECT * FROM vouchers ORDER BY (status='active') DESC, created_at DESC")
    .all();
  res.json({ rows: rows.map((v) => ({ ...v, live: voucherStatus(v, today).ok })) });
});

router.get('/vouchers/:code', (req, res) => {
  const v = findVoucher(req.params.code);
  if (!v) return res.status(404).json({ error: 'Эрхийн бичиг олдсонгүй' });
  res.json({ voucher: v });
});

function voucherPayload(body) {
  const type = ['percent', 'fixed'].includes(body.type) ? body.type : null;
  const value = Math.floor(Number(body.value) || 0);
  const to = String(body.valid_to || '');
  const errors = [];
  if (!type) errors.push('Төрөл сонгоно уу');
  if (type === 'percent' && (value < 1 || value > 100)) errors.push('Хувь 1–100 байх ёстой');
  if (type === 'fixed' && (value < 1 || value > 10_000_000)) errors.push('Дүн буруу байна');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(to)) errors.push('Дуусах хугацаа буруу байна');
  else if (to < localDate()) errors.push('Дуусах хугацаа өнгөрсөн байна');
  const s = (v, max) => String(v ?? '').trim().slice(0, max);
  const defTitle = type === 'percent' ? `${value}% хөнгөлөлт` : `${value.toLocaleString('en-US')}₮ бэлэг`;
  return {
    errors,
    row: {
      type,
      value,
      title: s(body.title, 60) || defTitle,
      recipient: s(body.recipient, 40),
      sender: s(body.sender, 40),
      message: s(body.message, 200),
      valid_to: to,
    },
  };
}

router.post('/vouchers', (req, res) => {
  const { errors, row } = voucherPayload(req.body || {});
  if (errors.length) return res.status(400).json({ error: errors.join('. ') });
  const code = generateVoucherCode();
  db.prepare(
    `INSERT INTO vouchers (code, type, value, title, recipient, sender, message, created_at, valid_to, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')`
  ).run(code, row.type, row.value, row.title, row.recipient, row.sender, row.message, localDateTime(), row.valid_to);
  res.json({ voucher: findVoucher(code) });
});

// Идэвх солих (цуцлах / сэргээх) — ашиглагдсаныг өөрчлөхгүй
router.put('/vouchers/:code', (req, res) => {
  const v = findVoucher(req.params.code);
  if (!v) return res.status(404).json({ error: 'Эрхийн бичиг олдсонгүй' });
  if (v.status === 'redeemed')
    return res.status(400).json({ error: 'Ашиглагдсан эрхийн бичгийг өөрчлөх боломжгүй' });
  const next = req.body?.status === 'void' ? 'void' : 'active';
  db.prepare('UPDATE vouchers SET status = ? WHERE code = ?').run(next, v.code);
  res.json({ voucher: findVoucher(v.code) });
});

router.delete('/vouchers/:code', (req, res) => {
  const v = findVoucher(req.params.code);
  if (!v) return res.status(404).json({ error: 'Эрхийн бичиг олдсонгүй' });
  if (v.status === 'redeemed')
    return res.status(400).json({ error: 'Ашиглагдсан эрхийн бичгийг устгах боломжгүй (түүх хадгалагдана)' });
  db.prepare('DELETE FROM vouchers WHERE code = ?').run(v.code);
  res.json({ ok: true });
});

// ---------- Дүрэм / Тохиргоо ----------
router.get('/rules', (req, res) => {
  res.json({
    business: getSetting('business'),
    loyalty: getSetting('loyalty'),
    services: getSetting('services'),
  });
});

router.put('/rules', (req, res) => {
  const b = req.body || {};
  const errors = [];

  if (b.business) {
    const cur = getSetting('business');
    const s = (v, max) => String(v ?? '').trim().slice(0, max);
    setSetting('business', {
      name: s(b.business.name, 60) || cur.name,
      tagline: s(b.business.tagline, 120),
      phone: s(b.business.phone, 30),
      address: s(b.business.address, 160),
      hours: s(b.business.hours, 80),
    });
  }

  if (b.loyalty) {
    const l = b.loyalty;
    const num = (v, min, max, dflt) => {
      const n = Math.floor(Number(v));
      return Number.isFinite(n) && n >= min && n <= max ? n : dflt;
    };
    const mode = ['per_visit', 'per_amount', 'per_service'].includes(l.points_mode)
      ? l.points_mode
      : 'per_service';

    // Урамшууллын шат (reward ladder) — өгөгдөөгүй бол хуучныг хадгална
    const prevLoyalty = getSetting('loyalty');
    let rewardTiers = Array.isArray(l.reward_tiers) ? l.reward_tiers : prevLoyalty.reward_tiers;
    rewardTiers = (Array.isArray(rewardTiers) ? rewardTiers : [])
      .slice(0, 8)
      .map((t) => ({
        points: num(t.points, 1, 100000, 10),
        title: String(t.title || '').trim().slice(0, 60) || 'Урамшуулал',
        value: num(t.value, 0, 10_000_000, 0),
      }))
      .sort((a, b2) => a.points - b2.points);
    if (!rewardTiers.length) errors.push('Дор хаяж нэг урамшууллын шат байх ёстой');

    let tiers = Array.isArray(l.tiers) ? l.tiers.slice(0, 6) : [];
    tiers = tiers
      .map((t, i) => ({
        key: String(t.key || `tier${i}`).toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20) || `tier${i}`,
        name: String(t.name || '').trim().slice(0, 30) || `Түвшин ${i + 1}`,
        min: num(t.min, 0, 1_000_000, 0),
        discount: num(t.discount, 0, 90, 0),
      }))
      .sort((a, b2) => a.min - b2.min);
    if (!tiers.length || tiers[0].min !== 0) errors.push('Эхний түвшний босго 0 байх ёстой');
    const keys = new Set(tiers.map((t) => t.key));
    if (keys.size !== tiers.length) errors.push('Түвшний key давхардаж байна');
    if (!errors.length) {
      const firstReward = rewardTiers[0];
      setSetting('loyalty', {
        points_mode: mode,
        points_per_visit: num(l.points_per_visit, 1, 1000, 1),
        amount_per_point: num(l.amount_per_point, 100, 10_000_000, 10000),
        default_points: num(l.default_points, 0, 1000, 1),
        // Картын бонус — өгөгдөөгүй бол хуучин утгыг хадгална
        card_bonus_enabled:
          typeof l.card_bonus_enabled === 'boolean'
            ? l.card_bonus_enabled
            : prevLoyalty.card_bonus_enabled !== false,
        card_bonus_pct: num(
          l.card_bonus_pct,
          0,
          50,
          Number.isFinite(Number(prevLoyalty.card_bonus_pct)) ? Number(prevLoyalty.card_bonus_pct) : 2
        ),
        reward_tiers: rewardTiers,
        // Хуучин нэг урамшууллын талбарууд — эхний шаттай ижил (нийцтэй байдал)
        reward_threshold: firstReward.points,
        reward_title: firstReward.title,
        reward_value: firstReward.value,
        tiers,
      });
      // Түвшин өөрчлөгдсөн тул бүх хэрэглэгчийн түвшинг шинэчилнэ
      const all = db.prepare('SELECT phone, lifetime_points, tier FROM customers').all();
      const upd = db.prepare('UPDATE customers SET tier = ? WHERE phone = ?');
      for (const c of all) {
        let cur = tiers[0];
        for (const t of tiers) if (c.lifetime_points >= t.min) cur = t;
        if (cur.key !== c.tier) upd.run(cur.key, c.phone);
      }
    }
  }

  if (b.services) {
    const prev = getSetting('services');
    const prevPts = new Map((Array.isArray(prev) ? prev : []).map((s) => [s.name, s.points]));
    const list = (Array.isArray(b.services) ? b.services : [])
      .map((s) => {
        const name = String(s.name || '').trim().slice(0, 60);
        const price = Math.max(0, Math.floor(Number(s.price) || 0));
        // Оноог өгсөн бол хэрэглэнэ; эс бол хуучин утга, түүнгүй бол нэрнээс тааварлана
        let points;
        if (s.points !== undefined && s.points !== null && s.points !== '' && Number.isFinite(Number(s.points))) {
          points = Math.max(0, Math.min(1000, Math.floor(Number(s.points))));
        } else if (prevPts.has(name)) {
          points = prevPts.get(name);
        } else {
          points = defaultServicePoints(name);
        }
        return { name, price, points };
      })
      .filter((s) => s.name)
      .slice(0, 12);
    if (!list.length) errors.push('Дор хаяж нэг үйлчилгээ байх ёстой');
    else setSetting('services', list);
  }

  if (errors.length) return res.status(400).json({ error: errors.join('. ') });
  res.json({
    business: getSetting('business'),
    loyalty: getSetting('loyalty'),
    services: getSetting('services'),
  });
});

// ---------- Тайлан ----------
router.get('/reports', (req, res) => {
  const group = ['day', 'month', 'year'].includes(req.query.group) ? req.query.group : 'day';

  let fromStr = '';
  let series;
  if (group === 'day') {
    series = daySeries(30);
    fromStr = series[0].p;
  } else if (group === 'month') {
    const d = new Date();
    d.setMonth(d.getMonth() - 11);
    fromStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`;
    const rows = db
      .prepare(
        `SELECT substr(date,1,7) AS p, SUM(amount) AS revenue, COUNT(*) AS cnt
         FROM transactions WHERE substr(date,1,10) >= ? GROUP BY p ORDER BY p`
      )
      .all(fromStr);
    const map = new Map(rows.map((r) => [r.p, r]));
    series = [];
    for (let i = 0; i < 12; i++) {
      const m = new Date(d.getFullYear(), d.getMonth() + i, 1);
      const key = `${m.getFullYear()}-${String(m.getMonth() + 1).padStart(2, '0')}`;
      const r = map.get(key);
      series.push({ p: key, revenue: r ? r.revenue : 0, cnt: r ? r.cnt : 0 });
    }
  } else {
    fromStr = '0000';
    series = db
      .prepare(
        `SELECT substr(date,1,4) AS p, SUM(amount) AS revenue, COUNT(*) AS cnt
         FROM transactions GROUP BY p ORDER BY p`
      )
      .all();
  }

  const txs = db
    .prepare(
      `SELECT date, amount, subtotal, payment_method, items, service_type, customer_phone
       FROM transactions WHERE substr(date,1,10) >= ?`
    )
    .all(group === 'year' ? '0000' : fromStr);

  const totals = {
    revenue: txs.reduce((s, t) => s + t.amount, 0),
    cnt: txs.length,
    avg: txs.length ? Math.round(txs.reduce((s, t) => s + t.amount, 0) / txs.length) : 0,
    customers: new Set(txs.map((t) => t.customer_phone)).size,
  };

  // Үйлчилгээний задаргаа (items JSON-оос)
  const svc = new Map();
  const pay = new Map();
  const weekday = Array(7).fill(0); // 0=Даваа ... 6=Ням
  const hour = Array(24).fill(0);
  for (const t of txs) {
    pay.set(t.payment_method, (pay.get(t.payment_method) || 0) + t.amount);
    const jd = new Date(t.date.replace(' ', 'T'));
    if (!isNaN(jd)) {
      weekday[(jd.getDay() + 6) % 7]++;
      hour[jd.getHours()]++;
    }
    let parsed = null;
    try {
      parsed = t.items ? JSON.parse(t.items) : null;
    } catch {}
    if (Array.isArray(parsed) && parsed.length) {
      for (const it of parsed) {
        const cur = svc.get(it.name) || { revenue: 0, qty: 0 };
        cur.revenue += (it.qty || 0) * (it.price || 0);
        cur.qty += it.qty || 0;
        svc.set(it.name, cur);
      }
    } else {
      const cur = svc.get(t.service_type) || { revenue: 0, qty: 0 };
      cur.revenue += t.subtotal;
      cur.qty += 1;
      svc.set(t.service_type, cur);
    }
  }
  let services = [...svc.entries()]
    .map(([name, v]) => ({ name, ...v }))
    .sort((a, b) => b.revenue - a.revenue);
  if (services.length > 6) {
    const rest = services.slice(5);
    services = services.slice(0, 5);
    services.push({
      name: 'Бусад',
      revenue: rest.reduce((s, r) => s + r.revenue, 0),
      qty: rest.reduce((s, r) => s + r.qty, 0),
    });
  }

  const top = db
    .prepare(
      `SELECT t.customer_phone AS phone, c.name, SUM(t.amount) AS revenue, COUNT(*) AS cnt,
              c.tier, c.points
       FROM transactions t JOIN customers c ON c.phone = t.customer_phone
       WHERE substr(t.date,1,10) >= ?
       GROUP BY t.customer_phone ORDER BY revenue DESC LIMIT 10`
    )
    .all(group === 'year' ? '0000' : fromStr);

  res.json({
    group,
    series,
    totals,
    top,
    services,
    payments: [...pay.entries()].map(([method, revenue]) => ({ method, revenue })),
    weekday,
    hour,
  });
});

// ---------- CSV экспорт ----------
function csvEscape(v) {
  let s = String(v ?? '');
  // CSV томьёо-тарилгаас сэргийлэх: =,+,-,@,tab,CR-ээр эхэлсэн ТЕКСТ-ийн өмнө ' тавина
  // (цэвэр тоо — сөрөг дүн ч — хөндөхгүй тул тайлангийн тоонууд зөв хэвээр).
  if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+(\.\d+)?$/.test(s)) s = "'" + s;
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
function sendCsv(res, filename, header, rows) {
  // ﻿ (BOM) — Excel кирилл текстийг зөв нээхэд шаардлагатай
  const body = '﻿' + [header, ...rows].map((r) => r.map(csvEscape).join(',')).join('\r\n');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.send(body);
}

router.get('/export/transactions.csv', (req, res) => {
  const from = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.from || '')) ? req.query.from : '0000-01-01';
  const to = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.to || '')) ? req.query.to : '9999-12-31';
  const rows = db
    .prepare(
      `SELECT t.*, c.name FROM transactions t JOIN customers c ON c.phone = t.customer_phone
       WHERE substr(t.date,1,10) BETWEEN ? AND ? ORDER BY t.date`
    )
    .all(from, to);
  sendCsv(
    res,
    `guilgee_${from}_${to}.csv`,
    ['Огноо', 'Утас', 'Нэр', 'Үйлчилгээ', 'Нийт дүн', 'Түвшний хөнг.', 'Картын бонус', 'Нийт хөнгөлөлт', 'Төлсөн', 'Төлбөр', 'Оноо+', 'Оноо-', 'Промо', 'Тэмдэглэл'],
    rows.map((t) => [
      t.date, t.customer_phone, t.name, t.service_type, t.subtotal,
      t.tier_discount, t.card_discount || 0,
      t.tier_discount + (t.card_discount || 0) + t.promo_discount + (t.voucher_discount || 0) + t.redeem_discount,
      t.amount,
      t.payment_method, t.points_earned, t.points_redeemed, t.promo_code || '', t.note,
    ])
  );
});

router.get('/export/customers.csv', (req, res) => {
  const rows = db
    .prepare(
      `SELECT c.*, (SELECT MAX(date) FROM transactions t WHERE t.customer_phone = c.phone) AS last_visit
       FROM customers c ORDER BY c.total_spent DESC`
    )
    .all();
  sendCsv(
    res,
    'hereglegchid.csv',
    ['Утас', 'Нэр', 'Бүртгүүлсэн', 'Ирсэн тоо', 'Нийт зарцуулалт', 'Оноо', 'Нийт оноо', 'Түвшин', 'Сүүлд ирсэн'],
    rows.map((c) => [
      c.phone, c.name, c.created_at, c.total_visits, c.total_spent,
      c.points, c.lifetime_points, c.tier, c.last_visit || '',
    ])
  );
});

module.exports = router;
