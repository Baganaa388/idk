// Өгөгдлийн сан — Node 22+ built-in SQLite (node:sqlite), нэмэлт хамаарал шаардлагагүй.
'use strict';

const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'laundry.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

db.exec(`
CREATE TABLE IF NOT EXISTS customers (
  phone           TEXT PRIMARY KEY,
  name            TEXT NOT NULL DEFAULT '',
  created_at      TEXT NOT NULL,
  total_visits    INTEGER NOT NULL DEFAULT 0,
  total_spent     INTEGER NOT NULL DEFAULT 0,
  points          INTEGER NOT NULL DEFAULT 0,
  lifetime_points INTEGER NOT NULL DEFAULT 0,
  tier            TEXT NOT NULL DEFAULT 'bronze'
);

CREATE TABLE IF NOT EXISTS transactions (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_phone  TEXT NOT NULL REFERENCES customers(phone) ON DELETE CASCADE,
  date            TEXT NOT NULL,
  service_type    TEXT NOT NULL,
  items           TEXT,
  subtotal        INTEGER NOT NULL,
  tier_discount   INTEGER NOT NULL DEFAULT 0,
  promo_code      TEXT,
  promo_discount  INTEGER NOT NULL DEFAULT 0,
  points_redeemed INTEGER NOT NULL DEFAULT 0,
  redeem_discount INTEGER NOT NULL DEFAULT 0,
  amount          INTEGER NOT NULL,
  payment_method  TEXT NOT NULL DEFAULT 'Бэлэн',
  points_earned   INTEGER NOT NULL DEFAULT 0,
  note            TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_tx_phone ON transactions(customer_phone);
CREATE INDEX IF NOT EXISTS idx_tx_date  ON transactions(date);

CREATE TABLE IF NOT EXISTS promo_codes (
  code        TEXT PRIMARY KEY,
  type        TEXT NOT NULL CHECK (type IN ('percent','fixed')),
  value       INTEGER NOT NULL,
  valid_from  TEXT NOT NULL,
  valid_to    TEXT NOT NULL,
  usage_limit INTEGER NOT NULL DEFAULT 0,
  used_count  INTEGER NOT NULL DEFAULT 0,
  is_active   INTEGER NOT NULL DEFAULT 1,
  description TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS vouchers (
  code           TEXT PRIMARY KEY,
  type           TEXT NOT NULL CHECK (type IN ('percent','fixed')),
  value          INTEGER NOT NULL,
  title          TEXT NOT NULL DEFAULT '',
  recipient      TEXT NOT NULL DEFAULT '',
  sender         TEXT NOT NULL DEFAULT '',
  message        TEXT NOT NULL DEFAULT '',
  created_at     TEXT NOT NULL,
  valid_to       TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'active',
  redeemed_at    TEXT,
  redeemed_phone TEXT
);

CREATE TABLE IF NOT EXISTS admin_users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token      TEXT PRIMARY KEY,
  username   TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
`);

// Хуучин хүснэгтэд багана нэмэх (аюулгүй — байхгүй бол л нэмнэ)
function ensureColumn(table, col, ddl) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all();
  if (!cols.some((c) => c.name === col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
}
ensureColumn('transactions', 'voucher_code', 'voucher_code TEXT');
ensureColumn('transactions', 'voucher_discount', 'voucher_discount INTEGER NOT NULL DEFAULT 0');
// Картын бонус — гүйлгээ бүрд тусад нь бүртгэнэ (тайланд ил харагдана)
ensureColumn('transactions', 'card_discount', 'card_discount INTEGER NOT NULL DEFAULT 0');
// NFC карт — хэрэглэгч бүрд нэг UID (давхардахгүй; хоосон байж болно)
ensureColumn('customers', 'nfc_uid', 'nfc_uid TEXT');
db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_cust_nfc ON customers(nfc_uid) WHERE nfc_uid IS NOT NULL');

// ---- Тохиргооны анхны утгууд (админ хэсгээс өөрчилнө) ----
const DEFAULT_SETTINGS = {
  business: {
    name: 'Moon Laundry',
    tagline: 'Өөртөө үйлчлэх хувцас угаалга',
    phone: '9145-0202',
    address: 'Улаанбаатар хот',
    hours: '09:00–22:00, өдөр бүр',
  },
  loyalty: {
    // 'per_service' — үйлчилгээ бүр өөр оноотой (үндсэн); 'per_visit' — ирэлт тутам тогтмол; 'per_amount' — дүнгээр
    points_mode: 'per_service',
    points_per_visit: 1,
    amount_per_point: 10000,
    default_points: 1, // per_service үед жагсаалтад байхгүй / гараар оруулсан үйлчилгээний оноо
    // Картын бонус — NFC карт холбосон хэрэглэгчид түвшнээс гадна НЭМЭЛТ хөнгөлөлт.
    // Админ хэсгээс нэг товчоор бүрэн унтраана (card_bonus_enabled = false).
    card_bonus_enabled: true,
    card_bonus_pct: 2,
    // Урамшууллын шат: оноо их байх тусам илүү сайн урамшуулал (карт дүүрэхэд оноонд тохирсон урамшуулал)
    reward_tiers: [
      { points: 10, title: 'Үнэгүй жижиг угаалга', value: 10000 },
      { points: 18, title: 'Үнэгүй том угаалга', value: 15000 },
      { points: 28, title: 'Том угаалга + хатаалт', value: 30000 },
    ],
    // Хуучин нэг урамшууллын талбарууд — reward_tiers[0]-оос гаргана (нийцтэй байдлын үүднээс)
    reward_threshold: 10,
    reward_title: 'Үнэгүй жижиг угаалга',
    reward_value: 10000,
    // 3 шатлалын хөнгөлөлт: 5% → 7% → 10%
    tiers: [
      { key: 'bronze', name: 'Bronze', min: 0, discount: 5 },
      { key: 'silver', name: 'Silver', min: 15, discount: 7 },
      { key: 'gold', name: 'Gold', min: 40, discount: 10 },
    ],
  },
  services: [
    { name: 'Угаалга — жижиг машин', price: 10000, points: 1 },
    { name: 'Угаалга — том машин', price: 15000, points: 3 },
    { name: 'Хатаалт', price: 15000, points: 2 },
    { name: 'Пүүз угаалга', price: 20000, points: 3 },
  ],
};

// Үйлчилгээний нэрнээс анхдагч оноо тааварлах (шинэ талбар нэмэхэд/шилжүүлэхэд)
function defaultServicePoints(name) {
  const n = String(name || '').toLowerCase();
  if (n.includes('том')) return 3;
  if (n.includes('пүүз') || n.includes('гутал')) return 3;
  if (n.includes('хатаа')) return 2;
  return 1;
}

const getSettingStmt = db.prepare('SELECT value FROM settings WHERE key = ?');
const setSettingStmt = db.prepare(
  'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
);

function getSetting(key) {
  const row = getSettingStmt.get(key);
  if (!row) return structuredClone(DEFAULT_SETTINGS[key]);
  try {
    return JSON.parse(row.value);
  } catch {
    return structuredClone(DEFAULT_SETTINGS[key]);
  }
}

function setSetting(key, value) {
  setSettingStmt.run(key, JSON.stringify(value));
}

function ensureDefaultSettings() {
  for (const key of Object.keys(DEFAULT_SETTINGS)) {
    if (!getSettingStmt.get(key)) setSetting(key, DEFAULT_SETTINGS[key]);
  }
}
ensureDefaultSettings();

// Хуучин суурилуулалтын тохиргоог шинэ бүтэц рүү зөөх (мэдээлэл алдагдуулахгүйгээр)
function migrateSettings() {
  // Үйлчилгээ бүрд оноо (points) талбар байхыг баталгаажуулна
  const services = getSetting('services');
  if (Array.isArray(services)) {
    let changed = false;
    for (const s of services) {
      if (typeof s.points !== 'number' || !Number.isFinite(s.points)) {
        s.points = defaultServicePoints(s.name);
        changed = true;
      }
    }
    if (changed) setSetting('services', services);
  }

  // Лоялти: reward_tiers, default_points талбарыг нэмнэ; хуучин анхдагч per_visit-г per_service рүү шинэчилнэ
  const l = getSetting('loyalty');
  let changed = false;
  if (!Array.isArray(l.reward_tiers) || !l.reward_tiers.length) {
    // Хуучин нэг урамшууллаас шат үүсгэх, эсвэл анхдагчийг ашиглах
    if (l.reward_threshold && l.reward_title) {
      l.reward_tiers = [
        { points: l.reward_threshold, title: l.reward_title, value: l.reward_value || 0 },
      ];
    } else {
      l.reward_tiers = DEFAULT_SETTINGS.loyalty.reward_tiers.map((t) => ({ ...t }));
    }
    changed = true;
  }
  if (typeof l.default_points !== 'number' || !Number.isFinite(l.default_points)) {
    l.default_points = 1;
    changed = true;
  }
  // Хуучин анхдагч (per_visit + 1 оноо) байсан бол шинэ per_service горимд шилжүүлнэ
  if (l.points_mode === 'per_visit' && (l.points_per_visit == null || l.points_per_visit === 1)) {
    l.points_mode = 'per_service';
    changed = true;
  }
  // Картын бонус талбарууд (шинэ) — байхгүй бол анхдагчаар нэмнэ
  if (typeof l.card_bonus_enabled !== 'boolean') {
    l.card_bonus_enabled = DEFAULT_SETTINGS.loyalty.card_bonus_enabled;
    changed = true;
  }
  if (typeof l.card_bonus_pct !== 'number' || !Number.isFinite(l.card_bonus_pct)) {
    l.card_bonus_pct = DEFAULT_SETTINGS.loyalty.card_bonus_pct;
    changed = true;
  }

  // Хуучин 0/5/10 шатлалыг шинэ 5/7/10 руу нэг удаа шилжүүлнэ.
  // Зөвхөн ХУУЧИН АНХДАГЧ хэвээрээ байвал хөнддөг тул гараар өөрчилсөн утга хэвээр үлдэнэ.
  if (Array.isArray(l.tiers) && l.tiers.length === 3) {
    const byMin = [...l.tiers].sort((a, b) => (a.min || 0) - (b.min || 0));
    const legacy =
      byMin[0].discount === 0 && byMin[1].discount === 5 && byMin[2].discount === 10;
    if (legacy) {
      byMin[0].discount = 5;
      byMin[1].discount = 7;
      byMin[2].discount = 10;
      l.tiers = byMin;
      changed = true;
    }
  }

  // Хуучин нэг урамшууллын талбарыг эхний шаттай ижил байлгах
  const first = [...l.reward_tiers].sort((a, b) => (a.points || 0) - (b.points || 0))[0];
  if (first && (l.reward_threshold !== first.points || l.reward_title !== first.title)) {
    l.reward_threshold = first.points;
    l.reward_title = first.title;
    l.reward_value = first.value;
    changed = true;
  }
  if (changed) setSetting('loyalty', l);
}
migrateSettings();

// Төхөөрөмжийн API түлхүүр — суурилуулалт бүрт нэг удаа санамсаргүйгээр үүсгэнэ
// (кодод хатуу утга бичихгүй; DEVICE_KEY орчны хувьсагчаар дарж болно)
if (!getSettingStmt.get('device_key'))
  setSetting('device_key', crypto.randomBytes(24).toString('base64url'));

module.exports = { db, getSetting, setSetting, DEFAULT_SETTINGS, DB_PATH, defaultServicePoints };
