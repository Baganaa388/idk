// Нээлттэй API — зөвхөн харах эрхтэй (ямар ч бичилт хийхгүй).
'use strict';

const express = require('express');
const { getSetting } = require('../db');
const {
  isPhone,
  customerPublicView,
  activePromosPublic,
  getCustomerByNfc,
  normalizeUid,
  cardBonusPct,
} = require('../lib');

const router = express.Router();

// Бонус шалгахын энгийн хязгаарлалт: IP тус бүр минутад 30 хүсэлт
const hits = new Map();
function publicRateLimit(req, res, next) {
  const ip = req.ip || '?';
  const now = Date.now();
  let h = hits.get(ip);
  if (!h || now > h.resetAt) h = { count: 0, resetAt: now + 60_000 };
  if (h.count >= 30) return res.status(429).json({ error: 'Түр хүлээгээд дахин оролдоно уу.' });
  h.count++;
  hits.set(ip, h);
  next();
}
// Санах ой хамгаалах: хугацаа дууссан IP бичлэгүүдийг тогтмол цэвэрлэнэ
setInterval(() => {
  const now = Date.now();
  for (const [ip, h] of hits) if (now > h.resetAt) hits.delete(ip);
}, 5 * 60_000).unref();

// Сайтын мэдээлэл: нэр, үнэ, лоялти дүрэм, идэвхтэй промо
router.get('/site', (req, res) => {
  const loyalty = getSetting('loyalty');
  res.json({
    business: getSetting('business'),
    services: getSetting('services'),
    loyalty: {
      points_mode: loyalty.points_mode,
      points_per_visit: loyalty.points_per_visit,
      amount_per_point: loyalty.amount_per_point,
      default_points: loyalty.default_points,
      reward_threshold: loyalty.reward_threshold,
      reward_title: loyalty.reward_title,
      reward_tiers: loyalty.reward_tiers,
      tiers: loyalty.tiers,
      card_bonus_pct: cardBonusPct(loyalty),
    },
    promos: activePromosPublic(),
  });
});

// Бонус шалгах — утасны дугаараар, зөвхөн харах
router.post('/check', publicRateLimit, (req, res) => {
  const phone = String(req.body?.phone || '').replace(/\D/g, '');
  if (!isPhone(phone))
    return res.status(400).json({ error: 'Утасны дугаар 8 оронтой байх ёстой' });
  const view = customerPublicView(phone);
  if (!view)
    return res.status(404).json({
      error: 'Энэ дугаар манай бонусын хөтөлбөрт бүртгэлгүй байна. Дараагийн ирэлтдээ кассанд дугаараа хэлж бүртгүүлээрэй!',
    });
  res.json({ ...view, promos: activePromosPublic() });
});

// Бонус шалгах — NFC картын uid-аар (утсаараа картаа уншуулбал шууд онооны хуудас нээгдэнэ)
router.get('/check-uid', publicRateLimit, (req, res) => {
  const uid = normalizeUid(String(req.query?.uid || ''));
  if (!uid || uid.length < 6)
    return res.status(400).json({ error: 'Картын код буруу байна' });
  const c = getCustomerByNfc(uid);
  if (!c)
    return res.status(404).json({
      error: 'Энэ карт бүртгэлгүй байна. Дараагийн ирэлтдээ кассанд хандаж бүртгүүлээрэй!',
    });
  const view = customerPublicView(c.phone);
  if (!view) return res.status(404).json({ error: 'Мэдээлэл олдсонгүй.' });
  res.json({ ...view, promos: activePromosPublic() });
});

module.exports = router;
